create PACKAGE            MGMT_CONFIG_UTL
AUTHID CURRENT_USER AS
/*
Create or replace the directory object to recreate the path based on
new ORACLE_HOME.
Note:
  1. This procedure is executed with invoker's rights. This is needed so that
     ORACLE_OCM user does not need to be granted "execute" permission on "dbms_system" package.
     Only SYS would be able to run this procedure without error as it has the privilege to execute "dbms_system" and re-create
     the directory object ORACLE_OCM_CONFIG_DIR owned by it.
  2. This procedure is only supported from release 10.2 onwards that supports dbms_system.get_env.
*/
procedure create_replace_dir_obj;
END MGMT_CONFIG_UTL;
/


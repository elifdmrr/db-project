create view WWV_FLOW_FEATURE_DOCSTATUS as
select 0 id, wwv_flow_lang.system_message('NO_STATUS')        the_name from dual union all
select 1 id, wwv_flow_lang.system_message('NOT_STARTED')      the_name from dual union all
select 2 id, wwv_flow_lang.system_message('RESEARCHING')      the_name from dual union all
select 3 id, wwv_flow_lang.system_message('NEED_INFORMATION') the_name from dual union all
select 4 id, wwv_flow_lang.system_message('WRITING')          the_name from dual union all
select 5 id, wwv_flow_lang.system_message('REVIEWING')        the_name from dual union all
select 6 id, wwv_flow_lang.system_message('COMPLETED')        the_name from dual union all
select 7 id, wwv_flow_lang.system_message('ARCHIVED')         the_name from dual union all
select 10 id, wwv_flow_lang.system_message('NOT_REQUIRED')    the_name from dual
/


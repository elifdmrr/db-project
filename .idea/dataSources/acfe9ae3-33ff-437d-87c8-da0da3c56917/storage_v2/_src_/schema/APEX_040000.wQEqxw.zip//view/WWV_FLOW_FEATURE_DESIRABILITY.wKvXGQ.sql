create view WWV_FLOW_FEATURE_DESIRABILITY as
select 1 id, wwv_flow_lang.system_message('MARQUEE_FEATURE')      the_name from dual union all
select 2 id, wwv_flow_lang.system_message('HIGHLY_DESIRABLE')     the_name from dual union all
select 3 id, wwv_flow_lang.system_message('DESIRABLE')   the_name from dual union all
select 4 id, wwv_flow_lang.system_message('NOT_DESIRABLE')        the_name from dual
/


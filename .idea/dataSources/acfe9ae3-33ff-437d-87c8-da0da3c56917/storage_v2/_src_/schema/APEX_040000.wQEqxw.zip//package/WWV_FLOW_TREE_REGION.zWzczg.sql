create package wwv_flow_tree_region
as

--
-- Procedure which reads the meta data for the tree and initializes other
-- global variables.
-- Note: This procedure has to be called before calling any other procedure in
--       this package
procedure init (
    p_application_id in number,
    p_page_id        in number,
    p_region_id      in number);
--
--
-- Procedure which generates the necessary HTML code for the tree.
-- Note: init has to be called before calling this procedure
procedure show_tree;

--
-- Central dispatch procedure for refreshing parts of the tree. Called from the
-- on-demand process on the generated page.
procedure get_tree_data;

-- Retrieve jsTree attributes
procedure fetch_jstree_attr  (
    p_flow_id                   in number,
    p_region_id                 in number,
    p_tree_template             out varchar2,
    p_tree_source               out varchar2,
    p_tree_query                out varchar2,
    p_tree_node_title           out varchar2,
    p_tree_node_value           out varchar2,
    p_tree_node_icon            out varchar2,
    p_tree_node_link            out varchar2,
    p_tree_node_hints           out varchar2,
    p_show_node_link            out varchar2,
    p_node_link_checksum_type   out varchar2,
    p_show_hints                out varchar2,
    p_tree_hint_text            out varchar2,
    p_tree_has_focus            out varchar2,
    p_tree_click_action         out varchar2,
    p_selected_node             out varchar2
    );

-- Save jsTree attributes
procedure save_jstree_attr  (
    p_flow_id                   in number default null,
    p_page_id                   in number default null,
    p_region_id                 in number default null,
    p_tree_template             in varchar2 default null,
    p_tree_source               in varchar2 default null,
    p_tree_query                in varchar2 default null,
    p_tree_node_title           in varchar2 default null,
    p_tree_node_value           in varchar2 default null,
    p_tree_node_icon            in varchar2 default null,
    p_tree_node_link            in varchar2 default null,
    p_tree_node_hints           in varchar2 default null,
    p_show_node_link            in varchar2 default null,
    p_node_link_checksum_type   in varchar2 default null,
    p_show_hints                in varchar2 default null,
    p_tree_hint_text            in varchar2 default null,
    p_tree_has_focus            in varchar2 default null,
    p_tree_click_action         in varchar2 default null,
    p_selected_node             in varchar2 default null
    );


/*function is_valid_tree_item_query (
    p_query in varchar2
    ) return boolean; */

procedure set_tree(
    p_tree        in wwv_flow_plugin_util.t_column_value_list
);

procedure set_tree_id(
    p_tree_id     in number
);

procedure set_tree_template(
    p_tree_template  in varchar2
);

procedure set_tree_has_focus(
    p_tree_has_focus in varchar2
);

procedure set_tree_action(
    p_tree_action  in varchar2
);

procedure set_hints(
    p_hints  in varchar2
);

procedure set_hints_text(
    p_hints_text  in varchar2
);

function is_valid_start_query(
    p_sql        in varchar2
) return boolean;

end wwv_flow_tree_region;
/


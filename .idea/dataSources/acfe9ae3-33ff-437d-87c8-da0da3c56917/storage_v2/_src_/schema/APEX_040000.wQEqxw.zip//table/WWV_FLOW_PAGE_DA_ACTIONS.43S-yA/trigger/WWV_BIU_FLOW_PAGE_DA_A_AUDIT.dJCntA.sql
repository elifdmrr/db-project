create trigger WWV_BIU_FLOW_PAGE_DA_A_AUDIT
    before insert or update or delete
    on WWV_FLOW_PAGE_DA_ACTIONS
    for each row
declare
    l_action varchar2(1);
begin
    l_action := case
                  when inserting then 'I'
                  when updating  then 'U'
                  else                'D'
                end;
    begin
        wwv_flow_audit.audit_action (
           p_table_name  => 'WWV_FLOW_PAGE_DA_ACTIONS',
           p_action      => l_action,
           p_table_pk    => nvl(:old.id, :new.id),
           p_object_name => nvl(:new.action,:old.action) );
    exception when others then null;
    end;
end;
/


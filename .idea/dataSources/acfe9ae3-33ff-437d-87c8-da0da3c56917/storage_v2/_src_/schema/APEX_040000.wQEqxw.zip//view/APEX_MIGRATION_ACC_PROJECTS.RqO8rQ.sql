create view APEX_MIGRATION_ACC_PROJECTS as
select
        a.project_id                                    project_id,
     --
        d.migration_name                                project_name,
     --
        d.description                                   description,
     --
        d.migration_type                                migration_type,
     --
        d.created_by                                    project_owner,
     --
        a.dbpathname                                    accdb_pathname,
     --
       (select count(*) from wwv_mig_acc_tables
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              tables,
     --
       (select count(*) from wwv_mig_acc_queries
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              queries,
     --
       (select count(*) from wwv_mig_acc_forms
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              forms,
     --
       (select count(*) from wwv_mig_acc_reports
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              reports,
     --
       (select count(*) from wwv_mig_acc_pages
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              pages,
     --
       (select count(*) from wwv_mig_acc_modules
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              modules,
     --
       (select count(*) from wwv_mig_acc_relations
        where project_id = a.project_id
        and security_group_id = a.security_group_id
        and dbid = a.dbid)                              relations,
     --
        a.jetversion                                    jetversion,
     --
        a.accessversion                                 accessversion,
     --
        a.dbname                                        dbname,
     --
        a.dbid                                          dbid,
     --
        a.dbsize                                        dbsize,
     --
        a.isappdb                                       isappdb,
     --
        a.isattacheddb                                  isattacheddb,
     --
        a.startupform                                   startupform,
     --
        a.linkdbid                                      linkdbid,
     --
        a.created_by                                    created_by,
     --
        d.last_updated_on                               last_modified_on,
     --
        d.last_updated_by                               last_modified_by,
     --
        s.schema                                        schema,
     --
        w.short_name                                    workspace,
     --
        w.provisioning_company_id                       workspace_id
from
        wwv_mig_access a,
     --
        wwv_flow_company_schemas s,
     --
        wwv_mig_projects d,
     --
        wwv_flow_companies w,
     --
        (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) g
where
        (s.schema = user or user in ('SYS','SYSTEM','APEX_040000') or g.sgid = w.PROVISIONING_COMPANY_ID)
and     w.PROVISIONING_COMPANY_ID != 0
and     a.database_schema = s.schema
and     a.project_id = d.id
and     a.security_group_id = d.security_group_id
and     w.provisioning_company_id = a.security_group_id
and     w.provisioning_company_id = s.security_group_id
order by w.PROVISIONING_COMPANY_ID, a.project_id
/

comment on table APEX_MIGRATION_ACC_PROJECTS is 'Available Application Express (Apex) Application Migrations MS Access Migration Projects'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.PROJECT_ID is 'Primary key that identifies the migration project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.PROJECT_NAME is 'Identifies name of the migration project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.DESCRIPTION is 'A brief description of the migration project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.MIGRATION_TYPE is 'Identifies the type of Migration Project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.PROJECT_OWNER is 'Identifies the Apex User Name who created and owns the Migration Project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.ACCDB_PATHNAME is 'Identifies full path name and location of the Microsoft Access database the migration project is based on'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.TABLES is 'Number of tables in the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.QUERIES is 'Number of queries in the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.FORMS is 'Number of forms in the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.REPORTS is 'Number of reports in the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.MODULES is 'Number of modules in the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.RELATIONS is 'Number of relationships in the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.JETVERSION is 'Version of Microsoft Jet for MS Access associated with captured Microsoft Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.ACCESSVERSION is 'Version of Microsoft Access database captured, which the migration project is based on'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.DBNAME is 'Identifies the name of the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.DBID is 'Identifies the unique number of the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.DBSIZE is 'Identifies the size of the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.ISAPPDB is 'Identifies whether the MS Access database is a single or parent database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.ISATTACHEDDB is 'Identifies whether the MS Access database is attached to a parent database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.STARTUPFORM is 'Identifies the name of the startup form in the MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.LINKDBID is 'Identifies the unique number of the MS Access database that this parent database is linked to'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.CREATED_BY is 'Identifies the name of the user who created the original MS Access database'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.LAST_MODIFIED_ON is 'Date of most recent changes to the Migration Project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.LAST_MODIFIED_BY is 'Identifies the APEX User Name who last modified the Migration Project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.SCHEMA is 'Identifies the name of database schema associated with the Migration Project'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_MIGRATION_ACC_PROJECTS.WORKSPACE_ID is 'Primary key that identifies the workspace'
/


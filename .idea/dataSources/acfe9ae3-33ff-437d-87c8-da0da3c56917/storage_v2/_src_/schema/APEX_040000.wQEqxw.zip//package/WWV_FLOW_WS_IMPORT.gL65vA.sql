create package wwv_flow_ws_import as

function is_date (
    p_str    in varchar2,
    p_format out varchar2) return boolean;

procedure import_csv (
     p_flow_id            number default null,
     p_ws_app_id          number,
     p_worksheet_id       number,
     p_websheet_id        number,
     p_collection_name    varchar2,
     p_headings_included  varchar2);

procedure import_text_sections (
    p_ws_app_id           in number,
    p_webpage_id          in number,
    p_collection_name     in varchar2,
    p_headings_included   in varchar2 default 'Y');
end wwv_flow_ws_import;
/


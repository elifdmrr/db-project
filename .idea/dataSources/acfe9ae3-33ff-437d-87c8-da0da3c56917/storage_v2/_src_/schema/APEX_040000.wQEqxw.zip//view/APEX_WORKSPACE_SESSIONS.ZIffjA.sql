create view APEX_WORKSPACE_SESSIONS as
select
    w.workspace_id                                      workspace_id,
    w.workspace_name                                    workspace_name,
    s.id                                                apex_session_id,
    s.cookie                                            user_name,
    s.created_on                                        session_created
from
    wwv_flow_sessions$ s,
(
select
    w.PROVISIONING_COMPANY_ID                           workspace_id,
    w.short_name                                        workspace_name,
    w.FIRST_SCHEMA_PROVISIONED                          first_schema_provisioned
from
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      w.PROVISIONING_COMPANY_ID != 0
group by  w.PROVISIONING_COMPANY_ID, w.short_name, w.FIRST_SCHEMA_PROVISIONED
) w
where s.SECURITY_GROUP_ID = w.workspace_id
/

comment on table APEX_WORKSPACE_SESSIONS is 'Application Express (APEX) sessions by workspace and APEX user'
/

comment on column APEX_WORKSPACE_SESSIONS.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

comment on column APEX_WORKSPACE_SESSIONS.WORKSPACE_NAME is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WORKSPACE_SESSIONS.APEX_SESSION_ID is 'Primary key of the apex session'
/

comment on column APEX_WORKSPACE_SESSIONS.USER_NAME is 'Name of the authenticated or public user'
/

comment on column APEX_WORKSPACE_SESSIONS.SESSION_CREATED is 'Date the APEX session was created'
/


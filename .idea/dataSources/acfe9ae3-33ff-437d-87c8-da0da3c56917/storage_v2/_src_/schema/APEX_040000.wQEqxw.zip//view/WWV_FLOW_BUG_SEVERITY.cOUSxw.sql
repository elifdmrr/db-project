create view WWV_FLOW_BUG_SEVERITY as
select 1 id, wwv_flow_lang.system_message('PRODUCTION_DOWN') the_name from dual union all
select 2 id, wwv_flow_lang.system_message('NO_WORKAROUND_AVAILABLE') the_name from dual union all
select 3 id, wwv_flow_lang.system_message('SIGNIFICANT_IMPACT') the_name from dual union all
select 4 id, wwv_flow_lang.system_message('MODERATE_IMPACT') the_name from dual union all
select 5 id, wwv_flow_lang.system_message('MINIMAL_IMPACT') the_name from dual union all
select 0 id, wwv_flow_lang.system_message('UNKNOWN') the_name from dual
/


create view APEX_WS_DATA_GRID as
select
w.short_name                workspace,
a.id                        application_id,
a.name                      application_name,
dg.worksheet_id             interactive_report_id,
dg.id                       data_grid_id,
dg.websheet_name            data_grid_name,
dg.websheet_alias           data_grid_alias,
--
dg.created_on               ,
dg.created_by               ,
dg.updated_on               ,
dg.updated_by
from wwv_flow_ws_websheet_attr dg,
     wwv_flow_ws_applications a,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.is_apex$_schema = 'Y' and
      a.security_group_id = w.PROVISIONING_COMPANY_ID and
      a.security_group_id = dg.security_group_id and
      a.id = dg.ws_app_id and
      dg.websheet_type = 'DATA' and
      w.provisioning_company_id != 0
/

comment on table APEX_WS_DATA_GRID is 'Websheet Data Grid definition'
/

comment on column APEX_WS_DATA_GRID.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WS_DATA_GRID.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_WS_DATA_GRID.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_WS_DATA_GRID.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_WS_DATA_GRID.DATA_GRID_ID is 'ID of the Data Grid'
/

comment on column APEX_WS_DATA_GRID.DATA_GRID_NAME is 'Name of the Data Grid'
/

comment on column APEX_WS_DATA_GRID.DATA_GRID_ALIAS is 'An alternate alphanumeric Data Grid identifier'
/

comment on column APEX_WS_DATA_GRID.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_WS_DATA_GRID.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_WS_DATA_GRID.UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_WS_DATA_GRID.UPDATED_BY is 'Auditing; user that last modified the record.'
/


create view APEX_TEAM_FEATURES as
select
    w.PROVISIONING_COMPANY_ID     workspace_id,
    w.short_name                  workspace_name,
    --
    f.id                          feature_id,
    f.feature_id                  feature_friendly_id,
    f.feature_name,
    f.feature_owner,
    f.feature_contributor,
    f.focus_area,
    f.release,
    f.feature_desc                feature_description,
    f.justification,
    f.feature_tags,
    f.feature_priority,
    f.feature_status,
    f.feature_desirability,
    f.due_date,
    f.start_date,
    f.module,
    f.estimated_effort_in_hours,
    --
    f.publishable_yn,
    f.publishable_description,
    --
    f.globalization_impact,
    f.globalization_assignee,
    f.globalization_status,
    --
    f.user_interface_impact,
    f.user_interface_assignee,
    f.user_interface_status,
    --
    f.doc_impact,
    f.doc_status,
    f.doc_writer,
    --
    f.testing_impact,
    f.testing_assignee,
    f.testing_status,
    --
    f.security_impact,
    f.security_assignee,
    f.security_status,
    --
    f.accessibility_impact,
    f.accessibility_assignee,
    f.accessibility_status,
    --
    f.application_id,
    f.parent_feature_id,
    f.event_id                    milestone_id,
    --
    f.created_by,
    f.created_on,
    f.updated_by,
    f.updated_on
from
    wwv_flow_features f,
    wwv_flow_companies w
where
    f.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_TEAM_FEATURES is 'Items that need to get done - i.e. to dos.'
/

comment on column APEX_TEAM_FEATURES.WORKSPACE_ID is 'Primary key that identifies the workspace.'
/

comment on column APEX_TEAM_FEATURES.WORKSPACE_NAME is 'Name of the workspace.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_ID is 'Primary key of the feature.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_FRIENDLY_ID is 'More readable id for the feature (unique within workspace only).'
/

comment on column APEX_TEAM_FEATURES.FEATURE_NAME is 'Brief description of the feature.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_OWNER is 'Identifies who the feature is assigned to.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_CONTRIBUTOR is 'Identifies who is contributing to the completion of the feature.'
/

comment on column APEX_TEAM_FEATURES.FOCUS_AREA is 'Focus area (or category) assigned to this feature.'
/

comment on column APEX_TEAM_FEATURES.RELEASE is 'Release associated with this feature.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_DESCRIPTION is 'Detailed description of the feature.'
/

comment on column APEX_TEAM_FEATURES.JUSTIFICATION is 'Justification for creating this feature.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_TAGS is 'Tags associated with this feature.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_PRIORITY is 'Priority assigned to this feature.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_STATUS is 'Current status of this feature.'
/

comment on column APEX_TEAM_FEATURES.FEATURE_DESIRABILITY is 'Desirability of this feature.'
/

comment on column APEX_TEAM_FEATURES.DUE_DATE is 'Date this feature is due to be completed.'
/

comment on column APEX_TEAM_FEATURES.START_DATE is 'Date this feature is due to be started.'
/

comment on column APEX_TEAM_FEATURES.MODULE is 'Module associated with this feature.'
/

comment on column APEX_TEAM_FEATURES.ESTIMATED_EFFORT_IN_HOURS is 'Estimate of the number of hours this feature will take to complete.'
/

comment on column APEX_TEAM_FEATURES.PUBLISHABLE_YN is 'Identifies whether or not this feature is publishable.'
/

comment on column APEX_TEAM_FEATURES.PUBLISHABLE_DESCRIPTION is 'Description that will be published describing this feature.'
/

comment on column APEX_TEAM_FEATURES.GLOBALIZATION_IMPACT is 'The globalization impact of this feature, including notes from the review.'
/

comment on column APEX_TEAM_FEATURES.GLOBALIZATION_ASSIGNEE is 'Person responsible for reviewing the globalization of this feature.'
/

comment on column APEX_TEAM_FEATURES.GLOBALIZATION_STATUS is 'Status of the globalization review of this feature.'
/

comment on column APEX_TEAM_FEATURES.USER_INTERFACE_IMPACT is 'The user interface impact of this feature, including notes from the review.'
/

comment on column APEX_TEAM_FEATURES.USER_INTERFACE_ASSIGNEE is 'Person responsible for reviewing the user interface of this feature.'
/

comment on column APEX_TEAM_FEATURES.USER_INTERFACE_STATUS is 'Status of the user interface review of this feature.'
/

comment on column APEX_TEAM_FEATURES.DOC_IMPACT is 'Additional information about needed documentation or documentation status.'
/

comment on column APEX_TEAM_FEATURES.DOC_STATUS is 'Status of documentation for this feature.'
/

comment on column APEX_TEAM_FEATURES.DOC_WRITER is 'Person responsible to document this feature.'
/

comment on column APEX_TEAM_FEATURES.TESTING_IMPACT is 'Additional information about needed testing or testing status.'
/

comment on column APEX_TEAM_FEATURES.TESTING_ASSIGNEE is 'Person responsible to test this feature.'
/

comment on column APEX_TEAM_FEATURES.TESTING_STATUS is 'Testing status for this feature.'
/

comment on column APEX_TEAM_FEATURES.SECURITY_IMPACT is 'The security impact of this feature, including notes from the review.'
/

comment on column APEX_TEAM_FEATURES.SECURITY_ASSIGNEE is 'Person responsible for reviewing the security of this feature.'
/

comment on column APEX_TEAM_FEATURES.SECURITY_STATUS is 'Status of the security review of this feature.'
/

comment on column APEX_TEAM_FEATURES.ACCESSIBILITY_IMPACT is 'The accessibility impact of this feature, including notes from the review.'
/

comment on column APEX_TEAM_FEATURES.ACCESSIBILITY_ASSIGNEE is 'Person responsible for reviewing the accessibility of this feature.'
/

comment on column APEX_TEAM_FEATURES.ACCESSIBILITY_STATUS is 'Status of the accessibility review of this feature.'
/

comment on column APEX_TEAM_FEATURES.APPLICATION_ID is 'Associated application.'
/

comment on column APEX_TEAM_FEATURES.PARENT_FEATURE_ID is 'ID of parent feature (link to feature_id to view hierarchy).'
/

comment on column APEX_TEAM_FEATURES.MILESTONE_ID is 'Associated milestone.'
/

comment on column APEX_TEAM_FEATURES.CREATED_BY is 'Developer who created this milestone.'
/

comment on column APEX_TEAM_FEATURES.CREATED_ON is 'Date on which this milestone was created.'
/

comment on column APEX_TEAM_FEATURES.UPDATED_BY is 'Developer who last updated this milestone.'
/

comment on column APEX_TEAM_FEATURES.UPDATED_ON is 'Date on which this milestone was last updated.'
/


create package wwv_flow_translation_utilities
as

--  Copyright (c) Oracle Corporation 2001 - 2009. All Rights Reserved.
--
--    DESCRIPTION
--      Global variables and APIs for use with flow translation services
--
--    SECURITY
--      Available to flows owner
--      No sensitive data
--
--    NOTES
--
--      Populate wwv_flow_translatable_text$ from columns identified in wwv_flow_translatable_cols$.
--      P_FLOW_ID identifies primary language flow ID.
--      P_LANGUAGE identifies language code the translation is into.
--      The translation_flow_id will be derived from the wwv_flow_language_map table.

-------------------
-- global variables
--
g_seed_new_attributes      number := 0;
g_seed_purged_attributes   number := 0;
g_seed_changed_attributes  number := 0;

procedure reuse_translations (
    p_from_flow_id          in varchar2 default null,
    p_translated_flow_id    in varchar2 default null,
    p_security_group_id     in varchar2 default null)
    ;

procedure seed_and_publish (
    p_from_flow_id          in varchar2 default null,
    p_language              in varchar2 default null,
    p_insert_only           in varchar2 default 'NO',
    p_translated_flow_id    in varchar2 default null,
    p_security_group_id     in varchar2 default null)
    ;

procedure publish_application (
    p_from_flow_id          in varchar2 default null,
    p_translated_flow_id    in varchar2 default null,
    p_security_group_id     in varchar2 default null)
    ;

procedure sync_translations (
    p_flow_id              in varchar2 default null,
    p_language             in varchar2 default null)
    ;

procedure seed_translations (
    p_flow_id              in varchar2 default null,
    p_language             in varchar2 default null,
    p_insert_only          in varchar2 default 'NO')
    ;


procedure flow_copy (
    p_flow_id_from         in number,
    p_flow_id_to           in number,
    p_alias_to             in varchar2 default null,
    p_flow_language_to     in varchar2,
    p_ok_to_delete_flow    in boolean := false,
    p_perform_translations in boolean := true)
    ;

end wwv_flow_translation_utilities;
/


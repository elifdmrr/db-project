create package wwv_purge is

procedure compute_inactive;

procedure save_response(
    p_purge_email_id in number,
    p_response_code  in varchar2 );

procedure daily_purge_process;

procedure send_summary_email;

end wwv_purge;
/


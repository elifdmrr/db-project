create view APEX_UI_DEFAULTS_COLUMNS as
select t.schema,
       t.table_name,
       c.column_name,
       c.label,
       c.help_text,
       g.group_name,
       c.mask_form,
       c.display_seq_form,
       c.display_in_form,
       c.display_as_form,
       c.form_attribute_01,
       c.form_attribute_02,
       c.form_attribute_03,
       c.form_attribute_04,
       c.form_attribute_05,
       c.form_attribute_06,
       c.form_attribute_07,
       c.form_attribute_08,
       c.form_attribute_09,
       c.form_attribute_10,
       c.display_as_tab_form,
       c.display_seq_report,
       c.display_in_report,
       c.display_as_report,
       c.mask_report,
       c.aggregate_by,
       c.default_value,
       c.required,
       c.alignment,
       c.display_width,
       c.max_width,
       c.height,
       c.group_by,
       c.searchable,
       c.lov_query,
       c.created_by,
       c.created_on,
       c.last_updated_by,
       c.last_updated_on
  from wwv_flow_hnt_column_info c,
       wwv_flow_hnt_table_info t,
       wwv_flow_hnt_groups g
 where t.schema   = user
   and c.table_id = t.table_id
   and c.group_id = g.group_id (+)
/

comment on table APEX_UI_DEFAULTS_COLUMNS is 'The User Interface Defaults for the columns within this schema.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.SCHEMA is 'Schema owning table.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.TABLE_NAME is 'The table associated with the user interface defaults.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.COLUMN_NAME is 'The column associated with the user interface defaults.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.LABEL is 'When creating a form against this table or view, this will be used as the label for the item if this column is included. When creating a report or tabular form, this will be used as the column heading if this column is included.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.HELP_TEXT is 'When creating a form against this table or view, this becomes the help text for the resulting item.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.GROUP_NAME is 'The group associated with this column.  Will be used for creating regions in forms and groups in interactive reports.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.MASK_FORM is 'When creating a form against this table or view, this specifies the mask that will be applied to the item, such as 999-99-9999. This is not used for character based items.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_SEQ_FORM is 'When creating a form against this table or view, this determines the sequence in which the columns will be displayed in the resulting form page.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_IN_FORM is 'When creating a form against this table or view, this determines whether this column will be displayed in the resulting form page.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_AS_FORM is 'When creating a form against this table or view, this determines the way the column will be displayed, such as text area or text field.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_01 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_02 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_03 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_04 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_05 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_06 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_07 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_08 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_09 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.FORM_ATTRIBUTE_10 is 'When creating a form against this table or view, this dynamic attribute stores additional information for item type specified in display_as_form.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_AS_TAB_FORM is 'When creating a tabular form against this table or view, this determines the way the column will be displayed, such as select list or popup LOV.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_SEQ_REPORT is 'When creating a report against this table or view, this determines the sequence in which the columns will be displayed in the resulting report.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_IN_REPORT is 'When creating a report against this table or view, this determines whether this column will be displayed in the resulting report.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_AS_REPORT is 'When creating a report against this table or view, this determines the way the column will be displayed, such as Standard Report Column or Display as Text (based on LOV).'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.MASK_REPORT is 'When creating a report against this table or view, this specifies the mask that will be applied against the data, such as 999-99-9999. This is not used for character based items.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.AGGREGATE_BY is 'Obsolete.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DEFAULT_VALUE is 'When creating a form against this table or view, this specifies the default value for the item resulting from this column.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.REQUIRED is 'When creating a form against this table or view, this specifies to generate a validation in which the resulting item must be NOT NULL.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.ALIGNMENT is 'When creating a report against this table or view, this determines the alignment for the resulting report column (left, center, or right).'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.DISPLAY_WIDTH is 'When creating a form against this table or view, this specifies the display width of the item resulting from this column.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.MAX_WIDTH is 'When creating a form against this table or view, this specifies the maximum string length that a user is allowed to enter in the item resulting from this column.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.HEIGHT is 'When creating a form against this table or view, this specifies the display height of the item resulting from this column.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.GROUP_BY is 'Obsolete.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.SEARCHABLE is 'Obsolete.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.LOV_QUERY is 'A query to be turned into a Named List of Values if this column is included in a Form, Report or Tabular Form and the column is displayed as a type that uses a List of Values (such as Radio Group or Select List).'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

comment on column APEX_UI_DEFAULTS_COLUMNS.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/


create package wwv_flow_ws_flash_chart
as

procedure chart(p_section_id in number default null);

end wwv_flow_ws_flash_chart;
/


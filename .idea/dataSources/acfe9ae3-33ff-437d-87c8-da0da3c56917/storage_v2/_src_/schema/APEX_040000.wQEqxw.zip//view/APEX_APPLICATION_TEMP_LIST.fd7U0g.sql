create view APEX_APPLICATION_TEMP_LIST as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.LIST_TEMPLATE_NAME             template_name,
    t.LIST_TEMPLATE_CURRENT,
    t.LIST_TEMPLATE_NONCURRENT,
    t.LIST_TEMPLATE_BEFORE_ROWS,
    t.LIST_TEMPLATE_AFTER_ROWS,
    t.BETWEEN_ITEMS,
    t.BEFORE_SUB_LIST,
    t.AFTER_SUB_LIST,
    t.BETWEEN_SUB_LIST_ITEMS,
    t.SUB_LIST_ITEM_CURRENT,
    t.SUB_LIST_ITEM_NONCURRENT,
    t.ITEM_TEMPLATE_CURR_W_CHILD,
    t.ITEM_TEMPLATE_NONCURR_W_CHILD,
    t.SUB_TEMPLATE_CURR_W_CHILD,
    t.SUB_TEMPLATE_NONCURR_W_CHILD,
    --
    t.FIRST_LIST_TEMPLATE_NONCURRENT,
    t.FIRST_LIST_TEMPLATE_CURRENT,
    t.F_ITEM_TEMPLATE_CURR_W_CHILD,
    t.FITEM_TEMPLATE_NONCURR_W_CHILD,
    --
    decode(t.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name
     from WWV_FLOW_LIST_TEMPLATES
     where id = t.REFERENCE_ID)      subscribed_from,
    --
    t.LAST_UPDATED_BY                ,
    t.LAST_UPDATED_ON                ,
    t.THEME_ID                       theme_number,
    decode(t.THEME_CLASS_ID,
       '1','Vertical Unordered List with Bullets',
       '2','Vertical Ordered List',
       '3','Horizontal Links List',
       '4','Horizontal Images with Label List',
       '5','Vertical Images List',
       '6','Button List',
       '7','Tabbed Navigation List',
       '9','Custom 1',
       '10','Custom 2',
       '11','Custom 3',
       '12','Custom 4',
       '13','Custom 5',
       '14','Custom 6',
       '15','Custom 7',
       '16','Custom 8',
       '17','Wizard Progress List',
       '18','Vertical Unordered List without Bullets',
       '19','Vertical Sidebar List',
       '20','Pull Down Menu',
       '21','Pull Down Menu with Image',
       '22','Hierarchical Expanding',
       '23','Hierarchical Expanded',
       t.THEME_CLASS_ID)             theme_class,
    t.TRANSLATE_THIS_TEMPLATE,
    t.LIST_TEMPLATE_COMMENT          component_comment,
    t.id                             list_template_id,
    --
    t.LIST_TEMPLATE_NAME
    ||' t='||t.THEME_ID
    ||' c='||t.THEME_CLASS_ID
    ||' 1='||dbms_lob.substr(t.LIST_TEMPLATE_CURRENT,40,1)||'.'||dbms_lob.getlength(t.LIST_TEMPLATE_CURRENT)
    ||' 2='||dbms_lob.substr(t.LIST_TEMPLATE_NONCURRENT,40,1)||'.'||dbms_lob.getlength(t.LIST_TEMPLATE_NONCURRENT)
    ||' 3='||dbms_lob.substr(t.SUB_LIST_ITEM_CURRENT,40,1)||'.'||dbms_lob.getlength(t.SUB_LIST_ITEM_CURRENT)
    ||' 4='||dbms_lob.substr(t.SUB_LIST_ITEM_NONCURRENT,40,1)||'.'||dbms_lob.getlength(t.SUB_LIST_ITEM_NONCURRENT)
    ||' 5='||dbms_lob.substr(t.ITEM_TEMPLATE_CURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.ITEM_TEMPLATE_CURR_W_CHILD)
    ||' 6='||dbms_lob.substr(t.ITEM_TEMPLATE_NONCURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.ITEM_TEMPLATE_NONCURR_W_CHILD)
    ||' 7='||dbms_lob.substr(t.SUB_TEMPLATE_CURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.SUB_TEMPLATE_CURR_W_CHILD)
    ||' 8='||dbms_lob.substr(t.SUB_TEMPLATE_NONCURR_W_CHILD,40,1)||'.'||dbms_lob.getlength(t.SUB_TEMPLATE_NONCURR_W_CHILD)
    ||' t='||t.TRANSLATE_THIS_TEMPLATE
    ||' r='||decode(t.REFERENCE_ID,null,'N','Y')
    ||' b='||substr(t.LIST_TEMPLATE_BEFORE_ROWS,1,20)||length(t.LIST_TEMPLATE_BEFORE_ROWS)
    ||' a='||substr(t.LIST_TEMPLATE_AFTER_ROWS,1,20)||length(t.LIST_TEMPLATE_AFTER_ROWS)
    ||' b='||substr(t.BETWEEN_ITEMS,1,20)||length(t.BETWEEN_ITEMS)
    ||' b='||substr(t.BEFORE_SUB_LIST,1,20)||length(t.BEFORE_SUB_LIST)
    ||' a='||substr(t.AFTER_SUB_LIST,1,20)||length(t.AFTER_SUB_LIST)
    ||' b='||substr(t.BETWEEN_SUB_LIST_ITEMS,1,20)||length(t.BETWEEN_SUB_LIST_ITEMS)
    component_signature
from WWV_FLOW_LIST_TEMPLATES t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_TEMP_LIST is 'Identifies HTML template markup used to render a List with List Elements'
/

comment on column APEX_APPLICATION_TEMP_LIST.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TEMP_LIST.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TEMP_LIST.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TEMP_LIST.TEMPLATE_NAME is 'Identifies the List template name'
/

comment on column APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_CURRENT is 'HTML or text to be substituted for the selected (or current) list entry'
/

comment on column APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_NONCURRENT is 'HTML or text to be substituted for the non selected (or non-current) list entry'
/

comment on column APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_BEFORE_ROWS is 'HTML that displays before any list elements. You can use this attribute to open an HTML table or HTML table row'
/

comment on column APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_AFTER_ROWS is 'HTML that displays after list elements. You can use this attribute to close an HTML table or HTML table row'
/

comment on column APEX_APPLICATION_TEMP_LIST.BETWEEN_ITEMS is 'HTML that displays between list elements'
/

comment on column APEX_APPLICATION_TEMP_LIST.BEFORE_SUB_LIST is 'HTML that displays before any sub list elements. '
/

comment on column APEX_APPLICATION_TEMP_LIST.AFTER_SUB_LIST is 'HTML that displays after any sub list elements.'
/

comment on column APEX_APPLICATION_TEMP_LIST.BETWEEN_SUB_LIST_ITEMS is 'HTML that displays between sub list elements'
/

comment on column APEX_APPLICATION_TEMP_LIST.SUB_LIST_ITEM_CURRENT is 'HTML or text to be substituted for the selected (or current) sub list entry'
/

comment on column APEX_APPLICATION_TEMP_LIST.SUB_LIST_ITEM_NONCURRENT is 'HTML or text to be substituted for the unselected (or noncurrent) sub list entry'
/

comment on column APEX_APPLICATION_TEMP_LIST.ITEM_TEMPLATE_CURR_W_CHILD is 'HTML or text to be substituted for the selected (or current) sub list template used when an item has sub list entries'
/

comment on column APEX_APPLICATION_TEMP_LIST.ITEM_TEMPLATE_NONCURR_W_CHILD is 'HTML or text to be substituted for the unselected (or noncurrent) list template used when item has sub list items'
/

comment on column APEX_APPLICATION_TEMP_LIST.SUB_TEMPLATE_CURR_W_CHILD is 'HTML or text to be substituted for the selected (or current) sub list template used when an item has sub list entries'
/

comment on column APEX_APPLICATION_TEMP_LIST.SUB_TEMPLATE_NONCURR_W_CHILD is 'HTML or text to be substituted for the unselected (or noncurrent) list template used when item has sub list items'
/

comment on column APEX_APPLICATION_TEMP_LIST.FIRST_LIST_TEMPLATE_NONCURRENT is 'First list template for non current entry template.  Defaults to list template non current.'
/

comment on column APEX_APPLICATION_TEMP_LIST.FIRST_LIST_TEMPLATE_CURRENT is 'First list template for current entry template.  Defaults to list template current.'
/

comment on column APEX_APPLICATION_TEMP_LIST.F_ITEM_TEMPLATE_CURR_W_CHILD is 'First item template for current entry with child'
/

comment on column APEX_APPLICATION_TEMP_LIST.FITEM_TEMPLATE_NONCURR_W_CHILD is 'First item template for non current entry with child'
/

comment on column APEX_APPLICATION_TEMP_LIST.IS_SUBSCRIBED is 'Identifies if this List Template is subscribed from another List Template'
/

comment on column APEX_APPLICATION_TEMP_LIST.SUBSCRIBED_FROM is 'Identifies the master component from which this component is subscribed'
/

comment on column APEX_APPLICATION_TEMP_LIST.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_TEMP_LIST.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TEMP_LIST.THEME_NUMBER is 'Identifies the numeric identifier of this theme to which this template is associated'
/

comment on column APEX_APPLICATION_TEMP_LIST.THEME_CLASS is 'Identifies a specific usage for this template'
/

comment on column APEX_APPLICATION_TEMP_LIST.TRANSLATE_THIS_TEMPLATE is 'Identifies if this template should be translated'
/

comment on column APEX_APPLICATION_TEMP_LIST.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_TEMP_LIST.LIST_TEMPLATE_ID is 'Primary Key of this template'
/

comment on column APEX_APPLICATION_TEMP_LIST.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/


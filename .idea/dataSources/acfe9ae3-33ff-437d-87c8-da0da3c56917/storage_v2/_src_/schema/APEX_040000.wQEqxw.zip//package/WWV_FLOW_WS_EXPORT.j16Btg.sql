create package wwv_flow_ws_export
is

g_mime_shown                 boolean := false;

procedure export (
    p_ws_app_id                   in number,
    p_format                      in varchar2 default 'UNIX',
    p_commit                      in varchar2 default 'YES',
    p_export_datagrid_data        in varchar2 default 'N',
    p_export_datagrid_annotations in varchar2 default 'N',
    p_export_page_annotations     in varchar2 default 'N',
    p_export_public_reports       in varchar2 default 'N',
    p_export_private_reports      in varchar2 default 'N',
    p_export_subscriptions        in varchar2 default 'N'
    );

end wwv_flow_ws_export;
/


create view APEX_APPLICATION_PAGE_DA_ACTS as
select  fa.workspace                                        workspace,
        fa.application_id                                   application_id,
        fa.application_name                                 application_name,
        a.page_id                                           page_id,
        p.name                                              page_name,
        a.event_id                                          dynamic_action_id,
        e.name                                              dynamic_action_name,
        case substr(a.action, 1, 7)
          when 'NATIVE_' then
              ( select display_name from wwv_flow_plugins where flow_id = 4411 and plugin_type = 'DYNAMIC ACTION' and name = substr(a.action, 8) )
          when 'PLUGIN_' then
              ( select display_name from wwv_flow_plugins where flow_id = a.flow_id and plugin_type = 'DYNAMIC ACTION' and name = substr(a.action, 8) )
          else a.action
        end                                                 action_name,
        a.action                                            action_code,
        a.action_sequence                                   action_sequence,
        decode(a.event_result,  'TRUE',     'True',
                                'FALSE',    'False',
                                            a.event_result )                dynamic_action_event_result,
        decode(a.execute_on_page_init,  'Y',    'Yes',
                                        'N',    'No',
                                                a.execute_on_page_init )    execute_on_page_init,
        a.affected_elements                                 affected_elements,
        decode(a.affected_elements_type,
            'ITEM',                 'Item',
            'REGION',               'Region',
            'COLUMN',               'Column',
            'DOM_OBJECT',           'DOM Object',
            'JQUERY_SELECTOR',      'jQuery Selector',
            'TRIGGERING_ELEMENT',   'Triggering Element',
            'EVENT_SOURCE',         'Event Source',
                                a.affected_elements_type)   affected_elements_type,
        nvl((select plug_name
               from wwv_flow_page_plugs
              where id = a.affected_region_id),
            a.affected_region_id)                           affected_region,
        a.affected_region_id                                affected_region_id,
        a.attribute_01                                      attribute_01,
        a.attribute_02                                      attribute_02,
        a.attribute_03                                      attribute_03,
        a.attribute_04                                      attribute_04,
        a.attribute_05                                      attribute_05,
        a.attribute_06                                      attribute_06,
        a.attribute_07                                      attribute_07,
        a.attribute_08                                      attribute_08,
        a.attribute_09                                      attribute_09,
        a.attribute_10                                      attribute_10,
        case when a.stop_execution_on_error = 'Y' then 'Yes' else 'No' end as stop_execution_on_error,
        a.last_updated_by                                   last_updated_by,
        a.last_updated_on                                   last_updated_on,
        a.da_action_comment                                 component_comment,
        a.id                                                action_id,
        'comp signature?'                                   component_signature
  from  wwv_flow_page_da_actions a,
        wwv_flow_page_da_events e,
        wwv_flow_authorized fa,
        wwv_flow_steps p
 where  a.flow_id = fa.application_id
   and  e.id      = a.event_id
   and  p.flow_id = a.flow_id
   and  p.id      = a.page_id
/

comment on table APEX_APPLICATION_PAGE_DA_ACTS is 'Identifies the Actions of a Dynamic Action associated with a Page'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.PAGE_NAME is 'Identifies a page within an application'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.DYNAMIC_ACTION_ID is 'Primary Key of the associated Dynamic Action'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.DYNAMIC_ACTION_NAME is 'Identifies the name of the Dynamic Action that these Actions are associated with'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ACTION_NAME is 'Identifies the name of the Action'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ACTION_CODE is 'Internal code of ACTION_NAME'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ACTION_SEQUENCE is 'Identifies the sequence the Action is executed'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.DYNAMIC_ACTION_EVENT_RESULT is 'Defines when the Action will execute as a result of whether the Dynamic Action When Condition has passed or failed'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.EXECUTE_ON_PAGE_INIT is 'Defines whether the Action will also execute when the page initially loads'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.AFFECTED_ELEMENTS is 'Identifies the element(s) that will be affected by the Action'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.AFFECTED_ELEMENTS_TYPE is 'Identifies the type of selector used for the Affected Element(s)'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.AFFECTED_REGION is 'Identifies the name of the region containing the Affected Element(s)'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.AFFECTED_REGION_ID is 'Identifies the ID of the region containing the Affected Element(s)'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_01 is 'Identifies attribute 01 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_02 is 'Identifies attribute 02 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_03 is 'Identifies attribute 03 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_04 is 'Identifies attribute 04 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_05 is 'Identifies attribute 05 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_06 is 'Identifies attribute 06 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_07 is 'Identifies attribute 07 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_08 is 'Identifies attribute 08 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_09 is 'Identifies attribute 09 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ATTRIBUTE_10 is 'Identifies attribute 10 for Plug-In Actions'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.STOP_EXECUTION_ON_ERROR is 'Defines whether the following Actions are executed in case of an error'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.LAST_UPDATED_BY is 'APEX Developer who made the last update'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.ACTION_ID is 'Primary Key of the Action'
/

comment on column APEX_APPLICATION_PAGE_DA_ACTS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/


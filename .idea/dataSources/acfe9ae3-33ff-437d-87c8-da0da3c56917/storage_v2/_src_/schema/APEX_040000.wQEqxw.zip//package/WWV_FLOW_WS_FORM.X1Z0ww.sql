create package wwv_flow_ws_form
as

procedure show_column_popup (
    p_db_column_name in varchar2,
    p_workspace_id   in number,
    p_worksheet_id   in number);

procedure show_actions (
    p_row_id  in number
    );

procedure show_manage (
    p_row_id  in number
    );

procedure show (
    p_ws_app_id            in number,
    p_worksheet_id         in number,
    p_data_grid_id         in number,
    p_app_user             in varchar2,
    p_row_id               in varchar2 default null,
    p_session              in number   default null,
    p_base_report_id       in number   default null,
    p_partial_page_refresh in boolean,
    p_validation_passed    in varchar2 default 'Y'
    );

end wwv_flow_ws_form;
/


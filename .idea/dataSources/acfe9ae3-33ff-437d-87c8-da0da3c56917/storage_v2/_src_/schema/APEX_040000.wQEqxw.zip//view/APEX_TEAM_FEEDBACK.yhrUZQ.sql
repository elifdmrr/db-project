create view APEX_TEAM_FEEDBACK as
select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
    f.ID                        feedback_id,
    f.deployment_system||
    f.feedback_id               feedback_number,
    f.FEEDBACK_COMMENT          feedback,
    f.FEEDBACK_TYPE             feedback_type,
    f.FEEDBACK_STATUS           feedback_status,
    f.deployment_system         deployment_system,
    --
    f.APPLICATION_ID            application_id,
    f.APPLICATION_NAME          application_name,
    f.APPLICATION_VERSION       application_version,
    f.PAGE_ID                   page_id,
    f.PAGE_NAME                 page_name,
    f.PAGE_LAST_UPDATED_BY      page_last_updated_by,
    f.PAGE_LAST_UPDATED_ON      page_last_updated,
    f.SESSION_ID                logging_session_id,
    f.APEX_USER                 logging_apex_user,
    f.user_email                logging_user_email,
    --
    f.SESSION_STATE,
    f.PARSING_SCHEMA,
    f.screen_width,
    f.screen_height,
    f.HTTP_USER_AGENT,
    f.REMOTE_ADDR,
    f.REMOTE_USER,
    f.HTTP_HOST,
    f.SERVER_NAME,
    f.SERVER_PORT,
    --
    f.LOGGED_BY_WORKSPACE_NAME   logging_workspace_name,
    f.LOGGING_SECURITY_GROUP_ID  logging_workspace_id,
    f.LOGGING_EMAIL,
    --
    f.SESSION_INFO               session_info,
    f.tags                       tags,
    f.DEVELOPER_COMMENT          developer_comment,
    f.public_response            public_response,
    f.BUG_ID                     logged_as_bug_id,
    f.FEATURE_ID                 logged_as_feature_id,
    f.TASK_ID                    logged_as_todo_id,
    --
    f.LABEL_01,
    f.LABEL_02,
    f.LABEL_03,
    f.LABEL_04,
    f.LABEL_05,
    f.LABEL_06,
    f.LABEL_07,
    f.LABEL_08,
    --
    f.ATTRIBUTE_01,
    f.ATTRIBUTE_02,
    f.ATTRIBUTE_03,
    f.ATTRIBUTE_04,
    f.ATTRIBUTE_05,
    f.ATTRIBUTE_06,
    f.ATTRIBUTE_07,
    f.ATTRIBUTE_08,
    --
    f.CREATED_BY,
    f.CREATED_ON,
    f.UPDATED_BY,
    f.UPDATED_ON
from
    wwv_flow_feedback f,
    wwv_flow_companies w
where
    f.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_TEAM_FEEDBACK is 'Identifies user feedback.'
/

comment on column APEX_TEAM_FEEDBACK.WORKSPACE_ID is 'Primary key that identifies the workspace.'
/

comment on column APEX_TEAM_FEEDBACK.WORKSPACE_NAME is 'Name of the current workspace.'
/

comment on column APEX_TEAM_FEEDBACK.FEEDBACK_ID is 'Primary key of the feedback entry.'
/

comment on column APEX_TEAM_FEEDBACK.FEEDBACK_NUMBER is 'External identifier for the feedback entry.'
/

comment on column APEX_TEAM_FEEDBACK.FEEDBACK is 'Comment provided by application user'
/

comment on column APEX_TEAM_FEEDBACK.FEEDBACK_TYPE is 'The type of feedback (identified by the user).'
/

comment on column APEX_TEAM_FEEDBACK.FEEDBACK_STATUS is 'The status of the Feedback as assigned by the reviewing developers.'
/

comment on column APEX_TEAM_FEEDBACK.DEPLOYMENT_SYSTEM is 'Identifies the system where the feedback entry has been created.'
/

comment on column APEX_TEAM_FEEDBACK.APPLICATION_ID is 'Unique identifier of the application the feedback was provided on.'
/

comment on column APEX_TEAM_FEEDBACK.APPLICATION_NAME is 'Name of the application the Feedback was provided on.'
/

comment on column APEX_TEAM_FEEDBACK.APPLICATION_VERSION is 'Version of the application the feedback was provided on.'
/

comment on column APEX_TEAM_FEEDBACK.PAGE_ID is 'Unique identifier of the page within the application that the feedback was provided on.'
/

comment on column APEX_TEAM_FEEDBACK.PAGE_NAME is 'Name of the page within the application that the feedback was provided on.'
/

comment on column APEX_TEAM_FEEDBACK.PAGE_LAST_UPDATED_BY is 'The developer that last updated the referenced page.'
/

comment on column APEX_TEAM_FEEDBACK.PAGE_LAST_UPDATED is 'The date on which the referenced page was last updated.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGING_SESSION_ID is 'The Session ID when the feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGING_APEX_USER is 'Application Express user providing the feedback.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGING_USER_EMAIL is 'Email address of Application Express user providing the feedback.'
/

comment on column APEX_TEAM_FEEDBACK.SESSION_STATE is 'The session state when the feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.PARSING_SCHEMA is 'The parsing schema of the application when the feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.SCREEN_WIDTH is 'Screen width when feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.SCREEN_HEIGHT is 'Screen height when feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.HTTP_USER_AGENT is 'HTTP User Agent where the feedback was provided (can be different that where the feedback is being reviewed).'
/

comment on column APEX_TEAM_FEEDBACK.REMOTE_ADDR is 'Remote Address where the feedback was provided (can be different that where the feedback is being reviewed).'
/

comment on column APEX_TEAM_FEEDBACK.REMOTE_USER is 'Remote User where the feedback was provided.'
/

comment on column APEX_TEAM_FEEDBACK.HTTP_HOST is 'HTTP Host where the feedback was provided (can be different that where the feedback is being reviewed).'
/

comment on column APEX_TEAM_FEEDBACK.SERVER_NAME is 'The name of the server where the feedback was provided (can be different that where the feedback is being reviewed).'
/

comment on column APEX_TEAM_FEEDBACK.SERVER_PORT is 'Server Port where the Feedback was provided (can be different that where the Feedback is being reviewed).'
/

comment on column APEX_TEAM_FEEDBACK.LOGGING_WORKSPACE_NAME is 'Name of workspace where feedbacl was collected.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGING_WORKSPACE_ID is 'Unique identifier of workspace where feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGING_EMAIL is 'Email of user from workspace where feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.SESSION_INFO is 'Session Header from session when feedback was collected.'
/

comment on column APEX_TEAM_FEEDBACK.TAGS is 'Tags associated with the feedback.'
/

comment on column APEX_TEAM_FEEDBACK.DEVELOPER_COMMENT is 'Comments or notes for internal use, not typically viewable by end-users.'
/

comment on column APEX_TEAM_FEEDBACK.PUBLIC_RESPONSE is 'The public response to the feedback.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGED_AS_BUG_ID is 'If feedback resulted in a bug, the unique identifier of the resulting bug.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGED_AS_FEATURE_ID is 'If feedback resulted in a feature, the unique identifier of the resulting feature.'
/

comment on column APEX_TEAM_FEEDBACK.LOGGED_AS_TODO_ID is 'If feedback resulted in a to do, the unique identifier of the resulting to do.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_01 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_02 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_03 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_04 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_05 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_06 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_07 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.LABEL_08 is 'Identifies the label for corresponding attribute.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_01 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_02 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_03 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_04 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_05 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_06 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_07 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.ATTRIBUTE_08 is 'Custom attribute for collecting feedback.'
/

comment on column APEX_TEAM_FEEDBACK.CREATED_BY is 'User that created this feedback.'
/

comment on column APEX_TEAM_FEEDBACK.CREATED_ON is 'Date this feedback was created.'
/

comment on column APEX_TEAM_FEEDBACK.UPDATED_BY is 'Developer who made last update.'
/

comment on column APEX_TEAM_FEEDBACK.UPDATED_ON is 'Date of last update.'
/


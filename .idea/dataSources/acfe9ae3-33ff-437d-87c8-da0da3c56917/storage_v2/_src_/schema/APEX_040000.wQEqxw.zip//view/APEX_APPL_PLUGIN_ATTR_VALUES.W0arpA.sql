create view APEX_APPL_PLUGIN_ATTR_VALUES as
select v.id                 as plugin_attribute_value_id,
       f.workspace,
       f.application_id,
       f.application_name,
       v.plugin_attribute_id,
       a.prompt             as plugin_attribute_prompt,
       v.display_sequence,
       v.display_value,
       v.return_value,
       v.created_by,
       v.created_on,
       v.last_updated_by,
       v.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugin_attr_values v,
       wwv_flow_plugin_attributes a
 where v.flow_id = f.application_id
   and a.id      = v.plugin_attribute_id
/

comment on table APEX_APPL_PLUGIN_ATTR_VALUES is 'Stores the possible values of a plug-in attribute if it''s of type selectlist.'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.PLUGIN_ATTRIBUTE_VALUE_ID is 'Identifies the primary key of this component'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.PLUGIN_ATTRIBUTE_ID is 'Id of the attribute this value is part of'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.PLUGIN_ATTRIBUTE_PROMPT is 'Label of the attribute this value is part of'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.DISPLAY_SEQUENCE is 'Order sequence in which the values are displayed.'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.DISPLAY_VALUE is 'Value displayed to end users'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.RETURN_VALUE is 'Value stored in attribute_xx column.'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.CREATED_BY is 'APEX developer who created the plugin attribute value'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.CREATED_ON is 'Date of creation'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPL_PLUGIN_ATTR_VALUES.LAST_UPDATED_ON is 'Date of last update'
/


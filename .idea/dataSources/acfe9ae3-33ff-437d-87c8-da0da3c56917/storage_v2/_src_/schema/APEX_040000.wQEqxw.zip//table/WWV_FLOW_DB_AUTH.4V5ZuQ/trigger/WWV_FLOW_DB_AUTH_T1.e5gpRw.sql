create trigger WWV_FLOW_DB_AUTH_T1
    before insert or update
    on WWV_FLOW_DB_AUTH
    for each row
begin
    :new.db_auth_schema := upper(:new.db_auth_schema);
end;
/


create TYPE  t_ords_module_privilege UNDER t_ords_metadata_type
   ("MODULE_NAME"    VARCHAR2(255 BYTE), 
    "PRIVILEGE_NAME" VARCHAR2(255 BYTE), 
    CONSTRUCTOR FUNCTION t_ords_module_privilege (
      privilege_name       IN VARCHAR2,
      module_name          IN VARCHAR2 DEFAULT NULL,
      created_on           IN DATE     DEFAULT NULL,
      created_by           IN VARCHAR2 DEFAULT NULL,
      updated_on           IN DATE     DEFAULT NULL,
      updated_by           IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT
   );
/


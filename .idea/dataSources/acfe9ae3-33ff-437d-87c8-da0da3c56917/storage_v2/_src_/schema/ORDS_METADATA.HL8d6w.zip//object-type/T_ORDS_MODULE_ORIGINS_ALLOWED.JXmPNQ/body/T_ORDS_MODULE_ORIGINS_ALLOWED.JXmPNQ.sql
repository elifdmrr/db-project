create TYPE BODY t_ords_module_origins_allowed  IS
  CONSTRUCTOR FUNCTION t_ords_module_origins_allowed (
      origins_allowed      IN VARCHAR2,
      created_on           IN DATE,
      created_by           IN VARCHAR2,
      updated_on           IN DATE,
      updated_by           IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.origins_allowed    := origins_allowed;
    SELF.created_on         := created_on;
    SELF.created_by         := created_by;
    SELF.updated_on         := updated_on;
    SELF.updated_by         := updated_by;
    RETURN;
  END;
END;
/


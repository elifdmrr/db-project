create PACKAGE BODY ORDS_UTIL wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
35 55
p8bGWpGcT0c4qT7Nud+SHMx/k6gwg5m49TOf9b9cuJu/9MOlKMC9SiiyCNLu5uFKr3HiP9Hn
rfbROaY1x5nq

/


create TYPE BODY t_ords_template  IS
  CONSTRUCTOR FUNCTION t_ords_template (
      pattern            IN VARCHAR2,
      priority           IN NUMBER,
      etag_type          IN VARCHAR2,
      etag_query         IN VARCHAR2,
      comments           IN VARCHAR2,
      handler_list       IN t_ords_handler_list,
      created_on         IN DATE,
      created_by         IN VARCHAR2,
      updated_on         IN DATE,
      updated_by         IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.pattern := pattern;
    SELF.priority := priority;
    SELF.etag_type := etag_type;
    SELF.etag_query := etag_query;
    SELF.comments := comments;
    SELF.handler_list := handler_list;
    SELF.created_on := created_on;
    SELF.created_by := created_by;
    SELF.updated_on := updated_on;
    SELF.updated_by := updated_by;
    RETURN;
  END;
  CONSTRUCTOR FUNCTION t_ords_template (
      pattern            IN VARCHAR2,
      priority           IN NUMBER,
      etag_type          IN VARCHAR2,
      etag_query         IN VARCHAR2,
      comments           IN VARCHAR2,
      handler            IN t_ords_handler,
      created_on         IN DATE,
      created_by         IN VARCHAR2,
      updated_on         IN DATE,
      updated_by         IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.pattern := pattern;
    SELF.priority := priority;
    SELF.etag_type := etag_type;
    SELF.etag_query := etag_query;
    SELF.comments := comments;
    IF handler IS NULL THEN
      SELF.handler_list := NULL;
    ELSE
      SELF.handler_list := t_ords_handler_list(handler);
    END IF;
    SELF.created_on := created_on;
    SELF.created_by := created_by;
    SELF.updated_on := updated_on;
    SELF.updated_by := updated_by;
    RETURN;
  END;
END;
/


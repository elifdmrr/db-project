create TYPE BODY t_ords_module  IS
  CONSTRUCTOR FUNCTION t_ords_module (
      name               IN VARCHAR2,
      base_path          IN VARCHAR2,
      items_per_page     IN NUMBER,
      status             IN VARCHAR2,
      comments           IN VARCHAR2,
      template_list      IN t_ords_template_list,
      created_on         IN DATE,
      created_by         IN VARCHAR2,
      updated_on         IN DATE,
      updated_by         IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.name := name;
    SELF.base_path := base_path;
    SELF.items_per_page := items_per_page;
    SELF.status := status;
    SELF.comments := comments;
    SELF.template_list := template_list;
    SELF.created_on := created_on;
    SELF.created_by := created_by;
    SELF.updated_on := updated_on;
    SELF.updated_by := updated_by;
    RETURN;
  END;
  CONSTRUCTOR FUNCTION t_ords_module (
      name               IN VARCHAR2,
      base_path          IN VARCHAR2,
      items_per_page     IN NUMBER,
      status             IN VARCHAR2,
      comments           IN VARCHAR2,
      template           IN t_ords_template,
      created_on         IN DATE,
      created_by         IN VARCHAR2,
      updated_on         IN DATE,
      updated_by         IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.name := name;
    SELF.base_path := base_path;
    SELF.items_per_page := items_per_page;
    SELF.status := status;
    SELF.comments := comments;
    IF template IS NULL THEN
      SELF.template_list := NULL;
    ELSE
      SELF.template_list := t_ords_template_list(template);
    END IF;
    SELF.created_on := created_on;
    SELF.created_by := created_by;
    SELF.updated_on := updated_on;
    SELF.updated_by := updated_by;
    RETURN;
  END;
END;
/


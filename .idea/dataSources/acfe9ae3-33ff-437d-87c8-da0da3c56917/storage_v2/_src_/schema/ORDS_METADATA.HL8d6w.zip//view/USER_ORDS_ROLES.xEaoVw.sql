create view USER_ORDS_ROLES as
SELECT sec_roles.id,
  sec_roles.name,
  sec_roles.created_by,
  sec_roles.created_on,
  sec_roles.updated_by,
  sec_roles.updated_on,
  sec_roles.schema_id
FROM sec_roles,
  ords_schemas
WHERE sec_roles.schema_id      IN (ords_schemas.id, 10)
AND nlssort(ords_schemas.parsing_schema,'NLS_SORT=BINARY') = nlssort(sys_context('USERENV', 'CURRENT_USER'),'NLS_SORT=BINARY')
/


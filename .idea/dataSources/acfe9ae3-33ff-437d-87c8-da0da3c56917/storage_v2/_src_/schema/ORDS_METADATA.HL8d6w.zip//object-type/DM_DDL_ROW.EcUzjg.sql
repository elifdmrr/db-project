create TYPE DM_DDL_ROW 
    UNDER DM_DDL_DESC ( 
        DDL CLOB 
    ) NOT FINAL 
;
/


create TYPE BODY t_ords_handler  IS
  CONSTRUCTOR FUNCTION t_ords_handler (
      method             IN VARCHAR2,
      source_type        IN VARCHAR2,
      source             IN CLOB,
      items_per_page     IN NUMBER,
      mimes_allowed      IN VARCHAR2,
      comments           IN VARCHAR2,
      parameter_list     IN t_ords_parameter_list,
      created_on         IN DATE,
      created_by         IN VARCHAR2,
      updated_on         IN DATE,
      updated_by         IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.method            := method;
    SELF.source_type       := source_type;
    SELF.source            := source;
    SELF.items_per_page    := items_per_page;
    SELF.mimes_allowed     := mimes_allowed;
    SELF.parameter_list    := parameter_list;
    SELF.comments          := comments;
    SELF.created_on        := created_on;
    SELF.created_by        := created_by;
    SELF.updated_on        := updated_on;
    SELF.updated_by        := updated_by;
    RETURN;
  END;
  CONSTRUCTOR FUNCTION t_ords_handler (
      method             IN VARCHAR2,
      source_type        IN VARCHAR2,
      source             IN CLOB,
      items_per_page     IN NUMBER,
      mimes_allowed      IN VARCHAR2,
      comments           IN VARCHAR2,
      parameter          IN t_ords_parameter,
      created_on         IN DATE,
      created_by         IN VARCHAR2,
      updated_on         IN DATE,
      updated_by         IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.method            := method;
    SELF.source_type       := source_type;
    SELF.source            := source;
    SELF.items_per_page    := items_per_page;
    SELF.mimes_allowed     := mimes_allowed;
    IF parameter IS NULL THEN
      SELF.parameter_list := NULL;
    ELSE
      SELF.parameter_list := t_ords_parameter_list(parameter);
    END IF;
    SELF.comments          := comments;
    SELF.created_on        := created_on;
    SELF.created_by        := created_by;
    SELF.updated_on        := updated_on;
    SELF.updated_by        := updated_by;
    RETURN;
  END;
END;
/


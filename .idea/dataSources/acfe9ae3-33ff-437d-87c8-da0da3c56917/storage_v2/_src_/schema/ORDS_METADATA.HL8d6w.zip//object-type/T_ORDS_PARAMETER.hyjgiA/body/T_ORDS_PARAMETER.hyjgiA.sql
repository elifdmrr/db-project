create TYPE BODY t_ords_parameter  IS
  CONSTRUCTOR FUNCTION t_ords_parameter (
      name                 IN VARCHAR2,
      bind_variable_name   IN VARCHAR2,
      source_type          IN VARCHAR2,
      param_type           IN VARCHAR2,
      access_method        IN VARCHAR2,
      comments             IN VARCHAR2,
      created_on           IN DATE,
      created_by           IN VARCHAR2,
      updated_on           IN DATE,
      updated_by           IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.name               := name;
    SELF.bind_variable_name := bind_variable_name;
    SELF.source_type        := source_type;
    SELF.param_type         := param_type;
    SELF.access_method      := access_method;
    SELF.comments           := comments;
    SELF.created_on         := created_on;
    SELF.created_by         := created_by;
    SELF.updated_on         := updated_on;
    SELF.updated_by         := updated_by;
    RETURN;
  END;
END;
/


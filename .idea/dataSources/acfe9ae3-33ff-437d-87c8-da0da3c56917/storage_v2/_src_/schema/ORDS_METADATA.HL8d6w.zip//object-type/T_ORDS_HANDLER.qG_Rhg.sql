create TYPE  t_ords_handler UNDER t_ords_metadata_type
   ("SOURCE_TYPE"    VARCHAR2(30 BYTE), 
    "METHOD"         VARCHAR2(10 BYTE), 
    "MIMES_ALLOWED"  VARCHAR2(255 BYTE), 
    "ITEMS_PER_PAGE" NUMBER, 
    "SOURCE"         CLOB, 
    "PARAMETER_LIST" t_ords_parameter_list, 
    CONSTRUCTOR FUNCTION t_ords_handler (
      method             IN VARCHAR2 DEFAULT 'GET',
      source_type        IN VARCHAR2 DEFAULT 'json/collection',
      source             IN CLOB,
      items_per_page     IN NUMBER   DEFAULT NULL,
      mimes_allowed      IN VARCHAR2 DEFAULT NULL,
      comments           IN VARCHAR2 DEFAULT NULL,
      parameter_list     IN t_ords_parameter_list,
      created_on         IN DATE     DEFAULT NULL,
      created_by         IN VARCHAR2 DEFAULT NULL,
      updated_on         IN DATE     DEFAULT NULL,
      updated_by         IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT,
    CONSTRUCTOR FUNCTION t_ords_handler (
      method             IN VARCHAR2 DEFAULT 'GET',
      source_type        IN VARCHAR2 DEFAULT 'json/collection',
      source             IN CLOB,
      items_per_page     IN NUMBER   DEFAULT NULL,
      mimes_allowed      IN VARCHAR2 DEFAULT NULL,
      comments           IN VARCHAR2 DEFAULT NULL,
      parameter          IN t_ords_parameter DEFAULT NULL,
      created_on         IN DATE     DEFAULT NULL,
      created_by         IN VARCHAR2 DEFAULT NULL,
      updated_on         IN DATE     DEFAULT NULL,
      updated_by         IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT
   );
/


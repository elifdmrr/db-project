create view USER_ORDS_CLIENT_ROLES as
SELECT ORDS_CLIENT_ROLES.client_id,
  ORDS_CLIENT_ROLES.client_name,
  ORDS_CLIENT_ROLES.role_id,
  ORDS_CLIENT_ROLES.role_name
FROM ORDS_CLIENT_ROLES,
  ords_schemas
WHERE ords_schemas.id           = ORDS_CLIENT_ROLES.schema_id
AND nlssort(ords_schemas.parsing_schema,'NLS_SORT=BINARY') = nlssort(sys_context('USERENV', 'CURRENT_USER'),'NLS_SORT=BINARY')
/


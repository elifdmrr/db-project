create TYPE  t_ords_module_origins_allowed UNDER t_ords_metadata_type
   ("ORIGINS_ALLOWED" VARCHAR2(4000 BYTE), 
    CONSTRUCTOR FUNCTION t_ords_module_origins_allowed (
      origins_allowed      IN VARCHAR2,
      created_on           IN DATE     DEFAULT NULL,
      created_by           IN VARCHAR2 DEFAULT NULL,
      updated_on           IN DATE     DEFAULT NULL,
      updated_by           IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT
   );
/


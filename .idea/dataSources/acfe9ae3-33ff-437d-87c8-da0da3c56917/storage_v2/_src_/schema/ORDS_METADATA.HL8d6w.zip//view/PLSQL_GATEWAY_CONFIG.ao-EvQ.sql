create view PLSQL_GATEWAY_CONFIG as
SELECT
    runtime_user,
    plsql_gateway_user,
    comments,
    created_by,
    created_on,
    updated_by,
    updated_on
FROM
    cfg_plsql_gateways
/


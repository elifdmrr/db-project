create view UNIFIED_POOL_CONFIG as
SELECT /*+NO_NATIVE_FULL_OUTER_JOIN*/
    CASE
      WHEN o.workspace_identifier is not null and a.workspace_identifier is not null THEN 'BOTH'
      WHEN o.workspace_identifier is null THEN 'APEX'
      WHEN a.workspace_identifier is null and o.workspace_identifier is not null THEN 'ORDS'
    END schema_type,
    NULL pool_name,
    NVL(a.schema_name,o.workspace_identifier) schema_name,
    a.workspace_name workspace_name,
    NVL(o.workspace_identifier,a.workspace_identifier) workspace_identifier,
    NVL(o.type,a.type) type,
    NVL(o.uri,a.uri) uri,
    NVL(o.updated,a.updated) updated,
    a.tenant_id,
    o.enc_key,
    o.mac_key
  FROM ORDS_METADATA.POOL_CONFIG o
       FULL JOIN ORDS_METADATA.APEX_WWV_FLOW_POOL_CONFIG a
  ON o.workspace_identifier = a.workspace_identifier AND o.uri = a.uri
/


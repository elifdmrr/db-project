create view USER_ORDS_SCHEMAS as
SELECT ords_schemas.id,
  ords_schemas.parsing_schema,
  ords_url_mappings.type,
  ords_url_mappings.pattern,
  ords_schemas.status,
  ords_schemas.auto_rest_auth,
  ords_schemas.ops_allowed,
  ords_schemas.pre_hook
FROM ords_url_mappings,
  ords_schemas
WHERE ords_url_mappings.id      = ords_schemas.url_mapping_id
AND nlssort(ords_schemas.parsing_schema,'NLS_SORT=BINARY') = nlssort(sys_context('USERENV', 'CURRENT_USER'),'NLS_SORT=BINARY')
/


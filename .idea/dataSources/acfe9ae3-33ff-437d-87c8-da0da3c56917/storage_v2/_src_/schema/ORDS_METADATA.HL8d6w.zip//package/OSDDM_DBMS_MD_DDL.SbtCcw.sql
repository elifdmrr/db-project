create PACKAGE OSDDM_DBMS_MD_DDL AUTHID CURRENT_USER
AS
  /*
  returns table (dm_ddl_tab) with description of each object and DDL for that
   object (dm_ddl_row)
  schema  - schema name need to be provided - 'HR'
  ftables      - tables
  fviews       - views
  fmviews      - materialized views
  fmvlog       - materialized view logs
  ftypes       - types - object and collection types
  ffunc        - functions
  fproc        - procedures
  fpack        VARCHAR2 DEFAULT 'true',
  fseq         VARCHAR2 DEFAULT 'true',
  fsyn         VARCHAR2 DEFAULT 'true',
  fpsyn        VARCHAR2 DEFAULT 'true',
  fdim         VARCHAR2 DEFAULT 'true',
  fclust       VARCHAR2 DEFAULT 'true',
  fstorage     VARCHAR2 DEFAULT 'false',
  fpartitions  VARCHAR2 DEFAULT 'false',
  fcomments    VARCHAR2 DEFAULT 'false',
  findexes     VARCHAR2 DEFAULT 'true',
  fconstraints VARCHAR2 DEFAULT 'true',
  fobj_grants  VARCHAR2 DEFAULT 'false',
  ftriggers    VARCHAR2 DEFAULT 'false')
  */
  FUNCTION get_md_schema_ddl(
      schema       VARCHAR2 DEFAULT NULL,
      ftables      VARCHAR2 DEFAULT 'true',
      fviews       VARCHAR2 DEFAULT 'true',
      fmviews      VARCHAR2 DEFAULT 'true',
      fmvlog       VARCHAR2 DEFAULT 'true',
      ftypes       VARCHAR2 DEFAULT 'true',
      ffunc        VARCHAR2 DEFAULT 'true',
      fproc        VARCHAR2 DEFAULT 'true',
      fpack        VARCHAR2 DEFAULT 'true',
      fseq         VARCHAR2 DEFAULT 'true',
      fsyn         VARCHAR2 DEFAULT 'true',
      fpsyn        VARCHAR2 DEFAULT 'true',
      fdim         VARCHAR2 DEFAULT 'true',
      fclust       VARCHAR2 DEFAULT 'true',
      fstorage     VARCHAR2 DEFAULT 'false',
      fpartitions  VARCHAR2 DEFAULT 'false',
      fcomments    VARCHAR2 DEFAULT 'false',
      findexes     VARCHAR2 DEFAULT 'true',
      fconstraints VARCHAR2 DEFAULT 'true',
      fobj_grants  VARCHAR2 DEFAULT 'false',
      fschema  VARCHAR2 DEFAULT 'true',
      fbytesize  VARCHAR2 DEFAULT 'false',
      ftriggers    VARCHAR2 DEFAULT 'false',
      all_dependent    VARCHAR2 DEFAULT 'false')
    RETURN DM_DDL_TAB pipelined ;
    ---
 FUNCTION get_md_object_ddl(
    oschema   VARCHAR2 ,
	otype         VARCHAR2 ,
    oname         VARCHAR2 ,
    fsyn          VARCHAR2 DEFAULT 'true',
    fpsyn        VARCHAR2 DEFAULT 'true',
    fstorage     VARCHAR2 DEFAULT 'true',
    fpartitions  VARCHAR2 DEFAULT 'true',
    fcomments    VARCHAR2 DEFAULT 'true',
    findexes     VARCHAR2 DEFAULT 'true',
    fconstraints VARCHAR2 DEFAULT 'true',
    fobj_grants  VARCHAR2 DEFAULT 'true',
    fschema      VARCHAR2 DEFAULT 'true',
    fbytesize    VARCHAR2 DEFAULT 'false',
    ftriggers     VARCHAR2 DEFAULT 'true')
  RETURN DM_DDL_TAB pipelined;
  ---
  FUNCTION get_md_tables_views_ddl(
      inschema       VARCHAR2 DEFAULT NULL,
      tables       DM_VARCHAR_TABLE DEFAULT NULL,
      tviews       DM_VARCHAR_TABLE DEFAULT NULL,
      ftables      VARCHAR2 DEFAULT 'true',
      fviews       VARCHAR2 DEFAULT 'true',
      fstorage     VARCHAR2 DEFAULT 'false',
      fpartitions  VARCHAR2 DEFAULT 'false',
      fcomments    VARCHAR2 DEFAULT 'false',
      findexes     VARCHAR2 DEFAULT 'true',
      fconstraints VARCHAR2 DEFAULT 'true',
      ftypes       VARCHAR2 DEFAULT 'false',
      fobj_grants  VARCHAR2 DEFAULT 'false',
      fschema  VARCHAR2 DEFAULT 'true', 
      fbytesize  VARCHAR2 DEFAULT 'false',
      ftriggers    VARCHAR2 DEFAULT 'false')
    RETURN dm_ddl_tab pipelined ;
END OSDDM_DBMS_MD_DDL;
/


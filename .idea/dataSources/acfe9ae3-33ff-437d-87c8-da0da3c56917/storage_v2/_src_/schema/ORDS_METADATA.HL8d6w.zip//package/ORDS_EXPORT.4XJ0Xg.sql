create PACKAGE ords_export AUTHID current_user AS 
----------------------------------------------------------------------
-- EXPORT_MODULE
----------------------------------------------------------------------
/**
 * Generates the code necessary to reproduce a module and all children using the ORDS API's.
 * The generated script includes Roles and Privileges associated with the selected module.
 *
 * @param p_module_name The module name for which to generate code.
 * @param p_include_enable_schema Dictates whether the enable_schema call will be included in the export. (DEFAULT TRUE)
 * @param p_include_privs Dictats whether Privs will be included in the export. (DEFAULT TRUE)
 * @returns CLOB datatype containing the script text.
 */
    FUNCTION export_module (
        p_module_name             IN VARCHAR2,
        p_include_enable_schema   IN BOOLEAN ,
        p_include_privs           IN BOOLEAN 
    ) RETURN CLOB;

----------------------------------------------------------------------
-- EXPORT_MODULE
----------------------------------------------------------------------
/**
 * Generates the code necessary to reproduce a module and all children using the ORDS API's.
 * The generated script includes Roles and Privileges associated with the selected module.
 *
 * @param p_module_name The module name for which to generate code.
 * @returns CLOB datatype containing the script text.
 */

    FUNCTION export_module (
        p_module_name IN VARCHAR2
    ) RETURN CLOB;

----------------------------------------------------------------------
-- EXPORT_ALL_MODULES
----------------------------------------------------------------------
/**
 * Generates the code necessary to reproduce all modules and children using the ORDS API's.
 * The generated script includes all Roles and Privileges associated with the exported modules.
 *
 * @param p_include_enable_schema Dictates whether the enable_schema call will be included in the export. (DEFAULT TRUE)
 * @param p_include_privs Dictats whether Privs will be included in the export. (DEFAULT TRUE)
 * @returns CLOB datatype containing the script text.
 */

    FUNCTION export_schema (
        p_include_enable_schema   IN BOOLEAN ,
        p_include_privs           IN BOOLEAN 
    ) RETURN CLOB;

----------------------------------------------------------------------
-- EXPORT_ALL_MODULES
----------------------------------------------------------------------
/**
 * Generates the code necessary to reproduce all modules and children using the ORDS API's.
 * The generated script includes all Roles and Privileges associated with the exported modules.
 *
 * @returns CLOB datatype containing the script text.
 */

    FUNCTION export_schema RETURN CLOB;

END ords_export;
/


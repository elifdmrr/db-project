create trigger ORDS_OBJECTS_TRG
    before insert or update
    on ORDS_OBJECTS
    for each row
begin
  if inserting then
    if :new.id is null then 
      -- :new.id := ords_id_seq.nextval;  -- supports only 11g and later releases
      -- 10g support for assignment of sequenceName.nextval
      select ords_id_seq.nextval into :new.id from sys.dual;   
    end if;
    -- Populated creation audit
    if :new.created_on is null then
      if :new.updated_on is null then
        :new.created_on := sysdate;
      else
        :new.created_on := :new.updated_on;
      end if;
    end if;
    if :new.created_by is null then
      if :new.updated_by is null then
        :new.created_by := sys_context('USERENV','SESSION_USER');
      else
        :new.created_by := :new.updated_by;
      end if;
    end if;
    -- Populated update audit
    if :new.updated_on is null then
      :new.updated_on := :new.created_on;
    end if;
    if :new.updated_by is null then
      :new.updated_by := :new.created_by;
    end if;
  else 
    case
      -- Updating via PL/SQL API
      when :new.updated_on is null or :new.updated_by is null or 
           :new.created_on is null or :new.created_by is null then
        case
          -- Creation being patched - e.g. import
          when :new.updated_on is null and :new.updated_by is null and 
               :new.created_on is not null and :new.created_by is not null then
            :new.updated_on := :new.created_on;
            :new.updated_by := :new.created_by;
          -- Audit being patched
          when :new.created_on is not null or :new.created_by is not null then
            if :new.updated_on is null then
              :new.updated_on := :old.updated_on;
            end if;
            if :new.updated_by is null then
              :new.updated_by := :old.updated_by;
            end if;
          -- Not patching audit - evolve update audit
          else
            null;
        end case;
        -- Evolve update audit and bring old values forward
        if :new.updated_on is null then
          :new.updated_on := sysdate;
        end if;
        if :new.updated_by is null then
          :new.updated_by := sys_context('USERENV','SESSION_USER');
        end if;
        if :new.created_on is null then
          :new.created_on := :old.created_on;
        end if;
        if :new.created_by is null then
          :new.created_by := :old.created_by;
        end if;
      -- Updating via SQL
      else
        case
          -- Creation audit not changed so evolve update audit
          when :new.created_on = :old.created_on and
               :new.created_by = :old.created_by then
            if :new.updated_on = :old.updated_on then
              :new.updated_on := sysdate;
            end if;
            if :new.updated_by = :old.updated_by then
              :new.updated_by := sys_context('USERENV','SESSION_USER');
            end if;
          -- Patching audit so accept what is given
          else
            null;
        end case;
    end case;
  end if;
end;
/


create PACKAGE               ORDS_CONSTANTS AUTHID definer
AS
/**  Copyright (c) Oracle Corporation 2014. All Rights Reserved.
 * 
 *     NAME
 *       ords_constants.pls
 * 
 *     DESCRIPTION
 *       This package declares immutable utility methods
 * 
 *     MODIFIED    (MM/DD/YYYY)
 *      dwhittin    06/10/2020 - created.
 */

-- ORDS API Constants

  source_type_query           CONSTANT ords_handlers.source_type%type := 'json/query';
  source_type_csv_query       CONSTANT ords_handlers.source_type%type := 'csv/query'; 
  source_type_query_one_row   CONSTANT ords_handlers.source_type%type := 'json/query;type=single'; 
  source_type_feed            CONSTANT ords_handlers.source_type%type := 'json/query;type=feed'; 
  source_type_media           CONSTANT ords_handlers.source_type%type := 'resource/lob'; 
  source_type_plsql           CONSTANT ords_handlers.source_type%type := 'plsql/block'; 
  source_type_collection_feed CONSTANT ords_handlers.source_type%type := 'json/collection'; 
  source_type_collection_item CONSTANT ords_handlers.source_type%type := 'json/item'; 
END ORDS_CONSTANTS;
/


create view DBA_ORDS_URL_MAPPINGS as
SELECT
    ords_url_mappings.id,
    ords_url_mappings.pattern,
    ords_url_mappings.type,
    ords_url_mappings.updated_on,
    ords_url_mappings.updated_by,
    ords_url_mappings.created_on,
    ords_url_mappings.created_by
FROM
    ords_url_mappings
WHERE
    ords_url_mappings.id <> 10
/


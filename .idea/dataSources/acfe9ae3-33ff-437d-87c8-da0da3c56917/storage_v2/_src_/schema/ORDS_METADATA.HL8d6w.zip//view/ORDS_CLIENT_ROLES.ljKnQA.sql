create view ORDS_CLIENT_ROLES as
SELECT oauth_clients.id client_id,
  oauth_clients.name client_name,
  sec_roles.id                AS role_id,
  sec_roles.name              AS role_name,
  ords_schemas.id             AS schema_id,
  ords_schemas.parsing_schema AS schema_name
FROM oauth_client_roles,
  oauth_clients,
  sec_roles,
  ords_schemas
WHERE oauth_clients.id = oauth_client_roles.client_id
AND sec_roles.id       = oauth_client_roles.role_id
AND ords_schemas.id    = oauth_client_roles.schema_id
AND ords_schemas.id    = oauth_clients.schema_id
AND ords_schemas.id    = sec_roles.schema_id
/


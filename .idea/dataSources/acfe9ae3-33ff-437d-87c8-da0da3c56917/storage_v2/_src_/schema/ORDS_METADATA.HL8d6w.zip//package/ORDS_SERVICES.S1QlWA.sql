create PACKAGE ords_services AUTHID current_user
IS
-- Procedures

  PROCEDURE create_service(
      p_module_name       IN ords_modules.name%type ,
      p_uri_prefix        IN ords_modules.uri_prefix%type,
      p_uri_template      IN ords_templates.uri_template%type ,
      p_priority          IN ords_templates.priority%type DEFAULT 0,
      p_method            IN ords_handlers.method%type DEFAULT 'GET',
      p_source_type       IN ords_handlers.source_type%type DEFAULT ords.source_type_collection_feed,
      p_source            IN ords_handlers.source%type ,
      p_items_per_page    IN ords_modules.items_per_page%type DEFAULT 25,
      p_status            IN ords_modules.status%type DEFAULT 'PUBLISHED',
      p_etag_type         IN ords_templates.etag_type%type DEFAULT 'HASH',
      p_etag_query        IN ords_templates.etag_query%type DEFAULT NULL ,
      p_mimes_allowed     IN ords_handlers.mimes_allowed%type DEFAULT NULL ,
      p_module_comments   IN ords_modules.comments%type DEFAULT NULL,
      p_template_comments IN ords_modules.comments%type DEFAULT NULL,
      p_handler_comments  IN ords_modules.comments%type DEFAULT NULL );

  PROCEDURE define_service(
      p_module_name       IN ords_modules.name%type ,
      p_base_path         IN ords_modules.uri_prefix%type,
      p_pattern           IN ords_templates.uri_template%type ,
      p_priority          IN ords_templates.priority%type DEFAULT 0,
      p_method            IN ords_handlers.method%type DEFAULT 'GET',
      p_source_type       IN ords_handlers.source_type%type DEFAULT ords.source_type_collection_feed,
      p_source            IN ords_handlers.source%type ,
      p_items_per_page    IN ords_modules.items_per_page%type DEFAULT 25,
      p_status            IN ords_modules.status%type DEFAULT 'PUBLISHED',
      p_etag_type         IN ords_templates.etag_type%type DEFAULT 'HASH',
      p_etag_query        IN ords_templates.etag_query%type DEFAULT NULL ,
      p_mimes_allowed     IN ords_handlers.mimes_allowed%type DEFAULT NULL ,
      p_module_comments   IN ords_modules.comments%type DEFAULT NULL,
      p_template_comments IN ords_modules.comments%type DEFAULT NULL,
      p_handler_comments  IN ords_modules.comments%type DEFAULT NULL,
      p_create_only       IN BOOLEAN DEFAULT FALSE);

  FUNCTION create_module(
      p_name           IN ords_modules.name%type ,
      p_uri_prefix     IN ords_modules.uri_prefix%type,
      p_items_per_page IN ords_modules.items_per_page%type DEFAULT 25,
      p_status         IN ords_modules.status%type DEFAULT 'PUBLISHED',
      p_comments       IN ords_modules.comments%type DEFAULT NULL)
    RETURN ords_modules.id%type;

  FUNCTION create_module(
      p_module             IN T_ORDS_MODULE)
    RETURN ords_modules.id%type;

  FUNCTION create_module(
      p_metadata           IN T_ORDS_METADATA_TYPE_LIST,
      p_allow_security     IN BOOLEAN DEFAULT TRUE)
    RETURN ords_modules.id%type;

  FUNCTION define_module(
      p_name           IN ords_modules.name%type ,
      p_base_path      IN ords_modules.uri_prefix%type,
      p_items_per_page IN ords_modules.items_per_page%type DEFAULT 25,
      p_status         IN ords_modules.status%type DEFAULT 'PUBLISHED',
      p_comments       IN ords_modules.comments%type DEFAULT NULL,
      p_create_only        IN BOOLEAN DEFAULT FALSE)
    RETURN ords_modules.id%type;

  FUNCTION define_module(
      p_module             IN T_ORDS_MODULE,
      p_create_only        IN BOOLEAN DEFAULT FALSE)
    RETURN ords_modules.id%type;

  FUNCTION define_module(
      p_metadata           IN T_ORDS_METADATA_TYPE_LIST,
      p_allow_security     IN BOOLEAN DEFAULT TRUE,
      p_create_only        IN BOOLEAN DEFAULT FALSE)
    RETURN ords_modules.id%type;

  PROCEDURE define_modules(
      p_module_ids     IN OUT NOCOPY T_ORDS_NUM_TAB,
      p_metadata           IN T_ORDS_METADATA_TYPE_LIST,
      p_allow_security     IN BOOLEAN DEFAULT TRUE,
      p_create_only        IN BOOLEAN DEFAULT FALSE,
      p_allow_multiple     IN BOOLEAN DEFAULT TRUE);

  PROCEDURE update_module(
      p_id             IN ords_modules.id%type,
      p_name           IN ords_modules.name%type ,
      p_uri_prefix     IN ords_modules.uri_prefix%type DEFAULT '',
      p_items_per_page IN ords_modules.items_per_page%type,
      p_status         IN ords_modules.status%type ,
      p_comments       IN ords_modules.comments%type DEFAULT NULL);

  PROCEDURE update_module(
      p_id             IN ords_modules.id%type,
      p_module             IN T_ORDS_MODULE);

  PROCEDURE update_module(
      p_id                 IN ords_modules.id%type,
      p_metadata           IN T_ORDS_METADATA_TYPE_LIST,
      p_allow_security     IN BOOLEAN DEFAULT TRUE);

  PROCEDURE publish_module(
      p_id             IN ords_modules.id%type,
      p_status             IN ords_modules.status%type DEFAULT 'PUBLISHED');

  PROCEDURE delete_module(
      p_name IN ords_modules.name%type);

  PROCEDURE delete_module(
      p_id IN ords_modules.id%type);

  FUNCTION add_template(
      p_module_id    IN ords_templates.module_id%type,
      p_uri_template IN ords_templates.uri_template%type ,
      p_priority     IN ords_templates.priority%type DEFAULT 0,
      p_etag_type    IN ords_templates.etag_type%type DEFAULT 'HASH',
      p_etag_query   IN ords_templates.etag_query%type DEFAULT NULL ,
      p_comments     IN ords_templates.comments%type DEFAULT NULL)
    RETURN ords_templates.id%type;

  FUNCTION define_template(
      p_module_id    IN ords_templates.module_id%type,
      p_pattern      IN ords_templates.uri_template%type ,
      p_priority     IN ords_templates.priority%type DEFAULT 0,
      p_etag_type    IN ords_templates.etag_type%type DEFAULT 'HASH',
      p_etag_query   IN ords_templates.etag_query%type DEFAULT NULL ,
      p_comments     IN ords_templates.comments%type DEFAULT NULL)
    RETURN ords_templates.id%type;

  PROCEDURE update_template(
      p_id           IN ords_templates.id%type,
      p_pattern      IN ords_templates.uri_template%type,
      p_priority     IN ords_templates.priority%type,
      p_etag_type    IN ords_templates.etag_type%type,
      p_etag_query   IN ords_templates.etag_query%type,
      p_comments     IN ords_templates.comments%type);

  PROCEDURE delete_template(
      p_id IN ords_templates.id%type);

  PROCEDURE delete_templates(
      p_module_id IN ords_modules.id%type);

  FUNCTION add_handler(
      p_template_id    IN ords_handlers.template_id%type ,
      p_source_type    IN ords_handlers.source_type%type DEFAULT ords.source_type_collection_feed,
      p_source         IN ords_handlers.source%type ,
      p_method         IN ords_handlers.method%type DEFAULT 'GET',
      p_items_per_page IN ords_handlers.items_per_page%type DEFAULT NULL ,
      p_mimes_allowed  IN ords_handlers.mimes_allowed%type DEFAULT NULL ,
      p_comments       IN ords_handlers.comments%type DEFAULT NULL )
    RETURN ords_handlers.id%type;

  FUNCTION define_handler(
      p_template_id    IN ords_handlers.template_id%type ,
      p_source_type    IN ords_handlers.source_type%type DEFAULT ords.source_type_collection_feed,
      p_source         IN ords_handlers.source%type ,
      p_method         IN ords_handlers.method%type DEFAULT 'GET',
      p_items_per_page IN ords_handlers.items_per_page%type DEFAULT NULL ,
      p_mimes_allowed  IN ords_handlers.mimes_allowed%type DEFAULT NULL ,
      p_comments       IN ords_handlers.comments%type DEFAULT NULL )
    RETURN ords_handlers.id%type;

  PROCEDURE update_handler(
      p_id             IN ords_handlers.id%type,
      p_source_type    IN ords_handlers.source_type%type,
      p_source         IN ords_handlers.source%type,
      p_method         IN ords_handlers.method%type,
      p_items_per_page IN ords_handlers.items_per_page%type,
      p_mimes_allowed  IN ords_handlers.mimes_allowed%type,
      p_comments       IN ords_handlers.comments%type);

  PROCEDURE delete_handler(
      p_id IN ords_handlers.id%type);

  PROCEDURE delete_handlers(
      p_template_id IN ords_templates.id%type);

  FUNCTION add_parameter(
      p_handler_id         IN ords_parameters.handler_id%type ,
      p_name               IN ords_parameters.name%type ,
      p_bind_variable_name IN ords_parameters.bind_variable_name%type DEFAULT NULL ,
      p_source_type        IN ords_parameters.source_type%type DEFAULT 'HEADER',
      p_param_type         IN ords_parameters.param_type%type DEFAULT 'STRING',
      p_access_method      IN ords_parameters.access_method%type DEFAULT 'IN',
      p_comments           IN ords_parameters.comments%type DEFAULT NULL )
    RETURN ords_parameters.id%type;

  FUNCTION define_parameter(
      p_handler_id         IN ords_parameters.handler_id%type ,
      p_name               IN ords_parameters.name%type ,
      p_bind_variable_name IN ords_parameters.bind_variable_name%type DEFAULT NULL ,
      p_source_type        IN ords_parameters.source_type%type DEFAULT 'HEADER',
      p_param_type         IN ords_parameters.param_type%type DEFAULT 'STRING',
      p_access_method      IN ords_parameters.access_method%type DEFAULT 'IN',
      p_comments           IN ords_parameters.comments%type DEFAULT NULL )
    RETURN ords_parameters.id%type;

  PROCEDURE update_parameter(
      p_id                 IN ords_parameters.id%type,
      p_name               IN ords_parameters.name%type,
      p_bind_variable_name IN ords_parameters.bind_variable_name%type,
      p_source_type        IN ords_parameters.source_type%type,
      p_param_type         IN ords_parameters.param_type%type,
      p_access_method      IN ords_parameters.access_method%type,
      p_comments           IN ords_parameters.comments%type);

  PROCEDURE delete_parameter(
      p_id IN ords_parameters.id%type);

  PROCEDURE delete_parameters(
      p_handler_id IN ords_handlers.id%type);

  -- Privileges

  FUNCTION create_privilege(
      p_name        IN sec_privileges.name%type,
      p_label       IN sec_privileges.label%type,
      p_description IN sec_privileges.description%type DEFAULT NULL,
      p_roles       IN owa.vc_arr,
      p_modules     IN owa.vc_arr,
      p_patterns    IN owa.vc_arr,
      p_comments    IN sec_privileges.comments%type DEFAULT NULL)
    RETURN sec_privileges.id%type;

  FUNCTION define_privilege(
      p_name        IN sec_privileges.name%type,
      p_label       IN sec_privileges.label%type,
      p_description IN sec_privileges.description%type DEFAULT NULL,
      p_roles       IN owa.vc_arr,
      p_modules     IN owa.vc_arr,
      p_patterns    IN owa.vc_arr,
      p_comments    IN sec_privileges.comments%type DEFAULT NULL)
    RETURN sec_privileges.id%type;

  FUNCTION define_privilege(
      p_name        IN sec_privileges.name%type,
      p_label       IN sec_privileges.label%type,
      p_description IN sec_privileges.description%type DEFAULT NULL,
      p_roles       IN owa.vc_arr,
      p_patterns    IN owa.vc_arr,
      p_comments    IN sec_privileges.comments%type DEFAULT NULL)
    RETURN sec_privileges.id%type;

  PROCEDURE update_privilege(
      p_id          IN sec_privileges.id%type,
      p_name        IN sec_privileges.name%type,
      p_label       IN sec_privileges.label%type,
      p_description IN sec_privileges.description%type DEFAULT NULL,
      p_roles       IN owa.vc_arr,
      p_modules     IN owa.vc_arr,
      p_patterns    IN owa.vc_arr,
      p_comments    IN sec_privileges.comments%type DEFAULT NULL);

  PROCEDURE set_module_privilege(
      p_module_name  IN ords_modules.name%type,
      p_privilege_id IN sec_privileges.id%type);

  PROCEDURE set_module_privilege(
      p_module_id      IN ords_modules.id%type,
      p_privilege_name IN sec_privileges.name%type);

  PROCEDURE set_module_privilege(
      p_module_name    IN ords_modules.name%type,
      p_privilege_name IN sec_privileges.name%type);

  PROCEDURE set_module_origins_allowed(
      p_module_id       IN ords_modules.id%type,
      p_origins_allowed IN sec_origins_allowed_modules.origins_allowed%type);

  PROCEDURE set_module_origins_allowed(
      p_module_name     IN ords_modules.name%type,
      p_origins_allowed IN sec_origins_allowed_modules.origins_allowed%type);

  PROCEDURE delete_privilege(
      p_id IN sec_privileges.id%type);
  -- Roles

  FUNCTION create_role(
      p_name IN sec_roles.name%type)
    RETURN sec_roles.id%type;

  PROCEDURE update_role(
      p_id   IN sec_roles.id%type,
      p_name IN sec_roles.name%type);

  PROCEDURE delete_role(
      p_id IN sec_roles.id%type);

  -- Context
  /**
   * Set or unset context value
   * @param p_attribute   The attribute name
   * @param p_value       The attribute value or NULL to unset
   */
  PROCEDURE set_context(
         p_attribute        IN VARCHAR2,
         p_value            IN VARCHAR2);

  /**
   * Lock context
   * Locks the context to prevent any further changes
   */
  PROCEDURE lock_context;

END ords_services;
/


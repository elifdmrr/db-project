create view USER_ORDS_PRIVILEGES as
SELECT sec.id,
  sec.label,
  sec.name,
  sec.comments,
  sec.created_by,
  sec.description,
  sec.schema_id,
  sec.created_on,
  sec.updated_by,
  sec.updated_on
FROM ords_schemas sch,
  sec_privileges sec
WHERE sec.schema_id   IN (sch.id, 10)
AND nlssort(sch.parsing_schema,'NLS_SORT=BINARY') = nlssort(sys_context('USERENV', 'CURRENT_USER'),'NLS_SORT=BINARY')
/


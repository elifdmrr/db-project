create trigger "title151_TAB$xd"
    after update or delete
    on "title151_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','title151_TAB', :old.sys_nc_oid$, 'A3BD98F337594FE3AAB7A2818826D0D6' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','title151_TAB', :old.sys_nc_oid$, 'A3BD98F337594FE3AAB7A2818826D0D6', user ); END IF; END;
/


create trigger "XS$DATA_SECURITY$xd"
    after update or delete
    on XS$DATA_SECURITY
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XS$DATA_SECURITY', :old.sys_nc_oid$, '78A6A265626E4D138C938E5F5C843CA0' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XS$DATA_SECURITY', :old.sys_nc_oid$, '78A6A265626E4D138C938E5F5C843CA0', user ); END IF; END;
/


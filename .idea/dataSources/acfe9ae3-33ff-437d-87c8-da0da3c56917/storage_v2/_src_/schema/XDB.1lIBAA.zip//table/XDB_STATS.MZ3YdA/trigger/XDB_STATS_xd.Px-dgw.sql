create trigger "XDB$STATS$xd"
    after update or delete
    on XDB$STATS
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', :old.sys_nc_oid$, '3610F712A5A24B04A632832692A6C0EA' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', :old.sys_nc_oid$, '3610F712A5A24B04A632832692A6C0EA', user ); END IF; END;
/


create trigger "aggregatePrivilege156_TAB$xd"
    after update or delete
    on "aggregatePrivilege156_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','aggregatePrivilege156_TAB', :old.sys_nc_oid$, '5FA5E78F25CE4AACA8C51F3DCDA9C0BC' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','aggregatePrivilege156_TAB', :old.sys_nc_oid$, '5FA5E78F25CE4AACA8C51F3DCDA9C0BC', user ); END IF; END;
/


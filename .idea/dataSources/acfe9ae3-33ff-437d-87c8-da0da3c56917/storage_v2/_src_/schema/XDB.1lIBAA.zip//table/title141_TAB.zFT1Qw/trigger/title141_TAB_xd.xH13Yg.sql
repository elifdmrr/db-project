create trigger "title141_TAB$xd"
    after update or delete
    on "title141_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','title141_TAB', :old.sys_nc_oid$, 'DD45573CEAC945589A11526770A8AE69' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','title141_TAB', :old.sys_nc_oid$, 'DD45573CEAC945589A11526770A8AE69', user ); END IF; END;
/


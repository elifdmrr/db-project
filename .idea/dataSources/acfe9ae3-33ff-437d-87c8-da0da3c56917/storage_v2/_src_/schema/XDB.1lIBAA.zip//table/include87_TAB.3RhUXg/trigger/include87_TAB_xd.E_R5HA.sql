create trigger "include87_TAB$xd"
    after update or delete
    on "include87_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','include87_TAB', :old.sys_nc_oid$, '90C30B61C7864A8C923DFD92CD8B2590' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','include87_TAB', :old.sys_nc_oid$, '90C30B61C7864A8C923DFD92CD8B2590', user ); END IF; END;
/


create trigger "Folder53_TAB$xd"
    after update or delete
    on "Folder53_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','Folder53_TAB', :old.sys_nc_oid$, '8954F3ECAC5A4ACCBEF536D7B678E659' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','Folder53_TAB', :old.sys_nc_oid$, '8954F3ECAC5A4ACCBEF536D7B678E659', user ); END IF; END;
/


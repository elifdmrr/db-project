create trigger "XDB$CONFIG$xd"
    after update or delete
    on XDB$CONFIG
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$CONFIG', :old.sys_nc_oid$, '5E5CC30AF3B9458E90C485DD75E05CCC' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$CONFIG', :old.sys_nc_oid$, '5E5CC30AF3B9458E90C485DD75E05CCC', user ); END IF; END;
/


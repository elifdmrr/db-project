create trigger "XS$SECURITYCLASS$xd"
    after update or delete
    on XS$SECURITYCLASS
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XS$SECURITYCLASS', :old.sys_nc_oid$, '882C6F18E0304D46999A164E8855FFB9' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XS$SECURITYCLASS', :old.sys_nc_oid$, '882C6F18E0304D46999A164E8855FFB9', user ); END IF; END;
/


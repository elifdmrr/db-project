create trigger "XDB$RESCONFIG$xd"
    after update or delete
    on XDB$RESCONFIG
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'A4A4F45D526E40C9A9A0CF714F7D162C' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'A4A4F45D526E40C9A9A0CF714F7D162C', user ); END IF; END;
/


create trigger "xdb-log30_TAB$xd"
    after update or delete
    on "xdb-log30_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','xdb-log30_TAB', :old.sys_nc_oid$, '4D6FCE101F3B4082803CB2E76F1440AE' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','xdb-log30_TAB', :old.sys_nc_oid$, '4D6FCE101F3B4082803CB2E76F1440AE', user ); END IF; END;
/


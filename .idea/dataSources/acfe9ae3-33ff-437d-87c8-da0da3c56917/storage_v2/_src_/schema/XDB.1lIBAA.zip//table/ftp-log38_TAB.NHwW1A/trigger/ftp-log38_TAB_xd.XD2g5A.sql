create trigger "ftp-log38_TAB$xd"
    after update or delete
    on "ftp-log38_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','ftp-log38_TAB', :old.sys_nc_oid$, 'DF413272E39946CF89F648B889899FD2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','ftp-log38_TAB', :old.sys_nc_oid$, 'DF413272E39946CF89F648B889899FD2', user ); END IF; END;
/


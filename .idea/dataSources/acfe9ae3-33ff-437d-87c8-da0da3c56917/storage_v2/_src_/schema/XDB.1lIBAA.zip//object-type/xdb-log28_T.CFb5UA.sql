create TYPE       "xdb-log28_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","xdb-log-entry" "xdb-log-entry29_COLL")FINAL INSTANTIABLE
/


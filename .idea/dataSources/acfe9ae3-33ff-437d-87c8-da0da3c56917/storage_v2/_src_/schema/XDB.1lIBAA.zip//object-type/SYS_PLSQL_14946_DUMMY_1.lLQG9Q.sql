create type       SYS_PLSQL_14946_DUMMY_1 as table of number;
/


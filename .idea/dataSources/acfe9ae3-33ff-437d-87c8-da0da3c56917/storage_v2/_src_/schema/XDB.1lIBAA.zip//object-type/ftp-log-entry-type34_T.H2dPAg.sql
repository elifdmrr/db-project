create TYPE       "ftp-log-entry-type34_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","Date-and-Time" DATE,"Module" VARCHAR2(4000 CHAR),"Description" VARCHAR2(4000 CHAR),"User-ID" VARCHAR2(4000 CHAR),"Type" VARCHAR2(4000 CHAR),"Client-IP" VARCHAR2(4000 CHAR),"Request-Command" VARCHAR2(4000 CHAR),"Response" "Response35_T")NOT FINAL INSTANTIABLE
/


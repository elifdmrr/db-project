create trigger "fallback83_TAB$xd"
    after update or delete
    on "fallback83_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','fallback83_TAB', :old.sys_nc_oid$, 'CE587267267A4F21BA74257E9D0277BB' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','fallback83_TAB', :old.sys_nc_oid$, 'CE587267267A4F21BA74257E9D0277BB', user ); END IF; END;
/


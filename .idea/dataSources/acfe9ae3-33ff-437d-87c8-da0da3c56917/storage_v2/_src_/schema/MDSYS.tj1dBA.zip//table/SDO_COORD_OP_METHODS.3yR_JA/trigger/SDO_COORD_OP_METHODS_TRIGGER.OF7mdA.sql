create trigger SDO_COORD_OP_METHODS_TRIGGER
    before insert or update or delete
    on SDO_COORD_OP_METHODS
    for each row
BEGIN
  MDSYS.MDERR.RAISE_MD_ERROR('MD', 'SDO', -13199, 'This cannot change the actual implementation status of a method.');
END;
/


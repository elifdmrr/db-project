create trigger SDO_LRS_TRIG_UPD
    instead of update
    on USER_SDO_LRS_METADATA
    for each row
declare
 user_name 	varchar2(32);
 stmt  		varchar2(2048);
 vcount 	INTEGER;
BEGIN

  EXECUTE IMMEDIATE
  'SELECT user FROM dual' into user_name;

    UPDATE sdo_lrs_metadata_table
    SET (SDO_TABLE_NAME, SDO_COLUMN_NAME, SDO_DIM_POS, SDO_DIM_UNIT)  =
     (SELECT UPPER(:n.table_name), UPPER(:n.column_name),:n.dim_pos, UPPER(:n.dim_unit) FROM DUAL)
    WHERE SDO_OWNER   	  = UPPER(user_name)
      AND SDO_TABLE_NAME  = UPPER(:old.table_name)
      AND SDO_COLUMN_NAME = UPPER(:old.column_name);
END;
/


create TYPE         "GridFile181_T" UNDER "GridFileType178_T"("creation" TIMESTAMP,"update" TIMESTAMP)FINAL INSTANTIABLE
/


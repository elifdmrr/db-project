create trigger SDO_PREFERRED_OPS_SYSTEM_TRIG
    before insert or update or delete
    on SDO_PREFERRED_OPS_SYSTEM
    for each row
BEGIN
delete from mdsys.sdo_cs_context_information;
END;
/


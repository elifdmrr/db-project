create Type SDO_Topo_Geometry
                                                                      
AUTHID current_user as Object
  (TG_Type  NUMBER,
   TG_ID NUMBER,
   TG_Layer_ID NUMBER,
   Topology_ID   NUMBER,
   Constructor Function SDO_Topo_Geometry(TG_Type number,
                                    TG_id NUMBER,
                                    TG_layer_id NUMBER,
                                    Topology_ID NUMBER)
     return SELF as RESULT DETERMINISTIC,
   Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,
   Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,
   Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    add_Topo_ids SDO_TGL_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,
   Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    add_Topo_ids SDO_TGL_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,

   Member Function Get_Geometry
     return SDO_GEOMETRY DETERMINISTIC )
  alter type sdo_topo_geometry add
   Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,
   add Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    add_Topo_ids SDO_TOPO_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,
   add Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,
   add Constructor Function SDO_Topo_Geometry(topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    add_Topo_ids SDO_TOPO_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC,
 add   Member Function Get_Topo_Elements
     return SDO_TOPO_OBJECT_ARRAY DETERMINISTIC  CASCADE
  alter type SDO_Topo_Geometry add member function Get_TGL_Objects  return SDO_TGL_OBJECT_ARRAY DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add   Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    add_Topo_ids SDO_TOPO_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    add_Topo_ids SDO_TOPO_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TOPO_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    TG_Type number,
                                    TG_layer_id NUMBER,
                                    add_Topo_ids SDO_TGL_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  Constructor Function SDO_Topo_Geometry(tg_id number, topology varchar2,
                                    Table_Name  varchar2,
                                    Column_Name varchar2,
                                    TG_Type number,
                                    add_Topo_ids SDO_TGL_OBJECT_ARRAY,
                                    delete_Topo_ids SDO_TGL_OBJECT_ARRAY)
     return SELF as RESULT DETERMINISTIC CASCADE
  alter type sdo_topo_geometry add  MAP MEMBER FUNCTION to_string RETURN VARCHAR2 CASCADE
/


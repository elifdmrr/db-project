create trigger "GridFile182_TAB$xd"
    after update or delete
    on "GridFile182_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','GridFile182_TAB', :old.sys_nc_oid$, '11C7A0EF4F1E4B009D05B8C727C8D046' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','GridFile182_TAB', :old.sys_nc_oid$, '11C7A0EF4F1E4B009D05B8C727C8D046', user ); END IF; END;
/


create trigger "ForeignKey192_TAB$xd"
    after update or delete
    on "ForeignKey192_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ForeignKey192_TAB', :old.sys_nc_oid$, '357EC43C7A92499B94746222AEFD53A8' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ForeignKey192_TAB', :old.sys_nc_oid$, '357EC43C7A92499B94746222AEFD53A8', user ); END IF; END;
/


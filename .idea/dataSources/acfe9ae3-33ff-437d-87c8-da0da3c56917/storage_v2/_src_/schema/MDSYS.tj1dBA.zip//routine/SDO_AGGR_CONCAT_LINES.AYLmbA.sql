create function SDO_Aggr_Concat_Lines wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
75 9e
+jWKoIAFaJfWNyvZs8Dm2rmP67Ywg8eZgcfLCNL+XuefCNC/Wa6WGL//cgzcVvT++kcMYjy4
v4H+MrK9GMOlMr1KdDwdPqy93sA+Fja+QEY5Ojj3w4/A9b8owDK/dFJc57Iz0sfqpgiQc3Nu
pITYiKatV6i5
/


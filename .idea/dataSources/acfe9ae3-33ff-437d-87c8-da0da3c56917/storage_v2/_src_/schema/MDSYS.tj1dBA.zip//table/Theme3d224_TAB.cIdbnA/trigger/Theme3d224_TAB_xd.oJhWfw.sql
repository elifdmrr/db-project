create trigger "Theme3d224_TAB$xd"
    after update or delete
    on "Theme3d224_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Theme3d224_TAB', :old.sys_nc_oid$, '826A4233E78449AF951B4842A6BD4B46' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Theme3d224_TAB', :old.sys_nc_oid$, '826A4233E78449AF951B4842A6BD4B46', user ); END IF; END;
/


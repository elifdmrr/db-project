create trigger SDO_LRS_TRIG_DEL
    instead of delete
    on USER_SDO_LRS_METADATA
    for each row
declare
 user_name 	varchar2(32);
 stmt  		varchar2(2048);
 vcount 	INTEGER;
BEGIN

  EXECUTE IMMEDIATE
  'SELECT user FROM dual' into user_name;

    DELETE FROM  sdo_lrs_metadata_table
    WHERE SDO_OWNER   = user_name
      AND SDO_TABLE_NAME  = UPPER(:n.table_name)
      AND SDO_COLUMN_NAME = UPPER(:n.column_name);
END;
/


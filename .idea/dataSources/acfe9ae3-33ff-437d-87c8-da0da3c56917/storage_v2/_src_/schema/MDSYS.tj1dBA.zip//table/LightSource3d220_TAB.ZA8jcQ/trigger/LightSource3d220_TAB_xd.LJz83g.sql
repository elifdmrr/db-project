create trigger "LightSource3d220_TAB$xd"
    after update or delete
    on "LightSource3d220_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','LightSource3d220_TAB', :old.sys_nc_oid$, 'CD6F5DC8A675459E80B6B39F6F2AD50D' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','LightSource3d220_TAB', :old.sys_nc_oid$, 'CD6F5DC8A675459E80B6B39F6F2AD50D', user ); END IF; END;
/


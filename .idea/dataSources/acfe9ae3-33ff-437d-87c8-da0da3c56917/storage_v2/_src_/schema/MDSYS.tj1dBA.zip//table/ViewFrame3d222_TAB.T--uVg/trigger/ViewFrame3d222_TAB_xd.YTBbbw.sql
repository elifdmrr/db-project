create trigger "ViewFrame3d222_TAB$xd"
    after update or delete
    on "ViewFrame3d222_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ViewFrame3d222_TAB', :old.sys_nc_oid$, 'D181445A61CA41A9B81B0ED6129F66EF' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ViewFrame3d222_TAB', :old.sys_nc_oid$, 'D181445A61CA41A9B81B0ED6129F66EF', user ); END IF; END;
/


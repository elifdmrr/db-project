create trigger "ViewPoint3d209_TAB$xd"
    after update or delete
    on "ViewPoint3d209_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ViewPoint3d209_TAB', :old.sys_nc_oid$, 'FB9F222FAF9A44C28EC5BCB18D44079B' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ViewPoint3d209_TAB', :old.sys_nc_oid$, 'FB9F222FAF9A44C28EC5BCB18D44079B', user ); END IF; END;
/


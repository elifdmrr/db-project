create trigger "Scene3d223_TAB$xd"
    after update or delete
    on "Scene3d223_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Scene3d223_TAB', :old.sys_nc_oid$, 'D07EBD42E0594D0BB5F2420497F1827D' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Scene3d223_TAB', :old.sys_nc_oid$, 'D07EBD42E0594D0BB5F2420497F1827D', user ); END IF; END;
/


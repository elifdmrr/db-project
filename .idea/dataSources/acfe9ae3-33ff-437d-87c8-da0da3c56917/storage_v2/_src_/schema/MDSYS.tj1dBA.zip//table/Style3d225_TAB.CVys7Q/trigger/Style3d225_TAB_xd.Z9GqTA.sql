create trigger "Style3d225_TAB$xd"
    after update or delete
    on "Style3d225_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Style3d225_TAB', :old.sys_nc_oid$, 'F718FBC7DB1F42188389E97C1C2277BE' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Style3d225_TAB', :old.sys_nc_oid$, 'F718FBC7DB1F42188389E97C1C2277BE', user ); END IF; END;
/


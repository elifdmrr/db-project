create trigger "Animation3d221_TAB$xd"
    after update or delete
    on "Animation3d221_TAB"
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Animation3d221_TAB', :old.sys_nc_oid$, 'E70DB884CDD44A4DA7DBE8C0F6910666' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Animation3d221_TAB', :old.sys_nc_oid$, 'E70DB884CDD44A4DA7DBE8C0F6910666', user ); END IF; END;
/


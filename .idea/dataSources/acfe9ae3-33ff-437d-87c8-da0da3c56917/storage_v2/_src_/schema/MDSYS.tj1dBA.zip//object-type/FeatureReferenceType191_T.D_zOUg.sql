create TYPE         "FeatureReferenceType191_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","ForeignKey" VARCHAR2(4000 CHAR),"TargetTheme" VARCHAR2(4000 CHAR),"ActivationDistance" "ActivationDistance193_T")NOT FINAL INSTANTIABLE
/


create TYPE ST_MultiPolygon
                                       UNDER ST_MULTISURFACE (
  CONSTRUCTOR FUNCTION ST_MultiPolygon(apolygonarray ST_POLYGON_ARRAY)
           RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION ST_MultiPolygon(apolygonarray ST_POLYGON_ARRAY,
            asrid INTEGER) RETURN SELF AS RESULT,

  STATIC FUNCTION ST_BdMPolyFromText(awkt CLOB)
           RETURN ST_MultiPolygon DETERMINISTIC,
  STATIC FUNCTION ST_BdMPolyFromText(awkt CLOB, asrid INTEGER)
           RETURN ST_MultiPolygon DETERMINISTIC,
  STATIC FUNCTION ST_BdMPolyFromWKB(awkb BLOB)
           RETURN ST_MultiPolygon DETERMINISTIC,
  STATIC FUNCTION ST_BdMPolyFromWKB(awkb BLOB, asrid INTEGER)
           RETURN ST_MultiPolygon DETERMINISTIC)
/


create type H81_INDEX_OBJECT wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
7c 96
hHM88OECsBqvYYpWLWJxIXhsWYkwg5n0dLhcpUt8X/7Sx1Lw4/6/m8Ayy8y4dCupwiFTrEzk
hlXW5IQdbnNMcZSsdmoqX1kuKjLdBlRGz6TvS+M5B1dARjnVRq05rRJXOYjeBCcno4Kmpu53
LHA=
/


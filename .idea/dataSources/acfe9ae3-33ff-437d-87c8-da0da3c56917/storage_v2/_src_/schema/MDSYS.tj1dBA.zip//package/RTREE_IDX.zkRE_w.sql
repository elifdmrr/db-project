create PACKAGE rtree_idx wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
102 f7
jPkObJAz3IQH0sF3NsKjkjlnX44wgxBKLcusZy+iee7VYXdGVLQJYsRtcUYAwr8HaUzvAmIt
pU7pmQtr3Cr6RzRZ0ItGgEBDYUfHRYe5qX8hp92iXKfIURdE0q1npJU2HjbYL9A+M0Y3OPbz
5F3+Sl8QRCsn6qni4/s9IU0H4KS1yPbe3W97I2Z6vndckrDRz/kJcsJ0VED+8D27IoiXqOWp
2+LgYsdv4bKXblbwQ4v7o3p6UQ==
/


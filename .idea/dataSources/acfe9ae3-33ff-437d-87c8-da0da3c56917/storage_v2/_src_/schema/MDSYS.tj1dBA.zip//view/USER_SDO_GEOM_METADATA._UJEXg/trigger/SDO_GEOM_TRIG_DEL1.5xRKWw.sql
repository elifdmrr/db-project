create trigger SDO_GEOM_TRIG_DEL1
    instead of delete
    on USER_SDO_GEOM_METADATA
    for each row
declare
 tname varchar2(32);
 stmt  varchar2(2048);
 vcount INTEGER;
BEGIN

  EXECUTE IMMEDIATE
  'SELECT user FROM dual' into tname;

    DELETE FROM  sdo_geom_metadata_table
    WHERE SDO_OWNER = tname
      AND SDO_TABLE_NAME = upper(:n.table_name)
      AND SDO_COLUMN_NAME = upper(:n.column_name);
END;
/


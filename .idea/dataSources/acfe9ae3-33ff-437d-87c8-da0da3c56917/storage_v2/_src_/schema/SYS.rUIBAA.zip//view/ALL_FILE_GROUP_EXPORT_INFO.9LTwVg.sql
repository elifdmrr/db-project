create view ALL_FILE_GROUP_EXPORT_INFO
            (FILE_GROUP_OWNER, FILE_GROUP_NAME, VERSION_NAME, VERSION, EXPORT_VERSION, PLATFORM_NAME, EXPORT_TIME,
             EXPORT_SCN, SOURCE_GLOBAL_NAME)
as
select file_group_owner, file_group_name, version_name, version_id,
       export_version, platform_name, export_time, export_scn,
       source_global_name
from "_ALL_FILE_GROUP_EXPORT_INFO"
/

comment on table ALL_FILE_GROUP_EXPORT_INFO is 'Details about export information of file group versions'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.FILE_GROUP_OWNER is 'Owner of the file group'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.VERSION_NAME is 'Name of the version'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.VERSION is 'Internal version number'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.EXPORT_VERSION is 'Compatibility level of export dump'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.PLATFORM_NAME is 'Platform export was done on'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.EXPORT_TIME is 'Export job start time'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.EXPORT_SCN is 'Export job scn'
/

comment on column ALL_FILE_GROUP_EXPORT_INFO.SOURCE_GLOBAL_NAME is 'Global name of the exporting database'
/


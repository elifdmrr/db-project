create view KU$_PCOLUMN_VIEW
            (OBJ_NUM, COL_NUM, SEGCOL_NUM, SEGCOLLENGTH, OFFSET, NAME, ATTRNAME, TYPE_NUM, LENGTH, FIXEDSTORAGE,
             PRECISION_NUM, SCALE, NOT_NULL, DEFLENGTH, DEFAULT_VAL, BINARYDEFVAL, INTCOL_NUM, BASE_INTCOL_NUM,
             BASE_COL_TYPE, BASE_COL_NAME, PROPERTY, CHARSETID, CHARSETFORM, CON, TYPEMD, LOBMD, PLOBMD, OPQMD,
             OIDINDEX, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6)
as
select c.obj#, c.col#, c.segcol#,
         c.segcollength, c.offset, c.name,
         (select a.name from attrcol$ a where
                        a.obj#=c.obj# and a.intcol#=c.intcol#),
         c.type#, c.length, c.fixedstorage,
         c.precision#, c.scale, c.null$, c.deflength,
         sys.dbms_metadata_util.long2varchar(c.deflength,
                                        'SYS.COL$',
                                        'DEFAULT$',
                                        c.rowid),
         sys.dbms_metadata_util.binary2varchar(c.obj#, c.intcol#),
         c.intcol#,
         case c.col# when c.intcol# then c.intcol#
          else sys.dbms_metadata_util.get_base_intcol_num(c.obj#,c.col#,
                                                          c.intcol#,c.type#)
         end,
         case c.col# when c.intcol# then 0
          else
            sys.dbms_metadata_util.get_base_col_type(c.obj#,c.col#,
                                                          c.intcol#,c.type#)
         end,
         case c.col# when c.intcol# then NULL
          else
            sys.dbms_metadata_util.get_base_col_name(c.obj#,c.col#,
                                                          c.intcol#,c.type#)
         end,
         c.property, c.charsetid, c.charsetform,
         ( select value(cv)
             from ku$_constraint0_view cv, ku$_constraint_col_view ccv
             where c.intcol# = ccv.intcol_num
             and c.obj# = ccv.obj_num
             and ccv.con_num = cv.con_num
             and cv.contype in (7,11)
         ),
         ( select value(ctv)
             from ku$_coltype_view ctv
             where c.type# in ( 121,    -- DTYADT  (user-defined type)
                                122,    -- DTYNTB  (nested table)
                                123,    -- DTYNAR  (varray)
                                111,    -- DTYIREF (REF)
                                 58)    -- DTYOPQ  (opaque type)
             and   c.obj#  = ctv.obj_num
             and   c.intcol# = ctv.intcol_num
         ),
         ( select value(lv)
             from ku$_lob_view lv
             where (c.type# in (112,    -- CLOB
                                113,    -- BLOB
                                123)    -- DTYNAR  (varray)
                    and   c.obj#  = lv.obj_num
                    and   c.intcol# = lv.intcol_num)
             or    (c.type# = 58        -- DTYOPQ (XML type)
                    and   c.obj#  = lv.obj_num
                    and   lv.intcol_num =
                          (select op.lobcol from sys.opqtype$ op
                                    where op.obj# = c.obj#
                                    and   bitand(op.flags,4) != 0
                                    and   op.intcol# = c.intcol#)
                    )
             or    (c.type# = 58        -- DTYOPQ (opaque type)
                    and   c.obj#  = lv.obj_num
                    and   c.intcol# = lv.intcol_num
                    and   EXISTS (
                          SELECT  1
                          FROM    sys.opqtype$ op
                          WHERE  op.obj# = c.obj#
                                 and   op.intcol# = c.intcol#
                                 and   op.type = 0 )
                    )
         ),
         ( select value(lv)
             from ku$_partlob_view lv
             where (c.type# in (112,    -- CLOB
                                113,    -- BLOB
                                123)    -- DTYNAR  (varray)
                    and   c.obj#  = lv.obj_num
                    and   c.intcol# = lv.intcol_num)
             or    (c.type# = 58        -- DTYOPQ (XML type)
                    and   c.obj#  = lv.obj_num
                    and   lv.intcol_num =
                          (select op.lobcol from sys.opqtype$ op
                                    where op.obj# = c.obj#
                                    and   bitand(op.flags,4) != 0
                                    and   op.intcol# = c.intcol#)
                    )
             or    (c.type# = 58        -- DTYOPQ (opaque type)
                    and   c.obj#  = lv.obj_num
                    and   c.intcol# = lv.intcol_num
                    and   EXISTS (
                          SELECT  1
                          FROM    sys.opqtype$ op
                          WHERE  op.obj# = c.obj#
                                 and   op.intcol# = c.intcol#
                                 and   op.type = 0 )
                    )
         ),
         ( select value(opq) from sys.ku$_opqtype_view opq
             where c.type# = 58        -- DTYOPQ (opaque type)
             and   c.obj# = opq.obj_num
             and   c.intcol# = opq.intcol_num
         ),
         ( select value(oi)
             from ku$_oidindex_view oi
             where bitand(c.property, 2) = 2
             and   c.obj# = oi.obj_num
             and   c.intcol# = oi.intcol_num
         ),
         c.spare1, c.spare2, c.spare3, c.spare4, c.spare5,
         to_char(c.spare6, 'YYYY/MM/DD HH24:MI:SS')
  from col$ c
/


create view DBA_CONTEXT (NAMESPACE, SCHEMA, PACKAGE, TYPE) as
select o.name, c.schema, c.package,
DECODE( c.flags,0,'ACCESSED LOCALLY',1,'INITIALIZED EXTERNALLY',2,'ACCESSED GLOBALLY',4,'INITIALIZED GLOBALLY')
from  context$ c, obj$ o
where c.obj# = o.obj#
and o.type# = 44
/

comment on table DBA_CONTEXT is 'Description of all context namespace information'
/

comment on column DBA_CONTEXT.NAMESPACE is 'Namespace of the context'
/

comment on column DBA_CONTEXT.SCHEMA is 'Schema of the designated package'
/

comment on column DBA_CONTEXT.PACKAGE is 'Name of the designated package'
/

comment on column DBA_CONTEXT.TYPE is 'Type of the context create'
/


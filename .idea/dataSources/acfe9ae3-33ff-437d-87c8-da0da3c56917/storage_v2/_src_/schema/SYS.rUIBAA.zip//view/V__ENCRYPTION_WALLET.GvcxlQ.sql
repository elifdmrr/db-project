create view V_$ENCRYPTION_WALLET (WRL_TYPE, WRL_PARAMETER, STATUS) as
select "WRL_TYPE","WRL_PARAMETER","STATUS" from v$encryption_wallet
/


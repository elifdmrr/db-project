create view EXU8RGSU (REFGROUP, OWNERID, OWNER) as
SELECT  "REFGROUP","OWNERID","OWNER"
        FROM    sys.exu8rgs
        WHERE   UID = ownerid
/


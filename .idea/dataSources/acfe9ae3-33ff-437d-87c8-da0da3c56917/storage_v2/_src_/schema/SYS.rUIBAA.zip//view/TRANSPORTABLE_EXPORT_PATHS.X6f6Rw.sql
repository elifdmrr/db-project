create view TRANSPORTABLE_EXPORT_PATHS (OBJECT_PATH) as
select OBJECT_PATH
    from dba_export_paths
    where het_type='TRANSPORTABLE_EXPORT'
UNION
select 'TABLE_DATA' from dual  /* hack */
/


create view "_DBA_STREAMS_UNSUPPORTED_9_2"
            (OWNER, TABLE_NAME, TPROPERTY, TTRIGFLAG, OFLAGS, TFLAGS, REASON, COMPATIBLE, AUTO_FILTERED) as
select
    distinct u.name, o.name,
             t.property, t.trigflag, o.flags, t.flags,
     (case
      when
        ( (bitand(t.property,
                64                                                    /* IOT */
              + 128         /* 0x00000080              IOT with row overflow */
              + 256         /* 0x00000100            IOT with row clustering */
              + 512         /* 0x00000200               IOT overflow segment */
             ) != 0
          ) or
          (bitand(t.flags,
                268435456    /* 0x10000000   IOT with Phys Rowid/mapping tab */
              + 536870912    /* 0x20000000 Mapping Tab for Phys rowid of IOT */
             ) != 0
          ) or
          (bitand(t.property, 262208) = 262208  /* 0x40+0x40000 IOT+user LOB */
          ) or
          (bitand(t.property, 2112) = 2112  /* 0x40+0x800 IOT + internal LOB */
          ) or
          (bitand(t.property, 64) != 0 and                           /* 0x40 */
             bitand(t.flags, 131072) != 0  /* 0x20000  IOT with row movement */
          )
        )
        then 'IOT'
      when exists (select 1 from sys.partobj$ p
                   where p.obj# = o.obj# and
                         p.parttype = 3)                 /* system partition */
        then 'table with system partition'
      when bitand(t.property,
                  1                                           /* typed table */
                + 2                                           /* ADT columns */
                + 4                                  /* nested table columns */
                + 8                                           /* REF columns */
                + 16                                        /* array columns */
                + 4096                                             /* pk OID */
                + 8192              /* storage table for nested table column */
                + 65536                                              /* sOID */
               ) != 0
         then 'column with user-defined type'
      when ( bitand(nvl(s.spare1, 0), 2048) = 2048  or  /* table compression */
             bitand(nvl(ds.flags_stg, 0), 4) = 4   /* DSC: table compression */
           )
         then 'table compression'
      when (exists                                                   /* long */
            (select 1 from sys.col$ c
             where t.obj# = c.obj# and c.type# = 8))
        then 'table with long column'
      when (exists                                                /* long raw*/
            (select 1 from sys.col$ c
             where t.obj# = c.obj# and c.type# = 24))
        then 'table with long raw column'
      when (exists                                           /* binary_float */
            (select 1 from sys.col$ c
             where t.obj# = c.obj# and c.type# = 100))
        then 'table with binary_float column'
      when (exists                                          /* binary_double */
            (select 1 from sys.col$ c
             where t.obj# = c.obj# and c.type# = 101))
        then 'table with binary_double column'
      when (exists
            (select 1 from sys.col$ c                               /* nclob */
             where t.obj# = c.obj# and c.type# = 112 and c.charsetform = 2))
        then 'table with NCLOB column'
      when (exists                                                 /* urowid */
            (select 1 from sys.col$ c
             where t.obj# = c.obj# and c.type# = 208))
        then 'table with urowid column'
      when (exists                                 /* funtion-based indexing */
            (select 1 from sys.ind$ i
             where i.bo# = t.obj#
             and bitand(i.property, 16) = 16))
        then 'table with function-based indexing'
      when (exists
            (select 1
             from   sys.col$ c
             where  t.obj# = c.obj#
               and
               ( (bitand(c.property, 32) = 32 and                  /* hidden */
                  bitand (c.property, 32768) != 32768          /* not unused */
                 ) or
                 (c.type# not in (
                     1,                                          /* varchar2 */
                     2,                                            /* number */
                     12,                                             /* date */
                     96,                                             /* char */
                     112,                                  /* clob and nclob */
                     113,                                            /* blob */
                     180,                                  /* timestamp (..) */
                     181,                    /* timestamp(..) with time zone */
                     182,                      /* interval year(..) to month */
                     183,                  /* interval day(..) to second(..) */
                     231)              /* timestamp(..) with local time zone */
                   and (c.type# != 23                     /* raw not raw oid */
                     or (c.type# = 23 and bitand(c.property, 2) = 2))
                 ) or
                 (c.segcol# = 0             /* virtual column: not supported */
                 ) or
                 (bitand(c.property,
                         2                                     /* OID column */
                       + 67108864                             /* KQLDCOP_ENC */
                       ) != 0
                 ) or
                 (c.type# = 112 and c.charsetform = 2               /* NCLOB */
                 ) or
                 (c.type# = 112 and c.charsetform = 1 and
                  /* discussed with JIYANG, varying width CLOB */
                  c.charsetid >= 800
                 )
               )
             )
          )
         then 'unsupported column exists'
      when bitand(t.property, 1) = 1
        then 'object table'
      when bitand(t.property, 131072) = 131072
        then 'AQ queue table'
      /* x00400000 + 0x00800000 */
      when bitand(t.property, 4194304 + 8388608) != 0
        then 'temporary table'
      when bitand(t.property, 134217728) = 134217728          /* 0x08000000 */
        then 'sub object'
      when bitand(t.property, 2147483648) = 2147483648
        then 'external table'
      when bitand(t.property, 33554432 + 67108864) != 0
        then 'materialized view'
      when bitand(t.property, 32768) = 32768     /* 0x8000 has FILE columns */
        then 'FILE column exists'
      when
        (exists
          (select 1
           from sys.mlog$ ml where ml.mowner = u.name and ml.log = o.name
          )
        )
        then 'materialized view log'
      when bitand(t.flags, 262144) = 262144
        then 'materalized view container table'
      when bitand(t.trigflag, 268435456) = 268435456
        then 'streams unsupported object'
      when bitand(o.flags, 16) = 16
        then 'domain index'
      else 'Streams unsupported table' end) reason,
      92,                                                      /* compatible */
      'NO'                                                  /* auto filtered */
  from sys.obj$ o, sys.user$ u, sys.tab$ t, sys.seg$ s, sys.deferred_stg$ ds
  where t.obj# = o.obj#
    and o.owner# = u.user#
    and t.file# = s.file# (+)
    and t.block# = s.block# (+)
    and t.ts# = s.ts# (+)
    and t.obj# = ds.obj# (+)
                   /* should be consistent with knlcfIsFilteredSpecialSchema */
    and u.name not in ('SYS', 'SYSTEM', 'CTXSYS', 'DBSNMP', 'LBACSYS',
                       'MDDATA', 'MDSYS', 'DMSYS', 'OLAPSYS', 'ORDPLUGINS',
                       'ORDSYS', 'SI_INFORMTN_SCHEMA', 'SYSMAN', 'OUTLN',
                       'EXFSYS', 'WMSYS', 'XDB', 'DVSYS', 'ORDDATA')
    and bitand(o.flags,
                  2                                      /* temporary object */
                + 4                               /* system generated object */
                + 32                                 /* in-memory temp table */
                + 128                          /* dropped table (RecycleBin) */
                  ) = 0
    and
      (  (bitand(t.property,
                64                                                    /* IOT */
              + 128         /* 0x00000080              IOT with row overflow */
              + 256         /* 0x00000100            IOT with row clustering */
              + 512         /* 0x00000200               IOT overflow segment */
             ) != 0
          ) or
          (bitand(t.flags,
                268435456    /* 0x10000000   IOT with Phys Rowid/mapping tab */
              + 536870912    /* 0x20000000 Mapping Tab for Phys rowid of IOT */
             ) != 0
          ) or
          (bitand(t.property, 262208) = 262208  /* 0x40+0x40000 IOT+user LOB */
          ) or
          (bitand(t.property, 2112) = 2112  /* 0x40+0x800 IOT + internal LOB */
          ) or
          (bitand(t.property, 64) != 0 and                           /* 0x40 */
             bitand(t.flags, 131072) != 0                         /* 0x20000 */
          ) or                                    /* IOT with "Row Movement" */
          (bitand(nvl(s.spare1, 0), 2048) = 2048) or    /* table compression */
          (bitand(nvl(ds.flags_stg, 0), 4) = 4) or /* DSC: table compression */
          (bitand(t.property,
                  1                                           /* typed table */
                + 2                                           /* ADT columns */
                + 4                                  /* nested table columns */
                + 8                                           /* REF columns */
                + 16                                        /* array columns */
                + 4096                                             /* pk OID */
                + 8192              /* storage table for nested table column */
                + 65536                                              /* sOID */
               ) != 0
          ) or
          (exists
            (select 1 from sys.partobj$ p
             where p.obj# = o.obj# and
                   p.parttype = 3)) or                   /* system partition */
          (exists                                      /* unsupported column */
            (select 1 from sys.col$ c
             where t.obj# = c.obj#
               and
               ( (bitand(c.property,          /* check for encrypted columns */
                       + 67108864                             /* KQLDCOP_ENC */
                       ) != 0) or
                 (c.segcol# != 0 and
                  bitand(c.property, 32) = 32 and                  /* hidden */
                  bitand (c.property, 32768) != 32768          /* not unused */
                 ) or
                 (c.type# not in (
                     1,                                          /* varchar2 */
                     2,                                            /* number */
                     12,                                             /* date */
                     96,                                             /* char */
                     112,                                  /* clob and nclob */
                     113,                                            /* blob */
                     180,                                  /* timestamp (..) */
                     181,                    /* timestamp(..) with time zone */
                     182,                      /* interval year(..) to month */
                     183,                  /* interval day(..) to second(..) */
                     231)              /* timestamp(..) with local time zone */
                   and (c.type# != 23                     /* raw not raw oid */
                     or (c.type# = 23 and bitand(c.property, 2) = 2))
                 ) or
                 (c.segcol# = 0             /* virtual column: not supported */
                 ) or
                 (bitand(c.property, 2) = 2                    /* OID column */
                 ) or
                 (c.type# = 112 and c.charsetform = 2               /* NCLOB */
                 ) or
                 (c.type# = 112 and c.charsetform = 1 and
                  /* discussed with JIYANG, varying width CLOB */
                  c.charsetid >= 800
                 )
               )
             )
          ) or
          (bitand(t.property, 1) = 1                         /* object table */
          ) or
          (bitand(t.property,
                131072      /* 0x00020000 table is used as an AQ queue table */
              + 4194304     /* 0x00400000             global temporary table */
              + 8388608     /* 0x00800000   session-specific temporary table */
              + 33554432    /* 0x02000000        Read Only Materialized View */
              + 67108864    /* 0x04000000            Materialized View table */
              + 134217728   /* 0x08000000                    Is a Sub object */
              + 2147483648   /* 0x80000000                    eXternal TaBle */
             ) != 0
          ) or
          (bitand(t.flags,
                  262144              /* 0x00040000   MV Container Table, MV */
                 ) = 262144
          ) or
          (bitand(t.property, 32768) = 32768      /* 0x8000 has FILE columns */
          ) or
          (bitand(t.trigflag,
                  65536     /* 0x00010000   server held key encrypted column */
                + 131072    /* 0x00020000     user held key encrypted column */
                + 268435456 /* 0x10000000                         strm unsup */
             ) != 0
          ) or
          (exists
            (select 1
             from sys.mlog$ ml where ml.mowner = u.name and ml.log = o.name
            )
          ) or
          (exists                                 /* funtion-based indexing */
            (select 1 from sys.ind$ i
             where i.bo# = t.obj#
             and bitand(i.property, 16) = 16))
        )
/


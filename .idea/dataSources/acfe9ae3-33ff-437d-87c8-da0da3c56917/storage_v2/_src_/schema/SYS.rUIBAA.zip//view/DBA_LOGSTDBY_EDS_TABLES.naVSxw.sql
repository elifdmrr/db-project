create view DBA_LOGSTDBY_EDS_TABLES (OWNER, TABLE_NAME, CTIME) as
select owner, table_name, ctime from system.logstdby$eds_tables
/

comment on table DBA_LOGSTDBY_EDS_TABLES is 'List of all tables that have EDS-based replication for Logical Standby'
/

comment on column DBA_LOGSTDBY_EDS_TABLES.OWNER is 'Schema name of supportable table'
/

comment on column DBA_LOGSTDBY_EDS_TABLES.TABLE_NAME is 'Table name of supportable table'
/

comment on column DBA_LOGSTDBY_EDS_TABLES.CTIME is 'Time that table had EDS added'
/


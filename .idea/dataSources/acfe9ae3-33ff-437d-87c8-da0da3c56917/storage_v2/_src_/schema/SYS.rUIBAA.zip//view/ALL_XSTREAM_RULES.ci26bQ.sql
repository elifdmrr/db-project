create view ALL_XSTREAM_RULES
            (STREAMS_NAME, STREAMS_TYPE, STREAMS_RULE_TYPE, RULE_SET_OWNER, RULE_SET_NAME, RULE_SET_TYPE, RULE_OWNER,
             RULE_NAME, RULE_TYPE, RULE_CONDITION, SCHEMA_NAME, OBJECT_NAME, INCLUDE_TAGGED_LCR, SUBSETTING_OPERATION,
             DML_CONDITION, SOURCE_DATABASE, ORIGINAL_RULE_CONDITION, SAME_RULE_CONDITION)
as
select
  streams_name, streams_type, streams_rule_type,
  rule_set_owner, rule_set_name, rule_set_type,
  rule_owner, rule_name, rule_type, rule_condition,
  schema_name, object_name, include_tagged_lcr,
  subsetting_operation, dml_condition, source_database,
  original_rule_condition, same_rule_condition
from all_streams_rules
  where ((streams_type = 'CAPTURE') or
         (streams_type = 'APPLY')) and
        ((streams_type, streams_name) IN
      (select 'APPLY', server_name from sys.xstream$_server
         union
       select 'CAPTURE', capture_name from sys.xstream$_server))
/

comment on table ALL_XSTREAM_RULES is 'Details about the XStream server rules visible to user'
/

comment on column ALL_XSTREAM_RULES.STREAMS_NAME is 'Name of the Streams process'
/

comment on column ALL_XSTREAM_RULES.STREAMS_TYPE is 'Type of the Streams process: CAPTURE or APPLY'
/

comment on column ALL_XSTREAM_RULES.STREAMS_RULE_TYPE is 'For global, schema or table rules, type of rule: TABLE, SCHEMA or GLOBAL'
/

comment on column ALL_XSTREAM_RULES.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column ALL_XSTREAM_RULES.RULE_SET_NAME is 'Name of the rule set'
/

comment on column ALL_XSTREAM_RULES.RULE_SET_TYPE is 'Type of the rule set: POSITIVE or NEGATIVE'
/

comment on column ALL_XSTREAM_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column ALL_XSTREAM_RULES.RULE_NAME is 'Name of the rule'
/

comment on column ALL_XSTREAM_RULES.RULE_TYPE is 'For global, schema or table rules, type of rule: DML or DDL'
/

comment on column ALL_XSTREAM_RULES.RULE_CONDITION is 'Current rule condition'
/

comment on column ALL_XSTREAM_RULES.SCHEMA_NAME is 'For table and schema rules, the schema name'
/

comment on column ALL_XSTREAM_RULES.OBJECT_NAME is 'For table rules, the table name'
/

comment on column ALL_XSTREAM_RULES.INCLUDE_TAGGED_LCR is 'For global, schema or table rules, whether or not to include tagged LCRs'
/

comment on column ALL_XSTREAM_RULES.SUBSETTING_OPERATION is 'For subset rules, the type of operation: INSERT, UPDATE, or DELETE'
/

comment on column ALL_XSTREAM_RULES.DML_CONDITION is 'For subset rules, the row subsetting condition'
/

comment on column ALL_XSTREAM_RULES.SOURCE_DATABASE is 'For global, schema or table rules, the name of the database where the LCRs originated'
/

comment on column ALL_XSTREAM_RULES.ORIGINAL_RULE_CONDITION is 'For rules created by Streams administrative APIs, the original rule condition when the rule was created'
/

comment on column ALL_XSTREAM_RULES.SAME_RULE_CONDITION is 'For rules created by Streams administrative APIs, whether or not the current rule condition is the same as the original rule condition'
/


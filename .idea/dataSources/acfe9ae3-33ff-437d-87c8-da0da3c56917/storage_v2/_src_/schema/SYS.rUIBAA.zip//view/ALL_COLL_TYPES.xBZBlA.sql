create view ALL_COLL_TYPES
            (OWNER, TYPE_NAME, COLL_TYPE, UPPER_BOUND, ELEM_TYPE_MOD, ELEM_TYPE_OWNER, ELEM_TYPE_NAME, LENGTH,
             PRECISION, SCALE, CHARACTER_SET_NAME, ELEM_STORAGE, NULLS_STORED, CHAR_USED)
as
select u.name, o.name, co.name, c.upper_bound,
       decode(bitand(c.properties, 32768), 32768, 'REF',
              decode(bitand(c.properties, 16384), 16384, 'POINTER')),
       nvl2(c.synobj#, (select u.name from user$ u, "_CURRENT_EDITION_OBJ" o
            where o.owner#=u.user# and o.obj#=c.synobj#),
            decode(bitand(et.properties, 64), 64, null, eu.name)),
       nvl2(c.synobj#, (select o.name from "_CURRENT_EDITION_OBJ" o where o.obj#=c.synobj#),
            decode(et.typecode,
                   9, decode(c.charsetform, 2, 'NVARCHAR2', eo.name),
                   96, decode(c.charsetform, 2, 'NCHAR', eo.name),
                   112, decode(c.charsetform, 2, 'NCLOB', eo.name),
                   eo.name)),
       c.length, c.precision, c.scale,
       decode(c.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(c.charsetid),
                             4, 'ARG:'||c.charsetid),
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(c.properties, 4096), 4096, 'C', 'B')
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c, sys."_CURRENT_EDITION_OBJ" co,
     sys."_CURRENT_EDITION_OBJ" eo, sys.user$ eu, sys.type$ et
where o.owner# = u.user#
  and o.type# <> 10 -- must not be invalid
  and o.oid$ = c.toid
  and o.subname IS NULL -- only the most recent version
  and c.coll_toid = co.oid$
  and c.elem_toid = eo.oid$
  and eo.owner# = eu.user#
  and c.elem_toid = et.tvoid
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                     -181 /* CREATE ANY TYPE */)))
/

comment on table ALL_COLL_TYPES is 'Description of named collection types accessible to the user'
/

comment on column ALL_COLL_TYPES.OWNER is 'Owner of the type'
/

comment on column ALL_COLL_TYPES.TYPE_NAME is 'Name of the type'
/

comment on column ALL_COLL_TYPES.COLL_TYPE is 'Collection type'
/

comment on column ALL_COLL_TYPES.UPPER_BOUND is 'Size of the FIXED ARRAY type or maximum size of the VARYING ARRAY type'
/

comment on column ALL_COLL_TYPES.ELEM_TYPE_MOD is 'Type modifier of the element'
/

comment on column ALL_COLL_TYPES.ELEM_TYPE_OWNER is 'Owner of the type of the element'
/

comment on column ALL_COLL_TYPES.ELEM_TYPE_NAME is 'Name of the type of the element'
/

comment on column ALL_COLL_TYPES.LENGTH is 'Length of the CHAR element or maximum length of the VARCHAR
or VARCHAR2 element'
/

comment on column ALL_COLL_TYPES.PRECISION is 'Decimal precision of the NUMBER or DECIMAL element or
binary precision of the FLOAT element'
/

comment on column ALL_COLL_TYPES.SCALE is 'Scale of the NUMBER or DECIMAL element'
/

comment on column ALL_COLL_TYPES.CHARACTER_SET_NAME is 'Character set name of the element'
/

comment on column ALL_COLL_TYPES.ELEM_STORAGE is 'Storage optimization specification for VARRAY of numeric elements'
/

comment on column ALL_COLL_TYPES.NULLS_STORED is 'Is null information stored with each VARRAY element?'
/

comment on column ALL_COLL_TYPES.CHAR_USED is 'C if the width was specified in characters, B if in bytes'
/


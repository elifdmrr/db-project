create view "_DBA_STREAMS_COMPONENT_STAT"
            (COMPONENT_NAME, COMPONENT_DB, COMPONENT_TYPE, STAT_TIME, COUNT1, COUNT2, COUNT3, COUNT4, LATENCY, STATUS,
             SPARE1, SPARE2, SPARE3, SPARE4)
as
SELECT v.COMPONENT_NAME,
       global_name COMPONENT_DB,
       v.COMPONENT_TYPE,
       sysdate STAT_TIME,
       v.COUNT1,
       v.COUNT2,
       v.COUNT3,
       0 COUNT4,
       v.LATENCY,
decode(v.STATUS, 'ENABLED',      0,
                 'ABORTED',      1,
                 'DISABLED',     2,
                 'FLOW CONTROL', 3,
                 'VALID',        0,
                 'INVALID',      1,
                 'N/A',          2, 0),
       0, 0, NULL, to_date(NULL, '')
FROM global_name,
 ( -- CAPTURE
   SELECT
     c.capture_name                       as COMPONENT_NAME,
     1                                    as COMPONENT_TYPE,
     -- COUNT1: TOTAL MESSAGES CAPTURED
     nvl(vcap.total_messages_captured, 0) as COUNT1,
     -- COUNT2: TOTAL MESSAGES ENQUEUED
     nvl(vcap.total_messages_enqueued, 0) as COUNT2,
     -- COUNT3: TOTAL BYTES SENT
     nvl(vcap.bytessent, 0)               as COUNT3,
     -- LATENCY: SECONDS
     nvl((vcap.AVAILABLE_MESSAGE_CREATE_TIME-vcap.CAPTURE_MESSAGE_CREATE_TIME)
         * 86400, -1)                     as LATENCY,
     CASE WHEN (vcap.state = 'PAUSED FOR FLOW CONTROL')
          THEN 'FLOW CONTROL'
          ELSE decode(c.status, 1, 'DISABLED',
                                2, 'ENABLED',
                                4, 'ABORTED', 'UNKNOWN')
     END                                  as STATUS
   -- OPTIMIZE: Replace dba_capture with sys.streams$_capture_process
   FROM sys.streams$_capture_process c,
      ( SELECT cap.capture_name,
               cap.total_messages_captured,
               cap.total_messages_enqueued,
               cap.available_message_create_time,
               cap.capture_message_create_time,
               cap.state,
               sess.value as bytessent
        FROM gv$streams_capture cap, gv$statname stat, gv$sesstat sess
        WHERE cap.sid = sess.sid AND sess.statistic# = stat.statistic# AND
              stat.name = 'bytes sent via SQL*Net to dblink') vcap
   WHERE c.capture_name = vcap.capture_name (+)
   UNION
   -- APPLY
   SELECT a.apply_name                    as COMPONENT_NAME,
          4                               as COMPONENT_TYPE,
          -- COUNT1: TOTAL MESSAGES APPLIED
          nvl(aps.COUNT1, 0)              as COUNT1,
          -- COUNT2: TOTAL TRANSACTIONS APPLIED
          nvl(apc.total_applied, 0)       as COUNT2,
          0                               as COUNT3,
          -- LATENCY: SECONDS
          CASE WHEN aps.state != 'IDLE' THEN
                 nvl((aps.apply_time - aps.create_time)*86400, -1)
               WHEN apc.state != 'IDLE' THEN
                 nvl((apc.apply_time - apc.create_time)*86400, -1)
               WHEN apr.state != 'IDLE' THEN
                 nvl((apr.apply_time - apr.create_time)*86400, -1)
               ELSE 0
          END                             as LATENCY,
          decode(a.status, 1, 'DISABLED',
                           2, 'ENABLED',
                           4, 'ABORTED', 'UNKNOWN')
                                          as STATUS
   -- OPTIMIZE: Replace dba_apply with sys.streams$_apply_process
   -- Calculate apply latency in order of SERVER, COORDINATOR, READER
   FROM sys.streams$_apply_process a,
        ( SELECT apply_name,
                 state,
                 apply_time,
                 max_create_time as create_time,
                 count1
          FROM ( SELECT apply_name,
                        state,
                        apply_time,
                        applied_message_create_time,
                        MAX(applied_message_create_time)
                          OVER (PARTITION BY apply_name)
                          as max_create_time,
                        SUM(total_messages_applied)
                          OVER (PARTITION BY apply_name)
                          as count1
                 FROM gv$streams_apply_server)
                 -- There may be many apply slaves, pick the first one for
                 -- apply_time, apply_message_create_time
          WHERE ROWNUM <= 1) aps,
        ( SELECT c.apply_name,
                 state,
                 -- If XOut use hwm_time else use lwm_time
                 CASE WHEN (bitand(p.flags, 256)) = 256
                      THEN c.hwm_time
                      ELSE c.lwm_time
                 END                          as apply_time,
                 CASE WHEN (bitand(p.flags, 256)) = 256
                      THEN hwm_message_create_time
                      ELSE lwm_message_create_time
                 END                          as create_time,
                 total_applied
          FROM gv$streams_apply_coordinator c,
               sys.streams$_apply_process p
          WHERE p.apply_name = c.apply_name) apc,
        ( SELECT apply_name,
                 state,
                 dequeue_time                 as apply_time,
                 dequeued_message_create_time as create_time
          FROM gv$streams_apply_reader ) apr
   WHERE a.apply_name = apc.apply_name (+) AND
         apc.apply_name = apr.apply_name (+) AND
         apr.apply_name = aps.apply_name (+)
   UNION
   -- QUEUE
   SELECT ('"'||q.queue_schema||'"."'||q.queue_name||'"')
                                          as COMPONENT_NAME,
          5                               as COMPONENT_TYPE,
          -- COUNT1: CUMULATIVE MESSAGES ENQUEUED
          q.cnum_msgs                     as COUNT1,
          -- COUNT2: CUMULATIVE MESSAGES SPILLED
          q.cspill_msgs                   as COUNT2,
          -- COUNT3: CURRENT QUEUE SIZE
          q.num_msgs                      as COUNT3,
          0                               as LATENCY,
          decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID')
                                          as STATUS
   -- OPTIMIZE: Replace dba_objects with sys.obj$ and sys.user$
   FROM gv$buffered_queues q, sys.obj$ o, sys.user$ u
   WHERE q.queue_schema = u.name AND
         q.queue_id = o.obj# AND
         o.owner# = u.user#
   UNION
   -- PROPAGATION SENDER
   SELECT ('"'||ps.queue_schema||'"."'||ps.queue_name||'"=>'||
           CASE WHEN ps.dblink IS NOT NULL AND
                     (ps.dst_queue_schema IS NULL OR ps.dst_queue_name IS NULL)
                THEN ps.dblink
                ELSE ('"'||ps.dst_queue_schema||'"."'||ps.dst_queue_name||
                      '"@'||ps.dst_database_name)
           END)                           as COMPONENT_NAME,
          2                               as COMPONENT_TYPE,
          -- COUNT1: TOTAL MESSAGES SENT
          ps.total_msgs                   as COUNT1,
          -- COUNT1: TOTAL BYTES SENT
          ps.total_bytes                  as COUNT2,
          0                               as COUNT3,
          -- LATENCY: SECONDS
          ps.last_lcr_latency             as LATENCY,
          CASE WHEN (regexp_instr(s.last_error_msg,
                    '.*flow control.*', 1, 1, 0, 'i') > 0)
               -- ORA-25307: Enqueue rate too high, flow control enabled
               -- Subscribers could not keep pace with the enqueue rate,
               -- propagation is in flow control
                    THEN 'FLOW CONTROL'
               WHEN (ps.schedule_status = 'SCHEDULE DISABLED')
                    THEN 'DISABLED'
               WHEN (ps.schedule_status = 'PROPAGATION UNSCHEDULED')
                    THEN 'ABORTED'
               WHEN (j.enabled != 'TRUE' AND j.retry_count >= 16)
                 -- (dqs.schedule_disabled = 'Y' AND dqs.failures >= 16)
                    THEN 'ABORTED'
               ELSE ps.schedule_status
          END                             as STATUS
   FROM gv$propagation_sender ps,
        -- OPTIMIZE: Replace DBA_QUEUE_SCHEDULES dqs with base tables q, s, j
        system.aq$_queues q, sys.aq$_schedules s, sys.dba_scheduler_jobs j
   WHERE ps.dst_database_name IS NOT NULL AND
         ps.queue_id = q.eventid AND ps.queue_name = q.name AND
         q.oid = s.oid (+) AND s.job_name = j.job_name (+) ) v
/

comment on table "_DBA_STREAMS_COMPONENT_STAT" is 'DBA Streams Component Statistics'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".COMPONENT_NAME is 'Name of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".COMPONENT_DB is 'Database on which the streams component resides'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".COMPONENT_TYPE is 'Type of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".STAT_TIME is 'Time that statistics were taken'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".COUNT1 is 'First count, dependent on the type of the component'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".COUNT2 is 'Second count, dependent on the type of the component'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".COUNT3 is 'Third count, dependent on the type of the component'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".COUNT4 is 'Fourth count, dependent on the type of the component (Spare Column)'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".LATENCY is 'Latency of the component'
/

comment on column "_DBA_STREAMS_COMPONENT_STAT".STATUS is 'Status of the component'
/


create view GV_$SQL_FEATURE_HIERARCHY (INST_ID, SQL_FEATURE, PARENT_ID) as
select "INST_ID","SQL_FEATURE","PARENT_ID" from gv$sql_feature_hierarchy
/


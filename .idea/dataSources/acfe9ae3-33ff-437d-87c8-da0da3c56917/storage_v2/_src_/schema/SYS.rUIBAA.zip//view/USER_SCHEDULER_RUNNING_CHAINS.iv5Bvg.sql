create view USER_SCHEDULER_RUNNING_CHAINS
            (JOB_NAME, JOB_SUBNAME, CHAIN_OWNER, CHAIN_NAME, STEP_NAME, STATE, ERROR_CODE, COMPLETED, START_DATE,
             END_DATE, DURATION, SKIP, PAUSE, PAUSE_BEFORE, RESTART_ON_RECOVERY, RESTART_ON_FAILURE, STEP_JOB_SUBNAME,
             STEP_JOB_LOG_ID)
as
SELECT jo.name, jo.subname, cu.name, co.name, cv.var_name,
    DECODE(BITAND(jss.flags,2),2,
      DECODE(jss.status, 'K', 'PAUSED', 'F', 'PAUSED', 'R', 'RUNNING',
        'C', 'SCHEDULED', 'E', 'RETRY SCHEDULED', 'T', 'STALLED', 'P','PAUSED',
        'NOT_STARTED'),
      DECODE(jss.status, 'K', 'STOPPED', 'R', 'RUNNING', 'C', 'SCHEDULED', 'E',
        'RETRY SCHEDULED', 'T', 'STALLED', 'P', 'PAUSED', 'F',
        DECODE(jss.error_code,0,'SUCCEEDED','FAILED'), 'NOT_STARTED')),
    jss.error_code, DECODE(jss.status, 'F', 'TRUE', 'K', 'TRUE','FALSE'),
    jss.start_date, jss.end_date,
    (CASE WHEN jss.end_date>jss.start_date THEN jss.end_date-jss.start_date
       ELSE NULL END),
    DECODE(BITAND(jss.flags,1),0,'FALSE',1,'TRUE',
      DECODE(BITAND(cv.flags,1),0,'FALSE',1,'TRUE')),
    DECODE(BITAND(jss.flags,2),0,'FALSE',2,'TRUE',
      DECODE(BITAND(cv.flags,2),0,'FALSE',2,'TRUE')),
    DECODE(BITAND(jss.flags,512),0,'FALSE',512,'TRUE',
      DECODE(BITAND(cv.flags,512),0,'FALSE',512,'TRUE')),
    DECODE(BITAND(jss.flags,64),0,'FALSE',64,'TRUE',
      DECODE(BITAND(cv.flags,64),0,'FALSE',64,'TRUE')),
    DECODE(BITAND(jss.flags,128),0,'FALSE',128,'TRUE',
      DECODE(BITAND(cv.flags,128),0,'FALSE',128,'TRUE')),
    jso.subname, jss.job_step_log_id
  FROM sys.scheduler$_job j
     JOIN obj$ jo ON (j.obj# = jo.obj# AND jo.owner# = USERENV('SCHEMAID'))
     JOIN obj$ co ON (co.obj# = j.program_oid)
     JOIN user$ cu ON (co.owner# = cu.user#)
     JOIN scheduler$_step cv ON (cv.oid = j.program_oid)
     LEFT OUTER JOIN scheduler$_step_state jss
       ON (jss.job_oid = j.obj# AND jss.step_name = cv.var_name)
     LEFT OUTER JOIN obj$ jso ON (jss.job_step_oid = jso.obj#)
     WHERE (BITAND(j.job_status,2+256) != 0 OR jo.subname IS NOT NULL)
/

comment on table USER_SCHEDULER_RUNNING_CHAINS is 'All steps of chains being run by jobs owned by the current user'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.JOB_NAME is 'Name of the job which is running the chain'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.JOB_SUBNAME is 'Subname of the job which is running the chain (for a subchain)'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.CHAIN_OWNER is 'Owner of the chain being run'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.CHAIN_NAME is 'Name of the chain being run'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.STEP_NAME is 'Name of this step of the running chain'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.STATE is 'State of this step'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.ERROR_CODE is 'Error code of this step, if it has finished running'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.COMPLETED is 'Whether this step has completed'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.START_DATE is 'When this step started, if it has already started'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.END_DATE is 'When this job step finished running, if it has finished running'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.DURATION is 'How long this step took to complete, if it has completed'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.SKIP is 'Whether this step will be skipped or not'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.PAUSE is 'Whether this step will be paused after running or not'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.PAUSE_BEFORE is 'Whether this step will be paused before running or not'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.RESTART_ON_RECOVERY is 'Whether this step will be restarted on database recovery'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.RESTART_ON_FAILURE is 'Whether this step should be retried on application failure'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.STEP_JOB_SUBNAME is 'Subname of the job running this step, if the step job has been created'
/

comment on column USER_SCHEDULER_RUNNING_CHAINS.STEP_JOB_LOG_ID is 'Log id of the step job if it has completed and has been logged.'
/


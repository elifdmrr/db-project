create view KU$_SIMPLE_SETID_COL_VIEW
            (OBJ_NUM, COL_NUM, INTCOL_NUM, SEGCOL_NUM, PROPERTY, NAME, ATTRNAME, TYPE_NUM, DEFLENGTH, DEFAULT_VAL,
             COL_EXPR) as
select c.obj#,
         c.col#,
         c.intcol#,
         c.segcol#,
         (c.property + BITAND(c2.property,1)),
         c2.name,
         (select a.name
          from attrcol$ a
          where a.obj# = c2.obj# and
                a.intcol# = c2.intcol#),
         c.type#,
         c.deflength,
         sys.dbms_metadata_util.long2clob(c.deflength,
                                          'SYS.COL$',
                                          'DEFAULT$',
                                          c.rowid),
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
           then null
           else
            (select sys.dbms_metadata.parse_default(u.name,o.name,
                                                    c.deflength,c.rowid)
             from obj$ o, user$ u
             where o.obj#=c.obj# and o.owner#=u.user#)
         end
  from col$ c, col$ c2
  where BITAND(c.property, 1024) = 1024 and                  /* SETID column */
        c2.obj# = c.obj# and
        c2.col# = c.col# and
        c2.intcol# = (c.intcol# - 1) and
        c2.segcol# = 0
/


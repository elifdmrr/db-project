create view DBA_HIST_DB_CACHE_ADVICE
            (SNAP_ID, DBID, INSTANCE_NUMBER, BPID, BUFFERS_FOR_ESTIMATE, NAME, BLOCK_SIZE, ADVICE_STATUS,
             SIZE_FOR_ESTIMATE, SIZE_FACTOR, PHYSICAL_READS, BASE_PHYSICAL_READS, ACTUAL_PHYSICAL_READS,
             ESTD_PHYSICAL_READ_TIME)
as
select db.snap_id, db.dbid, db.instance_number,
       bpid, buffers_for_estimate,
       name, block_size, advice_status, size_for_estimate,
       size_factor, physical_reads, base_physical_reads,
       actual_physical_reads, estd_physical_read_time
from WRM$_SNAPSHOT sn, WRH$_DB_CACHE_ADVICE db
where      db.snap_id          = sn.snap_id
      and  db.dbid             = sn.dbid
      and  db.instance_number  = sn.instance_number
      and  sn.status           = 0
/

comment on table DBA_HIST_DB_CACHE_ADVICE is 'DB Cache Advice History Information'
/


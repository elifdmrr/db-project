create view DBA_SCHEDULER_JOBS
            (OWNER, JOB_NAME, JOB_SUBNAME, JOB_STYLE, JOB_CREATOR, CLIENT_ID, GLOBAL_UID, PROGRAM_OWNER, PROGRAM_NAME,
             JOB_TYPE, JOB_ACTION, NUMBER_OF_ARGUMENTS, SCHEDULE_OWNER, SCHEDULE_NAME, SCHEDULE_TYPE, START_DATE,
             REPEAT_INTERVAL, EVENT_QUEUE_OWNER, EVENT_QUEUE_NAME, EVENT_QUEUE_AGENT, EVENT_CONDITION, EVENT_RULE,
             FILE_WATCHER_OWNER, FILE_WATCHER_NAME, END_DATE, JOB_CLASS, ENABLED, AUTO_DROP, RESTARTABLE, STATE,
             JOB_PRIORITY, RUN_COUNT, MAX_RUNS, FAILURE_COUNT, MAX_FAILURES, RETRY_COUNT, LAST_START_DATE,
             LAST_RUN_DURATION, NEXT_RUN_DATE, SCHEDULE_LIMIT, MAX_RUN_DURATION, LOGGING_LEVEL, STOP_ON_WINDOW_CLOSE,
             INSTANCE_STICKINESS, RAISE_EVENTS, SYSTEM, JOB_WEIGHT, NLS_ENV, SOURCE, NUMBER_OF_DESTINATIONS,
             DESTINATION_OWNER, DESTINATION, CREDENTIAL_OWNER, CREDENTIAL_NAME, INSTANCE_ID, DEFERRED_DROP,
             ALLOW_RUNS_IN_RESTRICTED_MODE, COMMENTS, FLAGS)
as
SELECT ju.name, jo.name, jo.subname, 'REGULAR',
    j.creator, j.client_id, j.guid,
    DECODE(bitand(j.flags,4194304),4194304,
      substr(j.program_action,1,instr(j.program_action,'"')-1),NULL),
    DECODE(bitand(j.flags,4194304),4194304,
      substr(j.program_action,instr(j.program_action,'"')+1,
        length(j.program_action)-instr(j.program_action,'"')) ,NULL),
    DECODE(BITAND(j.flags,131072+262144+2097152+524288),
      131072, 'PLSQL_BLOCK', 262144, 'STORED_PROCEDURE',
      2097152, 'EXECUTABLE', 524288, 'CHAIN', NULL),
    DECODE(bitand(j.flags,4194304),0,j.program_action,NULL), j.number_of_args,
    DECODE(bitand(j.flags,1024+4096),0,NULL,
      substr(j.schedule_expr,1,instr(j.schedule_expr,'"')-1)),
    DECODE(bitand(j.flags,1024+4096),0,NULL,
      substr(j.schedule_expr,instr(j.schedule_expr,'"') + 1,
        length(j.schedule_expr)-instr(j.schedule_expr,'"'))),
    DECODE(BITAND(j.flags, 1+2+512+1024+2048+4096+8192+16384+134217728+34359738368),
      512,'PLSQL',1024,'NAMED',2048,'CALENDAR',4096,'WINDOW',4098,'WINDOW_GROUP',
      8192,'ONCE',16384,'IMMEDIATE',34493956096, 'FILE_WATCHER',
      134217728,'EVENT',NULL),
    j.start_date,
    DECODE(BITAND(j.flags,1024+4096+134217728), 0, j.schedule_expr, NULL),
    j.queue_owner, j.queue_name, j.queue_agent,
    DECODE(BITAND(j.flags,134217728), 0, NULL,
      DECODE(BITAND(j.flags,1024+4096), 0, j.schedule_expr, NULL)),
    j.event_rule,
    DECODE(BITAND(j.flags, 34359738368), 0, NULL,
      substr(j.fw_name,1,instr(j.fw_name,'"')-1)),
    DECODE(BITAND(j.flags, 34359738368), 0, NULL,
      substr(j.fw_name,instr(j.fw_name,'"') + 1,
        length(j.fw_name)-instr(j.fw_name,'"'))),
    j.end_date, co.name,
    DECODE(BITAND(j.job_status,1),0,'FALSE','TRUE'),
    DECODE(BITAND(j.flags,32768),0,'TRUE','FALSE'),
    DECODE(BITAND(j.flags,65536),0,'FALSE','TRUE'),
    (CASE WHEN j.job_dest_id <> 0 AND
     bitand(j.flags, 549755813888) <> 0 THEN 'RUNNING'
     ELSE
     DECODE(BITAND(j.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
       DECODE(BITAND(j.job_status,1+4+8+16+32+128+8192+524288),0,'DISABLED',1,
        (CASE WHEN j.retry_count>0 THEN 'RETRY SCHEDULED'
            WHEN (bitand(j.job_status, 1024) <> 0) THEN 'READY TO RUN'
            ELSE 'SCHEDULED' END),
        4,'COMPLETED',8,'BROKEN',16,'FAILED',
        32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED',
        524288, 'SOME FAILED', NULL))END),
    j.priority, j.run_count, j.max_runs, j.failure_count, j.max_failures,
    j.retry_count,
    j.last_start_date,
    (CASE WHEN j.last_end_date>j.last_start_date THEN j.last_end_date-j.last_start_date
       ELSE NULL END), j.next_run_date,
    j.schedule_limit, j.max_run_duration,
    DECODE(BITAND(j.flags,32+64+128+256),32,'OFF',64,'RUNS',128,'FAILED RUNS',
      256,'FULL',NULL),
    DECODE(BITAND(j.flags,8),0,'FALSE','TRUE'),
    DECODE(BITAND(j.flags,16),0,'FALSE','TRUE'),
    /* BITAND(j.job_status, 16711680)/65536, */
    sys.dbms_scheduler.generate_event_list(j.job_status),
    DECODE(BITAND(j.flags,16777216),0,'FALSE','TRUE'),
    j.job_weight, j.nls_env,
    j.source,
    decode(bitand(j.flags, 274877906944), 0, 1,
    decode(bitand(j.flags, 549755813888), 0, 1,
    (select count(*) from dba_scheduler_job_dests djd
     where djd.owner = ju.name and djd.job_name = jo.name))),
    decode(bitand(j.flags, 274877906944), 0, NULL,
       substr(j.destination, 1, instr(j.destination, '"')-1)),
    decode(bitand(j.flags, 274877906944), 0, j.destination,
    substr(j.destination, instr(j.destination, '"')+1,
           length(j.destination) - instr(j.destination, '"'))),
    j.credential_owner, j.credential_name,
    j.instance_id,
    DECODE(BITAND(j.job_status,131072),0,'FALSE','TRUE'),
    DECODE(BITAND(j.flags,17179869184),0,'FALSE','TRUE'),
    j.comments, j.flags
  FROM obj$ jo, user$ ju, obj$ co, sys.scheduler$_job j, v$database v
  WHERE j.obj# = jo.obj# AND jo.owner# = ju.user# AND j.class_oid = co.obj#(+)
  AND (j.database_role = v.database_role OR
      (j.database_role is null AND v.database_role = 'PRIMARY'))
 UNION ALL
  SELECT lu.name, lo.name, lo.subname, 'LIGHTWEIGHT', l.creator, l.client_id, l.guid,
    lu.name, po.name, NULL, NULL, NULL,
    DECODE(bitand(l.flags,1024+4096),0,NULL,
      substr(l.schedule_expr,1,instr(l.schedule_expr,'"')-1)),
    DECODE(bitand(l.flags,1024+4096),0,NULL,
      substr(l.schedule_expr,instr(l.schedule_expr,'"') + 1,
        length(l.schedule_expr)-instr(l.schedule_expr,'"'))),
    DECODE(BITAND(l.flags, 1+2+512+1024+2048+4096+8192+16384+134217728+34359738368),
      512,'PLSQL',1024,'NAMED',2048,'CALENDAR',4096,'WINDOW',4098,'WINDOW_GROUP',
      8192,'ONCE',16384,'IMMEDIATE',34493956096, 'FILE_WATCHER',
      134217728,'EVENT',NULL),
    l.start_date,
    DECODE(BITAND(l.flags,1024+4096+134217728), 0, l.schedule_expr, NULL),
    l.queue_owner, l.queue_name, l.queue_agent,
    DECODE(BITAND(l.flags,134217728), 0, NULL,
      DECODE(BITAND(l.flags,1024+4096), 0, l.schedule_expr, NULL)),
    l.event_rule,
    DECODE(BITAND(l.flags, 34359738368), 0, NULL,
      substr(l.fw_name,1,instr(l.fw_name,'"')-1)),
    DECODE(BITAND(l.flags, 34359738368), 0, NULL,
      substr(l.fw_name,instr(l.fw_name,'"') + 1,
        length(l.fw_name)-instr(l.fw_name,'"'))),
    l.end_date, lco.name,
    DECODE(BITAND(l.job_status,1),0,'FALSE','TRUE'),
    DECODE(BITAND(l.flags,32768),0,'TRUE','FALSE'),
    DECODE(BITAND(l.flags,65536),0,'FALSE','TRUE'),
    DECODE(BITAND(l.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
    DECODE(BITAND(l.job_status,1+4+8+16+32+128+8192),0,'DISABLED',1,
      (CASE WHEN l.retry_count>0 THEN 'RETRY SCHEDULED'
            WHEN (bitand(l.job_status, 1024) <> 0) THEN 'READY TO RUN'
            ELSE 'SCHEDULED' END),
      4,'COMPLETED',8,'BROKEN',16,'FAILED',
      32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED', NULL)),
    NULL, l.run_count, NULL, l.failure_count, NULL,
    l.retry_count, l.last_start_date,
    (CASE WHEN l.last_end_date>l.last_start_date THEN l.last_end_date-l.last_start_date
       ELSE NULL END), l.next_run_date,
    NULL, NULL,
    DECODE(BITAND(l.flags,32+64+128+256),32,'OFF',64,'RUNS',128,'FAILED RUNS',
      256,'FULL',NULL),
    DECODE(BITAND(l.flags,8),0,'FALSE','TRUE'),
    DECODE(BITAND(l.flags,16),0,'FALSE','TRUE'),
    /* BITAND(j.job_status, 16711680)/65536, */
    sys.dbms_scheduler.generate_event_list(l.job_status),
    DECODE(BITAND(l.flags,16777216),0,'FALSE','TRUE'),
    NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, l.instance_id,
    DECODE(BITAND(l.job_status,131072),0,'FALSE','TRUE'),
    DECODE(BITAND(l.flags,17179869184),0,'FALSE','TRUE'),
    NULL, l.flags
  FROM scheduler$_lwjob_obj lo, user$ lu, obj$ lco,
    scheduler$_lightweight_job l, obj$ po
  WHERE ((bitand(l.flags, 8589934592) = 0 AND po.type# = 67) OR
         (bitand(l.flags, 8589934592) <> 0 AND po.type# = 66))
    AND bitand(l.flags, 137438953472) = 0
    AND l.obj# = lo.obj# AND l.program_oid = po.obj#
    AND lo.userid = lu.user# AND l.class_oid = lco.obj#(+)
/

comment on table DBA_SCHEDULER_JOBS is 'All scheduler jobs in the database'
/

comment on column DBA_SCHEDULER_JOBS.OWNER is 'Owner of the scheduler job'
/

comment on column DBA_SCHEDULER_JOBS.JOB_NAME is 'Name of the scheduler job'
/

comment on column DBA_SCHEDULER_JOBS.JOB_SUBNAME is 'Subname of the scheduler job (for a job running a chain step)'
/

comment on column DBA_SCHEDULER_JOBS.JOB_STYLE is 'Job style - regular, lightweight or volatile'
/

comment on column DBA_SCHEDULER_JOBS.JOB_CREATOR is 'Original creator of this job'
/

comment on column DBA_SCHEDULER_JOBS.CLIENT_ID is 'Client id of user creating job'
/

comment on column DBA_SCHEDULER_JOBS.GLOBAL_UID is 'Global uid of user creating this job'
/

comment on column DBA_SCHEDULER_JOBS.PROGRAM_OWNER is 'Owner of the program associated with the job'
/

comment on column DBA_SCHEDULER_JOBS.PROGRAM_NAME is 'Name of the program associated with the job'
/

comment on column DBA_SCHEDULER_JOBS.JOB_TYPE is 'Inlined job action type'
/

comment on column DBA_SCHEDULER_JOBS.JOB_ACTION is 'Inlined job action'
/

comment on column DBA_SCHEDULER_JOBS.NUMBER_OF_ARGUMENTS is 'Inlined job number of arguments'
/

comment on column DBA_SCHEDULER_JOBS.SCHEDULE_OWNER is 'Owner of the schedule that this job uses (can be a window or window group)'
/

comment on column DBA_SCHEDULER_JOBS.SCHEDULE_NAME is 'Name of the schedule that this job uses (can be a window or window group)'
/

comment on column DBA_SCHEDULER_JOBS.SCHEDULE_TYPE is 'Type of the schedule that this job uses'
/

comment on column DBA_SCHEDULER_JOBS.START_DATE is 'Original scheduled start date of this job (for an inlined schedule)'
/

comment on column DBA_SCHEDULER_JOBS.REPEAT_INTERVAL is 'Inlined schedule PL/SQL expression or calendar string'
/

comment on column DBA_SCHEDULER_JOBS.EVENT_QUEUE_OWNER is 'Owner of source queue into which event will be raised'
/

comment on column DBA_SCHEDULER_JOBS.EVENT_QUEUE_NAME is 'Name of source queue into which event will be raised'
/

comment on column DBA_SCHEDULER_JOBS.EVENT_QUEUE_AGENT is 'Name of AQ agent used by user on the event source queue (if it is a secure queue)'
/

comment on column DBA_SCHEDULER_JOBS.EVENT_CONDITION is 'Boolean expression used as subscription rule for event on the source queue'
/

comment on column DBA_SCHEDULER_JOBS.EVENT_RULE is 'Name of rule used by the coordinator to trigger event based job'
/

comment on column DBA_SCHEDULER_JOBS.FILE_WATCHER_OWNER is 'Owner of file watcher on which this job is based'
/

comment on column DBA_SCHEDULER_JOBS.FILE_WATCHER_NAME is 'Name of file watcher on which this job is based'
/

comment on column DBA_SCHEDULER_JOBS.END_DATE is 'Date after which this job will no longer run (for an inlined schedule)'
/

comment on column DBA_SCHEDULER_JOBS.JOB_CLASS is 'Name of job class associated with the job'
/

comment on column DBA_SCHEDULER_JOBS.ENABLED is 'Whether the job is enabled'
/

comment on column DBA_SCHEDULER_JOBS.AUTO_DROP is 'Whether this job will be dropped when it has completed'
/

comment on column DBA_SCHEDULER_JOBS.RESTARTABLE is 'Whether this job can be restarted or not'
/

comment on column DBA_SCHEDULER_JOBS.STATE is 'Current state of the job'
/

comment on column DBA_SCHEDULER_JOBS.JOB_PRIORITY is 'Priority of the job relative to others within the same class'
/

comment on column DBA_SCHEDULER_JOBS.RUN_COUNT is 'Number of times this job has run'
/

comment on column DBA_SCHEDULER_JOBS.MAX_RUNS is 'Maximum number of times this job is scheduled to run'
/

comment on column DBA_SCHEDULER_JOBS.FAILURE_COUNT is 'Number of times this job has failed to run'
/

comment on column DBA_SCHEDULER_JOBS.MAX_FAILURES is 'Number of times this job will be allowed to fail before being marked broken'
/

comment on column DBA_SCHEDULER_JOBS.RETRY_COUNT is 'Number of times this job has retried, if it is retrying.'
/

comment on column DBA_SCHEDULER_JOBS.LAST_START_DATE is 'Last date on which the job started running'
/

comment on column DBA_SCHEDULER_JOBS.LAST_RUN_DURATION is 'How long the job took last time'
/

comment on column DBA_SCHEDULER_JOBS.NEXT_RUN_DATE is 'Next date the job is scheduled to run on'
/

comment on column DBA_SCHEDULER_JOBS.SCHEDULE_LIMIT is 'Time in minutes after which a job which has not run yet will be rescheduled'
/

comment on column DBA_SCHEDULER_JOBS.MAX_RUN_DURATION is 'This column is reserved for future use'
/

comment on column DBA_SCHEDULER_JOBS.LOGGING_LEVEL is 'Amount of logging that will be done pertaining to this job'
/

comment on column DBA_SCHEDULER_JOBS.STOP_ON_WINDOW_CLOSE is 'Whether this job will stop if a window it is associated with closes'
/

comment on column DBA_SCHEDULER_JOBS.INSTANCE_STICKINESS is 'Whether this job is sticky'
/

comment on column DBA_SCHEDULER_JOBS.RAISE_EVENTS is 'List of job events to raise for this job'
/

comment on column DBA_SCHEDULER_JOBS.SYSTEM is 'Whether this is a system job'
/

comment on column DBA_SCHEDULER_JOBS.JOB_WEIGHT is 'Weight of this job'
/

comment on column DBA_SCHEDULER_JOBS.NLS_ENV is 'NLS environment of this job'
/

comment on column DBA_SCHEDULER_JOBS.SOURCE is 'Source global database identifier'
/

comment on column DBA_SCHEDULER_JOBS.DESTINATION_OWNER is 'Owner of destination object (if used) else NULL'
/

comment on column DBA_SCHEDULER_JOBS.DESTINATION is 'Destination that this job will run on'
/

comment on column DBA_SCHEDULER_JOBS.CREDENTIAL_OWNER is 'Owner of login credential'
/

comment on column DBA_SCHEDULER_JOBS.CREDENTIAL_NAME is 'Name of login credential'
/

comment on column DBA_SCHEDULER_JOBS.INSTANCE_ID is 'Instance user requests job to run on.'
/

comment on column DBA_SCHEDULER_JOBS.DEFERRED_DROP is 'Whether this job will be dropped when completed due to user request.'
/

comment on column DBA_SCHEDULER_JOBS.COMMENTS is 'Comments on the job'
/

comment on column DBA_SCHEDULER_JOBS.FLAGS is 'This column is for internal use.'
/


create view KU$_TTS_IDX_TABLESPACE_VIEW (OBJ_NUM, PARTOBJ, TS_NAME) as
SELECT "OBJ_NUM","PARTOBJ","TS_NAME" FROM ku$_tts_indpartview
  UNION ALL
    SELECT "OBJ_NUM","PARTOBJ","TS_NAME" FROM ku$_tts_indsubpartview
/


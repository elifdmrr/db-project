create view DBA_AUTOTASK_SCHEDULE (WINDOW_NAME, START_TIME, DURATION) as
SELECT "WINDOW_NAME","START_TIME","DURATION"
    FROM TABLE (dbms_auto_task.window_calendar(
                CURSOR(SELECT wgr.window_name,
                              case when w.start_date > current_timestamp
                                   then w.start_date
                                   else current_timestamp
                              end,
                              case when w.end_date <
                                       (current_timestamp + INTERVAL '32' DAY)
                                   then w.end_date
                                   else current_timestamp + INTERVAL '32' DAY
                              end
                         FROM dba_scheduler_windows w,
                              dba_scheduler_wingroup_members wgr
                        WHERE w.window_name = wgr.window_name
                          AND w.enabled = 'TRUE'
                          AND (w.start_date IS NULL
                               OR w.start_date < current_timestamp + INTERVAL '32' DAY)
                          AND wgr.window_group_name = 'MAINTENANCE_WINDOW_GROUP')))
/

comment on table DBA_AUTOTASK_SCHEDULE is 'Schedule of Maintenance Windows for the next 32 days'
/

comment on column DBA_AUTOTASK_SCHEDULE.WINDOW_NAME is 'Name of the Maintenance Window'
/

comment on column DBA_AUTOTASK_SCHEDULE.START_TIME is 'Projected start time of the window'
/

comment on column DBA_AUTOTASK_SCHEDULE.DURATION is 'Currently defined duration of the window'
/


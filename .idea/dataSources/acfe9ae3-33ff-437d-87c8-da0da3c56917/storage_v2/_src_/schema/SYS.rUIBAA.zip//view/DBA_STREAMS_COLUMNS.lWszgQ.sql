create view DBA_STREAMS_COLUMNS
            (OWNER, TABLE_NAME, COLUMN_NAME, SYNC_CAPTURE_VERSION, SYNC_CAPTURE_REASON, APPLY_VERSION, APPLY_REASON) as
select distinct u.name, o.name, c.name,
                                                    /* sync capture version */
    (case
      when bitand(t.property, 1                              /* typed table */
                             + 131072                           /* AQ table */
                             + 134217728                       /* Sub table */
                             + 4194304                        /* temp table */
                             + 8388608                        /* temp table */
                             + 2147483648                 /* external table */
                 ) != 0 or
            bitand(o.flags, 16) != 0 or                     /* domain index */
            (exists                                /* materialized view log */
              (select 1
                from   sys.mlog$ ml
                where  ml.mowner = u.name and ml.log = o.name)
            ) or
           bitand(t.trigflag, 268435456) != 0        /* streams unsupported */
       then NULL
      when c.segcol# = 0 and bitand(c.property, 65536+8) = 65544 and
                             bitand(c.property, 32) = 0
       then 11.1                                          /* virtual column */
      when c.type#  IN
                  (1,                                        /* (N)VARCHAR2 */
                   2,                                             /* NUMBER */
                   12,                                              /* DATE */
                   23,                                               /* RAW */
                   96,                                           /* (N)CHAR */
                   100,                                     /* BINARY_FLOAT */
                   101,                                    /* BINARY_DOUBLE */
                   180,                                        /* TIMESTAMP */
                   182,                           /* INTERVAL YEAR TO MONTH */
                   183,                           /* INTERVAL DAY TO SECOND */
                   181,                         /* TIMESTAMP WITH TIME ZONE */
                   208,                                           /* UROWID */
                   231) then 11.1         /* TIMESTAMP WITH LOCAL TIME ZONE */
      when c.type# in (112, 113) or                       /* securefile/lob */
            c.type# = 69 or
            bitand(t.property, 4                    /* nested table columns */
                            + 8                              /* REF columns */
                            + 4096                                /* pk OID */
                            + 8192 /* storage table for nested table column */
                            + 32768                   /* FILE column exists */
                            + 65536                                 /* sOID */
                    ) != 0 or
            c.type# = 123 or                                /* array column */
            bitand(c.property, 2) != 0 or                     /* OID column */
           c.type# = 121                                      /* ADT column */
        then NULL
      else NULL end)
    sync_capture_version,
    (case
      when  bitand(t.property, 1) != 0                       /* typed table */
        then 'object table'
      when bitand(t.property, 131072) != 0                      /* AQ table */
        then 'AQ queue table'
       when bitand(t.property, 134217728) != 0                 /* Sub table */
        then 'sub table'
      when bitand(t.property, 4194304 + 8388608) != 0         /* temp table */
        then 'temp table'
      when bitand(t.property, 2147483648) !=0             /* external table */
        then 'external table'
      when bitand(o.flags, 16) != 0                         /* domain index */
        then 'domain index'
      when (exists                                 /* materialized view log */
             (select 1
              from   sys.mlog$ ml
              where  ml.mowner = u.name and ml.log = o.name)
            )
        then 'materialized view log'
      when  bitand(t.property, 8192) != 0
        then 'storage table for nested table column'
      when bitand(t.trigflag, 268435456) != 0         /*streams unsupported */
         then 'streams unsupported object'
      when c.segcol# = 0 and
           (bitand(c.property, 65536+8) != 65544 or  /* not virtual column */
            bitand(c.property, 32) = 32)
         then 'unsupported column'
      when c.type#  IN
                  (1,                                        /* (N)VARCHAR2 */
                   2,                                             /* NUMBER */
                   12,                                              /* DATE */
                   23,                                               /* RAW */
                   96,                                           /* (N)CHAR */
                   100,                                     /* BINARY_FLOAT */
                   101,                                    /* BINARY_DOUBLE */
                   180,                                        /* TIMESTAMP */
                   182,                           /* INTERVAL YEAR TO MONTH */
                   183,                           /* INTERVAL DAY TO SECOND */
                   181,                         /* TIMESTAMP WITH TIME ZONE */
                   208,                                           /* UROWID */
                   231) then NULL         /* TIMESTAMP WITH LOCAL TIME ZONE */
      when (c.type# IN (112, 113) and                         /* securefile */
            (exists (select 1
                     from lob$ l
                     where c.obj#=l.obj# and
                           c.col#=l.col# and
                           c.obj#=t.obj# and
                           bitand(l.property, 2048) != 0   /* 11g LOCAL lob */
                     ) or
             exists (select 1                     /* partitioned securefile */
                     from lob$ l, lobfrag$ lf
                     where c.obj#=l.obj# and
                           c.col#=l.col# and
                           c.obj#=t.obj# and
                           l.lobj#=lf.parentobj# and
                           bitand(l.property, 4) != 0 and/* partitioned LOB */
                           bitand(lf.fragpro, 2048) != 0   /* 11g LOCAL lob */
                     ) or
             exists (select 1           /* composite-partitioned securefile */
                     from lob$ l, lobcomppart$ p, lobfrag$ lf
                     where c.obj#=l.obj# and
                           c.obj#=t.obj# and
                           c.col#=l.col# and
                           l.lobj#=p.lobj# and
                           p.partobj#=lf.parentobj# and
                           bitand(l.property, 4) != 0 and/* partitioned LOB */
                           bitand(lf.fragpro, 2048) != 0)))/* 11g LOCAL lob */
         then 'securefile'
      when c.type# = 121 then 'ADT column'
      when c.type# = 69  then 'rowid column'
      when bitand(t.property, 8) != 0                         /* REF colunm */
        then 'table with REF column'
      when bitand(t.property, 4) != 0               /* nested table columns */
        then 'table with nested table column'
      when c.type# = 123                                   /* array columns */
        then 'array column'
      when bitand(t.property, 4096) != 0                          /* pk OID */
        then 'table with primary key based oid column'
      when bitand(t.property, 32768) != 0             /* FILE column exists */
        then 'table with FILE column'
      when bitand(t.property, 65536) != 0                           /* sOID */
        then 'table with system generated OID'
      when bitand(c.property, 2) != 0                         /* OID column */
        then 'table with OID column'
      when c.type# = 8 then  'long column'                          /* LONG */
      when c.type# = 24 then 'long raw column'                  /* LONG RAW */
      when c.type# = 112 then '(N)CLOB column'                   /* (N)CLOB */
      when c.type# = 113 then  'BLOB column'                        /* BLOB */
      else 'Streams unsupported object' end) sync_capture_reason,
                                                           /* apply version */
    (case
       when bitand(t.property, 1                             /* typed table */
                             + 131072                           /* AQ table */
                             + 134217728                       /* Sub table */
                             + 4194304                        /* temp table */
                             + 8388608                        /* temp table */
                             + 2147483648                 /* external table */
                  ) != 0 or
             bitand(o.flags, 16) != 0 or                    /* domain index */
             (exists                               /* materialized view log */
              (select 1
                from   sys.mlog$ ml
                where  ml.mowner = u.name and ml.log = o.name)
             ) or
             bitand(t.trigflag, 268435456) != 0       /*streams unsupported */
         then NULL
       when exists (select 1 from sys.partobj$ p
                    where p.obj# = o.obj# and
                          p.parttype = 3)               /* system partition */
         then NULL
       when c.segcol# = 0 and bitand(c.property, 65544) = 65544 and
                              bitand(c.property, 32) = 0
         then 11.1                                        /* virtual column */
       when c.segcol# = 0 and bitand(c.property, 65536+32+8) = 65576
         then 10.1                                      /* functional index */
       when (bitand(c.property, 67108864 + 536870912) != 0 and       /* TDE */
             c.type# IN
                  (1,                                        /* (N)VARCHAR2 */
                   2,                                             /* NUMBER */
                   8,                                               /* LONG */
                   12,                                              /* DATE */
                   23,                                               /* RAW */
                   24,                                          /* LONG RAW */
                   96,                                           /* (N)CHAR */
                   100,                                     /* BINARY_FLOAT */
                   101,                                    /* BINARY_DOUBLE */
                   112,                                          /* (N)CLOB */
                   113,                                             /* BLOB */
                   180,                                        /* TIMESTAMP */
                   182,                           /* INTERVAL YEAR TO MONTH */
                   183,                           /* INTERVAL DAY TO SECOND */
                   181,                         /* TIMESTAMP WITH TIME ZONE */
                   208,                                           /* UROWID */
                   231)) then 11.1        /* TIMESTAMP WITH LOCAL TIME ZONE */
       when ((bitand(t.property, 262208) = 262208 or      /* IOT + user LOB */
              bitand(t.property, 128 + 512) != 0 or/* IOT with row overflow */
              bitand(t.property, 2112) = 2122 or      /* IOT + internal LOB */
              bitand(t.property, 256) != 0 or    /* IOT with row clustering */
              (bitand(t.property, 64) != 0 and
               bitand(t.flags, 131072) != 0) or    /* IOT with row movement */
                                         /* IOT with physical Rowid mapping */
             bitand(t.flags, 268435456) != 0 or
                                 /* Mapping table for physical rowid of IOT */
             bitand(t.flags, 536870912) != 0) and
             c.type# IN
                  (1,                                        /* (N)VARCHAR2 */
                   2,                                             /* NUMBER */
                   8,                                               /* LONG */
                   12,                                              /* DATE */
                   23,                                               /* RAW */
                   24,                                          /* LONG RAW */
                   96,                                           /* (N)CHAR */
                   100,                                     /* BINARY_FLOAT */
                   101,                                    /* BINARY_DOUBLE */
                   112,                                          /* (N)CLOB */
                   113,                                             /* BLOB */
                   180,                                        /* TIMESTAMP */
                   182,                           /* INTERVAL YEAR TO MONTH */
                   183,                           /* INTERVAL DAY TO SECOND */
                   181,                         /* TIMESTAMP WITH TIME ZONE */
                   208,                                           /* UROWID */
                   231)) then 10.2        /* TIMESTAMP WITH LOCAL TIME ZONE */
       when ((bitand(t.property, 64) != 0 or                         /* IOT */
                                                       /* materialized view */
              bitand(t.property, 33554432 + 67108864) != 0 or
                                       /* materialized view container table */
              bitand(t.flags, 262144) != 0 ) and
             c.type# IN
                  (1,                                        /* (N)VARCHAR2 */
                   2,                                             /* NUMBER */
                   8,                                               /* LONG */
                   12,                                              /* DATE */
                   23,                                               /* RAW */
                   24,                                          /* LONG RAW */
                   96,                                           /* (N)CHAR */
                   100,                                     /* BINARY_FLOAT */
                   101,                                    /* BINARY_DOUBLE */
                   112,                                          /* (N)CLOB */
                   113,                                             /* BLOB */
                   180,                                        /* TIMESTAMP */
                   182,                           /* INTERVAL YEAR TO MONTH */
                   183,                           /* INTERVAL DAY TO SECOND */
                   181,                         /* TIMESTAMP WITH TIME ZONE */
                   208,                                           /* UROWID */
                   231)) then 10.1        /* TIMESTAMP WITH LOCAL TIME ZONE */
       when c.type# in (1,                                   /* (N)VARCHAR2 */
                        2,                                        /* NUMBER */
                        12,                                         /* DATE */
                        23,                                          /* RAW */
                        96,                                      /* (N)CHAR */
                        113,                                        /* BLOB */
                        180,                                   /* TIMESTAMP */
                        181,                    /* TIMESTAMP WITH TIME ZONE */
                        182,                      /* INTERVAL YEAR TO MONTH */
                        183,                      /* INTERVAL DAY TO SECOND */
                        231) then 9.2     /* TIMESTAMP WITH LOCAL TIME ZONE */
       when c.type# in (8,                                          /* LONG */
                        24,                                     /* LONG RAW */
                        100,                                /* BINARY_FLOAT */
                        101,                               /* BINARY_DOUBLE */
                        208) then 10.1                            /* UROWID */
      when (c.type# IN (112, 113) and                         /* securefile */
            (exists (select 1
                    from lob$ l
                    where c.obj#=l.obj# and
                          c.obj#=t.obj# and
                          c.col#=l.col# and
                          bitand(l.property, 2048) != 0     /* 11g LOCAL lob */
                    ) or
             exists (select 1                      /* partitioned securefile */
                   from lob$ l, lobfrag$ lf
                    where c.obj#=l.obj# and
                          c.obj#=t.obj# and
                          c.col#=l.col# and
                          l.lobj#=lf.parentobj# and
                          bitand(l.property, 4) != 0 and  /* partitioned LOB */
                          bitand(lf.fragpro, 2048) != 0     /* 11g LOCAL lob */
                    ) or
             exists (select 1            /* composite-partitioned securefile */
                    from lob$ l, lobcomppart$ p, lobfrag$ lf
                    where c.obj#=l.obj# and
                          c.obj#=t.obj# and
                          c.col#=l.col# and
                          l.lobj#=p.lobj# and
                          p.partobj#=lf.parentobj# and
                          bitand(l.property, 4) != 0 and /* partitioned LOB */
                          bitand(lf.fragpro, 2048) != 0))) /* 11g LOCAL lob */
         then 11.2
       when c.type# = 112 then
         (case
            when c.charsetform = 2 or
                 c.charsetform = 1 and c.charsetid >= 800
              then 10.1                                            /* NCLOB */
              else 9.2 end)                                         /* CLOB */
       when c.type# = 69 or
            bitand(t.property, 4                    /* nested table columns */
                            + 8                              /* REF columns */
                            + 4096                                /* pk OID */
                            + 8192 /* storage table for nested table column */
                            + 32768                   /* FILE column exists */
                            + 65536                                 /* sOID */
                    ) != 0 or
            c.type# = 123 or                                /* array column */
            bitand(c.property, 2) != 0 or                     /* OID column */
            c.type# = 121                                     /* ADT column */
        then NULL
     end) apply_version,
                                                            /* apply reason */
    (case
      when exists (select 1 from sys.partobj$ p
                   where p.obj# = o.obj# and
                         p.parttype = 3)                /* system partition */
        then 'table with system partition'
      when  bitand(t.property, 1) != 0                       /* typed table */
        then 'object table'
      when bitand(t.property, 131072) != 0                      /* AQ table */
        then 'AQ queue table'
      when bitand(t.property, 134217728) != 0                  /* Sub table */
        then 'sub table'
      when bitand(t.property, 4194304 + 8388608) != 0         /* temp table */
        then 'temp table'
      when bitand(t.property, 2147483648) !=0             /* external table */
        then 'external table'
      when bitand(o.flags, 16) != 0                         /* domain index */
        then 'domain index'
                                   /* storage table for nested table column */
      when  bitand(t.property, 8192) != 0
        then 'storage table for nested table column'
      when (exists                                 /* materialized view log */
             (select 1
              from   sys.mlog$ ml
              where  ml.mowner = u.name and ml.log = o.name)
            )
        then 'materialized view log'
      when bitand(t.trigflag, 268435456) != 0        /* streams unsupported */
         then 'Streams unsupported object'
      when (c.type# IN (112, 113) and                         /* securefile */
            (exists (select 1
                    from lob$ l
                    where c.obj#=l.obj# and
                          c.obj#=t.obj# and
                          c.col#=l.col# and
                          bitand(l.property, 2048) != 0    /* 11g LOCAL lob */
                    ) or
             exists (select 1                      /* partitioned securefile */
                   from lob$ l, lobfrag$ lf
                    where c.obj#=l.obj# and
                          c.obj#=t.obj# and
                          c.col#=l.col# and
                          l.lobj#=lf.parentobj# and
                          bitand(l.property, 4) != 0 and  /* partitioned LOB */
                          bitand(lf.fragpro, 2048) != 0     /* 11g LOCAL lob */
                     ) or
              exists (select 1           /* composite-partitioned securefile */
                     from lob$ l, lobcomppart$ p, lobfrag$ lf
                     where c.obj#=l.obj# and
                           c.obj#=t.obj# and
                           c.col#=l.col# and
                           l.lobj#=p.lobj# and
                           p.partobj#=lf.parentobj# and
                           bitand(l.property, 4) != 0 and/* partitioned LOB */
                           bitand(lf.fragpro, 2048) != 0)))/* 11g LOCAL lob */
        then 'securefile'
      when c.type# = 121 then 'ADT column'
      when c.type# = 69
        then 'rowid column'
      when c.type# = 123                                   /* array columns */
        then 'array column'
      when bitand(c.property, 67108864 + 536870912) != 0             /* TDE */
        then 'column encrypted'
      when bitand(t.property, 128 + 512) != 0      /* IOT with row overflow */
        then 'IOT with row overflow'
      when bitand(t.property, 262208) = 262208            /* IOT + user LOB */
        then 'IOT with user LOBs'
      when bitand(t.property, 2112) = 2112            /* IOT + internal LOB */
        then 'IOT with internal LOBs'
      when (bitand(t.property, 64) != 0 and        /* IOT with row movement */
            bitand(t.flags, 131072) != 0)
        then 'IOT with row movement'
                                         /* IOT with physical Rowid mapping */
      when bitand(t.flags, 268435456) != 0
        then 'IOT with physical rowid mapping'
                                 /* Mapping table for physical rowid of IOT */
      when bitand(t.flags, 536870912) != 0
        then 'mapping table for physical rowid of IOT '
      when bitand(t.property, 256) != 0          /* IOT with row clustering */
        then 'IOT with row clustering'
      when bitand(t.property, 64) != 0                         /* Basic IOT */
        then 'IOT'
      when bitand(t.property, 33554432 + 67108864) != 0/* materialized view */
        then 'materialized view'
      when bitand(t.flags, 262144) != 0/* materialized view container table */
        then 'materialized view container table'
      when c.segcol# = 0 and
             bitand(c.property, 65536+8) != 65544 and /* not virtual column */
             bitand(c.property, 65536+32+8) != 65576/* not functional index */
        then 'unsupported column'                     /* unsupported column */
      when c.type# in (1,                                    /* (N)VARCHAR2 */
                       2,                                         /* NUMBER */
                       12,                                          /* DATE */
                       96,                                       /* (N)CHAR */
                       23,                                           /* RAW */
                       113,                                         /* BLOB */
                       180,                                    /* TIMESTAMP */
                       182,                       /* INTERVAL YEAR TO MONTH */
                       183,                       /* INTERVAL DAY TO SECOND */
                       181,                     /* TIMESTAMP WITH TIME ZONE */
                       231) then NULL     /* TIMESTAMP WITH LOCAL TIME ZONE */
      when c.type# = 8 then 'long column'                           /* LONG */
      when c.type# = 24 then 'long raw column'                  /* LONG RAW */
      when c.type# = 100 then 'binary_float column'         /* BINARY_FLOAT */
      when c.type# = 101 then 'binary_double column'       /* BINARY_DOUBLE */
      when c.type# = 112 then
        (case
          when c.charsetform = 2
            then 'NCLOB column'                                    /* NCLOB */
          when c.charsetform = 1 and c.charsetid >= 800
            then 'varing length CLOB column'
            else NULL end)                                          /* CLOB */
      when c.type# = 208 then 'urowid'                            /* UROWID */
      when bitand(t.property, 4) != 0               /* nested table columns */
        then 'table with nested table column'
      when bitand(t.property, 8) != 0                        /* REF columns */
        then 'table with REF column'
      when bitand(t.property, 4096) != 0                          /* pk OID */
        then 'table with primary key based OID column'
      when bitand(t.property, 32768) != 0             /* FILE column exists */
        then 'table with FILE column'
      when bitand(t.property, 65536) != 0                           /* sOID */
        then 'table with system generated OID'
      when bitand(c.property, 2) != 0                         /* OID column */
        then 'oid column'
      else 'Streams unsupported object' end) apply_reason
  from sys.obj$ o, sys.user$ u, sys.tab$ t, sys.col$ c
  where c.obj# = o.obj# and
        c.type# <> 58 and
        o.obj# = t.obj# and
        o.owner# = u.user# and
        bitand(c.property, 32) = 0 and
                  /* should be consistent with knlcfIsFilteredSpecialSchema */
        u.name not in ('SYS', 'SYSTEM', 'CTXSYS', 'DBSNMP', 'LBACSYS',
                       'MDDATA', 'MDSYS', 'DMSYS', 'OLAPSYS', 'ORDPLUGINS',
                       'ORDSYS', 'SI_INFORMTN_SCHEMA', 'SYSMAN', 'OUTLN',
                       'EXFSYS', 'WMSYS', 'XDB', 'DVSYS', 'ORDDATA') and
        bitand(o.flags,
                  2                                     /* temporary object */
                + 4                              /* system generated object */
                + 32                                /* in-memory temp table */
                + 128                         /* dropped table (RecycleBin) */
                  ) = 0 and
        (
          bitand(t.property, 1                               /* typed table */
                             + 4                    /* nested table columns */
                             + 8                             /* REF columns */
                             + 4096                               /* pk OID */
                             + 8192/* storage table for nested table column */
                             + 32768                  /* FILE column exists */
                             + 65536                                /* sOID */
                             + 131072                           /* AQ table */
                             + 134217728                       /* Sub table */
                             + 4194304                        /* temp table */
                             + 8388608                        /* temp table */
                             + 2147483648                 /* external table */
                 ) != 0 or
          bitand(o.flags, 16) != 0 or                       /* domain index */
           (exists                                 /* materialized view log */
             (select 1
              from   sys.mlog$ ml
              where  ml.mowner = u.name and ml.log = o.name)
           ) or
           bitand(t.trigflag, 268435456) != 0 or     /* streams unsupported */
           (c.type# IN (112, 113) and                         /* securefile */
            (exists (select 1
                    from lob$ l
                    where c.obj#=l.obj# and c.col#=l.col# and
                    c.obj#=t.obj# and
                    bitand(l.property, 2048) != 0)) or    /* 11g LOCAL lob */
             exists (select 1                     /* partitioned securefile */
                    from lob$ l, lobfrag$ lf
                    where c.obj#=l.obj# and
                          c.obj#=t.obj# and
                          c.col#=l.col# and
                          l.lobj#=lf.parentobj# and
                          bitand(l.property, 4) != 0 and /* partitioned LOB */
                          bitand(lf.fragpro, 2048) != 0) or/* 11g LOCAL lob */
             exists (select 1           /* composite-partitioned securefile */
                     from lob$ l, lobcomppart$ p, lobfrag$ lf
                     where c.obj#=l.obj# and
                           c.obj#=t.obj# and
                           c.col#=l.col# and
                           l.lobj#=p.lobj# and
                           p.partobj#=lf.parentobj# and
                           bitand(l.property, 4) != 0 and/* partitioned LOB */
                           bitand(lf.fragpro, 2048) != 0)) or/*11g LOCAL lob*/
            c.type# = 69 or
            c.type# = 123 or                                /* array column */
            c.segcol# = 0 or                              /* virtual column */
            bitand(c.property, 2) != 0 or                     /* OID column */
            c.type# = 121 or                                  /* ADT column */
            c.type# IN
                  (1,                                        /* (N)VARCHAR2 */
                   2,                                             /* NUMBER */
                   8,                                               /* LONG */
                   12,                                              /* DATE */
                   23,                                               /* RAW */
                   24,                                          /* LONG RAW */
                   96,                                           /* (N)CHAR */
                   100,                                     /* BINARY_FLOAT */
                   101,                                    /* BINARY_DOUBLE */
                   112,                                          /* (N)CLOB */
                   113,                                             /* BLOB */
                   180,                                        /* TIMESTAMP */
                   182,                           /* INTERVAL YEAR TO MONTH */
                   183,                           /* INTERVAL DAY TO SECOND */
                   181,                         /* TIMESTAMP WITH TIME ZONE */
                   208,                                           /* UROWID */
                   231)
        )
union all
  select distinct u.name, o.name, c.name, NULL,     /* sync_capture_version */
    (case                                            /* sync_capture_reason */
      when exists (select 1 from sys.partobj$ p
                   where p.obj# = o.obj# and
                         p.parttype = 3)                /* system partition */
        then 'table with system partition'
      when op.type = 1 then                                     /* XML Type */
        (case when bitand(op.flags,512) ! = 0
                   then 'hierarchy enabled XMLType table'
              when bitand(op.flags,
                                  1             /* XMLType stored as object */
                                + 2          /* XMLType schema is specified */
                                + 4                /* XMLType stored as lob */
                                + 8          /* XMLType stores extra column */
                                + 32        /* XMLType table is out-of-line */
                                + 64            /* XMLType stored as binary */
                                + 128           /* XMLType binary ANYSCHEMA */
                                + 256) != 0 /* XMLType binary NO non-schema */
                   then 'XMLType column'
              else 'streams unsupported object'
         end)
     else 'unsupported opaque type column' end) sync_capture_reason,
    (case                                                  /* apply_version */
      when exists (select 1 from sys.partobj$ p
                   where p.obj# = o.obj# and
                         p.parttype = 3)                /* system partition */
        then NULL
      when op.type = 1 then                                     /* XML Type */
        (case when bitand(op.flags,
                            1                   /* XMLType stored as object */
                          + 8                /* XMLType stores extra column */
                          + 64                  /* XMLType stored as binary */
                          + 128                 /* XMLType binary ANYSCHEMA */
                          + 256) != 0       /* XMLType binary NO non-schema */
              then NULL
              when bitand(op.flags,
                            2                /* XMLType schema is specified */
                          + 4                      /* XMLType stored as lob */
                          + 32 ) != 0       /* XMLType table is out-of-line */
                then 11.1
              else NULL end)
      else NULL end) apply_version,
    (case                                                   /* apply_reason */
      when exists (select 1 from sys.partobj$ p
                   where p.obj# = o.obj# and
                         p.parttype = 3)                /* system partition */
        then 'table with system partition'
      when op.type = 1 then                                     /* XML Type */
        (case when bitand(op.flags,
                                  1             /* XMLType stored as object */
                                + 8          /* XMLType stores extra column */
                                + 64            /* XMLType stored as binary */
                                + 128           /* XMLType binary ANYSCHEMA */
                                + 256) != 0 /* XMLType binary NO non-schema */
                   then 'unsupported XMLType column'
              when bitand(op.flags,
                                + 2          /* XMLType schema is specified */
                                + 4                /* XMLType stored as lob */
                                + 32)       /* XMLType table is out-of-line */
                    != 0 then 'XMLType column'
        else 'unsupported XMLType column' end)
      else 'unsupported opaque type column' end) apply_reason
    from sys.user$ u, sys.opqtype$ op, sys.obj$ o, sys.tab$ t, sys.col$ c
    where c.intcol# = op.intcol# and
          c.obj# = op.obj# and
          u.user# = o.owner# and
          o.obj# = t.obj# and
          t.obj# = c.obj# and
          c.type# = 58 and                                  /* opaque types */
          bitand(c.property, 32) = 0 and                      /* not hidden */
                  /* should be consistent with knlcfIsFilteredSpecialSchema */
          u.name not in ('SYS', 'SYSTEM', 'CTXSYS', 'DBSNMP', 'LBACSYS',
                         'MDDATA', 'MDSYS', 'DMSYS', 'OLAPSYS', 'ORDPLUGINS',
                         'ORDSYS', 'SI_INFORMTN_SCHEMA', 'SYSMAN', 'OUTLN',
                         'EXFSYS', 'WMSYS', 'XDB', 'DVSYS', 'ORDDATA') and
          bitand(o.flags,
                  2                                     /* temporary object */
                + 4                              /* system generated object */
                + 32                                /* in-memory temp table */
                + 128                         /* dropped table (RecycleBin) */
                  ) = 0
/

comment on table DBA_STREAMS_COLUMNS is 'Supportability info about streams columns'
/

comment on column DBA_STREAMS_COLUMNS.OWNER is 'Owner of the object'
/

comment on column DBA_STREAMS_COLUMNS.TABLE_NAME is 'Name of the object'
/

comment on column DBA_STREAMS_COLUMNS.COLUMN_NAME is 'Name of the column'
/

comment on column DBA_STREAMS_COLUMNS.SYNC_CAPTURE_VERSION is 'Version of sync capture which supports this column'
/

comment on column DBA_STREAMS_COLUMNS.SYNC_CAPTURE_REASON is 'Reason why this column is not supported by sync capture'
/

comment on column DBA_STREAMS_COLUMNS.APPLY_VERSION is 'Version of apply which supports this column'
/

comment on column DBA_STREAMS_COLUMNS.APPLY_REASON is 'Reason why this column is not supported by apply'
/


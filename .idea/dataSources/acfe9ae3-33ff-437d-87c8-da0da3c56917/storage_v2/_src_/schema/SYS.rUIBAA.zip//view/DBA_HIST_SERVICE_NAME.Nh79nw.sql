create view DBA_HIST_SERVICE_NAME (DBID, SERVICE_NAME_HASH, SERVICE_NAME) as
select dbid, service_name_hash, service_name
  from WRH$_SERVICE_NAME sn
/

comment on table DBA_HIST_SERVICE_NAME is 'Service Names'
/


create view SM$AUDIT_CONFIG (AUDIT_TYPE, SCHEMA_USER, AUDIT_TARGET) as
select 'Object', owner, object_type || ' ' || object_name
    from sys.dba_obj_audit_opts
    where ALT != '-/-' OR AUD != '-/-' OR COM != '-/-' OR DEL != '-/-'
       OR GRA != '-/-' OR IND != '-/-' OR INS != '-/-' OR LOC != '-/-'
       OR REN != '-/-' OR SEL != '-/-' OR UPD != '-/-' OR FBK != '-/-'
       OR EXE != '-/-'
    union all select 'Privilege', user_name, privilege
    from sys.dba_priv_audit_opts
    union all select 'Statement', user_name, audit_option
    from sys.dba_stmt_audit_opts
/


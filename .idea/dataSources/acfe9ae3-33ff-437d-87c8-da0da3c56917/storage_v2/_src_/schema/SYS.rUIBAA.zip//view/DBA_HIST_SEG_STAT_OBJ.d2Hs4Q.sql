create view DBA_HIST_SEG_STAT_OBJ
            (DBID, TS#, OBJ#, DATAOBJ#, OWNER, OBJECT_NAME, SUBOBJECT_NAME, OBJECT_TYPE, TABLESPACE_NAME,
             PARTITION_TYPE) as
select dbid, ts#, obj#, dataobj#, owner, object_name,
       subobject_name, object_type,
       coalesce(tsname, tablespace_name) tablespace_name,
       partition_type
from WRH$_SEG_STAT_OBJ so LEFT OUTER JOIN WRH$_TABLESPACE ts USING (dbid, ts#)
/

comment on table DBA_HIST_SEG_STAT_OBJ is 'Segment Names'
/


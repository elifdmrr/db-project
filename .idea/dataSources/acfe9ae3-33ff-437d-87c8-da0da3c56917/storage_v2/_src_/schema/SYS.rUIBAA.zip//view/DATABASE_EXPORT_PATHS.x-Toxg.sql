create view DATABASE_EXPORT_PATHS (OBJECT_PATH) as
select OBJECT_PATH
    from dba_export_paths
    where het_type='DATABASE_EXPORT'
/


create view EXU8VNC
            (VOBJID, VNAME, VTEXT, VOWNER, VOWNERID, VAUDIT, VCOMMENT, VCNAME, PROPERTY, DEFER, FLAGS, OIDLEN,
             OIDCLAUSE, TYPEOWNER, TYPENAME, VLEN)
as
SELECT  "VOBJID","VNAME","VTEXT","VOWNER","VOWNERID","VAUDIT","VCOMMENT","VCNAME","PROPERTY","DEFER","FLAGS","OIDLEN","OIDCLAUSE","TYPEOWNER","TYPENAME","VLEN"
        FROM    sys.exu8vinf vf$
        WHERE   NOT EXISTS (
                    SELECT  0
                    FROM    sys.exu8vdpt vd$
                    WHERE   vd$.parent = vf$.vobjid)
/


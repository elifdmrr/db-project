create view KU$_10_1_PROXY_VIEW (USER_ID, CLIENT_NAME, PROXY_NAME, FLAGS, CRED_TYPE, PROXY_ROLE_LIST) as
select t.* from ku$_proxy_view t
  where bitand(t.flags,16)=0
/


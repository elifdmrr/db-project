create view GV_$WAITSTAT (INST_ID, CLASS, COUNT, TIME) as
select "INST_ID","CLASS","COUNT","TIME" from gv$waitstat
/


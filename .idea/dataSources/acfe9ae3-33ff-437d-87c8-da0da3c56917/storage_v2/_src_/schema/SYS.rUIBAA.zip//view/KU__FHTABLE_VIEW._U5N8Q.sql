create view KU$_FHTABLE_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, BASE_OBJ, ANC_OBJ, PARENT_OBJ, STORAGE, DEFERRED_STG, TS_NAME,
             BLOCKSIZE, DATAOBJ_NUM, BOBJ_NUM, TAB_NUM, COLS, CLUCOLS, TABCLUSTER, FBA, PCT_FREE, PCT_USED, INITRANS,
             MAXTRANS, FLAGS, AUDIT_VAL, ROWCNT, BLKCNT, EMPCNT, AVGSPC, CHNCNT, AVGRLN, AVGSPC_FLB, FLBCNT,
             ANALYZETIME, SAMPLESIZE, DEGREE, INSTANCES, INTCOLS, KERNELCOLS, PROPERTY, PROPERTY2, XMLSCHEMACOLS,
             TSTZ_COLS, XMLCOLSET, TRIGFLAG, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6, ENCALG, INTALG, COL_LIST,
             NT, CON0_LIST, CON1_LIST, CON2_LIST, PKREF_LIST, EXTTAB, CUBETAB, REFPAR_LEVEL)
as
select '2','5',
         t.obj#,
         value(o),
         -- if this is a secondary table, get base obj and ancestor obj
         decode(bitand(o.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, secobj$ s
              where o.obj_num=s.secobj#
                and oo.obj_num=s.obj#
                and rownum < 2),
           null),
         decode(bitand(o.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, ind$ i, secobj$ s
              where o.obj_num=s.secobj#
                and i.obj#=s.obj#
                and oo.obj_num=i.bo#
                and rownum < 2),
           null),
         null,
         (select value(s) from ku$_storage_view s
          where t.file# = s.file_num
          and t.block#  = s.block_num
          and t.ts#     = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = t.obj#),
         ts.name, ts.blocksize,
         t.dataobj#, t.bobj#, t.tab#, t.cols,
         t.clucols,
         (select value(cl) from ku$_tabcluster_view cl
          where cl.obj_num = t.obj#),
         (select value(fb) from ku$_fba_view fb where fb.obj_num = t.obj#),
         t.pctfree$, t.pctused$, t.initrans, t.maxtrans, t.flags,
         replace(t.audit$,chr(0),'-'), t.rowcnt, t.blkcnt, t.empcnt,
         t.avgspc, t.chncnt, t.avgrln, t.avgspc_flb, t.flbcnt,
         to_char(t.analyzetime,'YYYY/MM/DD HH24:MI:SS'),
         t.samplesize, t.degree, t.instances, t.intcols, t.kernelcols,
         bitand(t.property, 4294967295),
         trunc(t.property / power(2, 32)),
         decode((select 1 from dual where
                 (exists (select q.obj# from sys.opqtype$ q
                          where q.obj#=t.obj#
                          and q.type=1                        /* xmltype col */
                          and bitand(q.flags,2+64)!=0))),       /* CSX or SB */
                1,'Y','N'),
         (select sys.dbms_metadata_util.has_tstz_cols(t.obj#) from dual),
         case when (exists (select q.obj# from sys.opqtype$ q
                          where q.obj#=t.obj#
                          and q.type=1))                      /* xmltype col */
              then dbms_metadata_util.get_xmlcolset(o.obj_num)
              else NULL end,
         t.trigflag,
         t.spare1, t.spare2, t.spare3, t.spare4, t.spare5,
         to_char(t.spare6,'YYYY/MM/DD HH24:MI:SS'),
         decode(bitand(t.trigflag, 65536), 65536,
           (select e.encalg from sys.enc$ e where e.obj#=t.obj#),
           null),
         decode(bitand(t.trigflag, 65536), 65536,
           (select e.intalg from sys.enc$ e where e.obj#=t.obj#),
           null),
         cast( multiset(select * from ku$_column_view c
                        where c.obj_num = t.obj#
                        order by c.col_num, c.intcol_num
                        ) as ku$_column_list_t
              ),
         (select value(nt) from ku$_nt_parent_view nt
          where nt.obj_num = t.obj#),
         cast( multiset(select * from ku$_constraint0_view con
                        where con.obj_num = t.obj#
                        and con.contype not in (7,11)
                       ) as ku$_constraint0_list_t
             ),
         cast( multiset(select * from ku$_constraint1_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint1_list_t
             ),
         cast( multiset(select * from ku$_constraint2_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint2_list_t
             ),
         cast( multiset(select * from ku$_pkref_constraint_view con
                        where con.obj_num = t.obj#
                       ) as ku$_pkref_constraint_list_t
             ),
         (select value(etv) from ku$_exttab_view etv
                        where etv.obj_num = o.obj_num),
         (select value(otv) from ku$_cube_tab_view otv
                        where otv.obj_num = o.obj_num),
         0
  from ku$_schemaobj_view o, tab$ t, ts$ ts
  where t.obj# = o.obj_num
        AND t.ts# = ts.ts#
        AND bitand(t.property, 32+64+128+256+512) = 0
                                                /* not IOT, partitioned   */
        AND bitand(t.property,1607983103)     -- mask off bits 0x20282000
                NOT in (0,1024,8192) -- don't include those in ku$_htable_view
        AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/


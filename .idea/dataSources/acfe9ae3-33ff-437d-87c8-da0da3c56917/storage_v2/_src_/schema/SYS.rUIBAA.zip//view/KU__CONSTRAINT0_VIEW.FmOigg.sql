create view KU$_CONSTRAINT0_VIEW
            (OWNER_NUM, NAME, CON_NUM, OBJ_NUM, NUMCOLS, CONTYPE, ENABLED, INTCOLS, MTIME, FLAGS) as
select c.owner#, c.name, c.con#, cd.obj#, cd.cols, cd.type#,
          NVL(cd.enabled,0),
          cd.intcols, to_char(cd.mtime,'YYYY/MM/DD HH24:MI:SS'), cd.defer
   from con$ c, cdef$ cd
   where c.con# = cd.con#
     and cd.type# in (5,7,11)  -- view WITH CHECK OPTION (5)
                               -- NOT NULL on built-in datatyped column (7)
                               -- NOT NULL on ADT column (11)
/


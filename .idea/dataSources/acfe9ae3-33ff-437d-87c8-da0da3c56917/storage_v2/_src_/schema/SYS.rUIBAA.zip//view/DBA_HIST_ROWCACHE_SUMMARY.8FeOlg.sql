create view DBA_HIST_ROWCACHE_SUMMARY
            (SNAP_ID, DBID, INSTANCE_NUMBER, PARAMETER, TOTAL_USAGE, USAGE, GETS, GETMISSES, SCANS, SCANMISSES,
             SCANCOMPLETES, MODIFICATIONS, FLUSHES, DLM_REQUESTS, DLM_CONFLICTS, DLM_RELEASES)
as
select rc.snap_id, rc.dbid, rc.instance_number,
       parameter, total_usage,
       usage, gets, getmisses, scans, scanmisses, scancompletes,
       modifications, flushes, dlm_requests, dlm_conflicts,
       dlm_releases
  from WRM$_SNAPSHOT sn, WRH$_ROWCACHE_SUMMARY rc
  where     sn.snap_id         = rc.snap_id
        and sn.dbid            = rc.dbid
        and sn.instance_number = rc.instance_number
        and sn.status          = 0
/

comment on table DBA_HIST_ROWCACHE_SUMMARY is 'Row Cache Historical Statistics Information Summary'
/


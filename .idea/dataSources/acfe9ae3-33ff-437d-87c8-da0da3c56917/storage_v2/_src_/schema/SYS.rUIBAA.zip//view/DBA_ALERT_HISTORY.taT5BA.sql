create view DBA_ALERT_HISTORY
            (SEQUENCE_ID, REASON_ID, OWNER, OBJECT_NAME, SUBOBJECT_NAME, OBJECT_TYPE, REASON, TIME_SUGGESTED,
             CREATION_TIME, SUGGESTED_ACTION, ADVISOR_NAME, METRIC_VALUE, MESSAGE_TYPE, MESSAGE_GROUP, MESSAGE_LEVEL,
             HOSTING_CLIENT_ID, MODULE_ID, PROCESS_ID, HOST_ID, HOST_NW_ADDR, INSTANCE_NAME, INSTANCE_NUMBER, USER_ID,
             EXECUTION_CONTEXT_ID, ERROR_INSTANCE_ID, RESOLUTION)
as
select sequence_id,
            reason_id,
            owner,
            object_name,
            subobject_name,
            typnam_keltosd AS object_type,
            dbms_server_alert.expand_message(userenv('LANGUAGE'),
                                             mid_keltsd,
                                             reason_argument_1,
                                             reason_argument_2,
                                             reason_argument_3,
                                             reason_argument_4,
                                             reason_argument_5) AS reason,
            time_suggested,
            creation_time,
            dbms_server_alert.expand_message(userenv('LANGUAGE'),
                                             amid_keltsd,
                                             action_argument_1,
                                             action_argument_2,
                                             action_argument_3,
                                             action_argument_4,
                                             action_argument_5)
              AS suggested_action,
            advisor_name,
            metric_value,
            decode(message_level, 32, 'Notification', 'Warning')
              AS message_type,
            nam_keltgsd AS message_group,
            message_level,
            hosting_client_id,
            mdid_keltsd AS module_id,
            process_id,
            host_id,
            host_nw_addr,
            instance_name,
            instance_number,
            user_id,
            execution_context_id,
            error_instance_id,
            decode(resolution, 1, 'cleared', 'N/A') AS resolution
  FROM wri$_alert_history, X$KELTSD, X$KELTOSD, X$KELTGSD,
       dba_advisor_definitions
  WHERE reason_id = rid_keltsd
    AND otyp_keltsd = typid_keltosd
    AND grp_keltsd = id_keltgsd
    AND aid_keltsd = advisor_id(+)
/

comment on table DBA_ALERT_HISTORY is 'Description on alert history'
/

comment on column DBA_ALERT_HISTORY.SEQUENCE_ID is 'Alert sequence number'
/

comment on column DBA_ALERT_HISTORY.REASON_ID is 'Alert reason id'
/

comment on column DBA_ALERT_HISTORY.OWNER is 'Owner of the object on which alert is issued'
/

comment on column DBA_ALERT_HISTORY.OBJECT_NAME is 'Name of the object'
/

comment on column DBA_ALERT_HISTORY.SUBOBJECT_NAME is 'Name of the subobject (partition)'
/

comment on column DBA_ALERT_HISTORY.OBJECT_TYPE is 'Type of the object (table, tablespace, etc)'
/

comment on column DBA_ALERT_HISTORY.REASON is 'Reason for the alert'
/

comment on column DBA_ALERT_HISTORY.TIME_SUGGESTED is 'Time when the alert was last updated'
/

comment on column DBA_ALERT_HISTORY.CREATION_TIME is 'Time when the alert was first produced'
/

comment on column DBA_ALERT_HISTORY.SUGGESTED_ACTION is 'Advice of recommended action'
/

comment on column DBA_ALERT_HISTORY.ADVISOR_NAME is 'Name of advisor to be invoked for more information'
/

comment on column DBA_ALERT_HISTORY.METRIC_VALUE is 'Value of the related metrics'
/

comment on column DBA_ALERT_HISTORY.MESSAGE_TYPE is 'Message type - warning or notification'
/

comment on column DBA_ALERT_HISTORY.MESSAGE_GROUP is 'Name of the group that the alert belongs to'
/

comment on column DBA_ALERT_HISTORY.MESSAGE_LEVEL is 'Severity level (1-32)'
/

comment on column DBA_ALERT_HISTORY.HOSTING_CLIENT_ID is 'ID of the client or security group etc. that the alert relates to'
/

comment on column DBA_ALERT_HISTORY.MODULE_ID is 'ID of the module that originated the alert'
/

comment on column DBA_ALERT_HISTORY.PROCESS_ID is 'Process id'
/

comment on column DBA_ALERT_HISTORY.HOST_ID is 'DNS hostname of originating host'
/

comment on column DBA_ALERT_HISTORY.HOST_NW_ADDR is 'IP or other network address of originating host'
/

comment on column DBA_ALERT_HISTORY.INSTANCE_NAME is 'Originating instance name'
/

comment on column DBA_ALERT_HISTORY.INSTANCE_NUMBER is 'Originating instance number'
/

comment on column DBA_ALERT_HISTORY.USER_ID is 'User id'
/

comment on column DBA_ALERT_HISTORY.EXECUTION_CONTEXT_ID is 'ID of the thread of execution'
/

comment on column DBA_ALERT_HISTORY.ERROR_INSTANCE_ID is 'ID of an error instance plus a sequence number'
/

comment on column DBA_ALERT_HISTORY.RESOLUTION is 'Cleared or not'
/


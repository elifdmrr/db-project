create view KU$_TTS_TAB_TABLESPACE_VIEW (OBJ_NUM, PARTOBJ, TS_NAME) as
SELECT "OBJ_NUM","PARTOBJ","TS_NAME" FROM ku$_tts_tabview
  UNION ALL
    SELECT "OBJ_NUM","PARTOBJ","TS_NAME" FROM ku$_tts_tabpartview
  UNION ALL
    SELECT "OBJ_NUM","PARTOBJ","TS_NAME" FROM ku$_tts_tabsubpartview
  UNION ALL
    SELECT "OBJ_NUM","PARTOBJ","TS_NAME" FROM ku$_tts_partlobview
  UNION ALL
    SELECT "OBJ_NUM","PARTOBJ","TS_NAME" FROM ku$_tts_subpartlobview
/


create view ALL_CUBE_MEASURES
            (OWNER, CUBE_NAME, MEASURE_NAME, OVERRIDE_SOLVE_SPEC, MEASURE_TYPE, EXPRESSION, DESCRIPTION, DATA_TYPE,
             DATA_LENGTH, DATA_PRECISION, DATA_SCALE)
as
SELECT
  u.name OWNER,
  o.name CUBE_NAME,
  m.measure_name MEASURE_NAME,
  ss.syntax_clob OVERRIDE_SOLVE_SPEC,
  DECODE(m.measure_type, 1, 'BASE', 2, 'DERIVED') MEASURE_TYPE,
  DECODE(m.measure_type, 2, s.syntax_clob) EXPRESSION,
  d.description_value DESCRIPTION,
  DECODE(m.type#, 1, decode(m.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                  2, decode(m.scale, null,
                            decode(m.precision#, null, 'NUMBER', 'FLOAT'),
                            'NUMBER'),
                  8, 'LONG',
                  9, decode(m.charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                  12, 'DATE',
                  23, 'RAW', 24, 'LONG RAW',
                  69, 'ROWID',
                  96, decode(m.charsetform, 2, 'NCHAR', 'CHAR'),
                  100, 'BINARY_FLOAT',
                  101, 'BINARY_DOUBLE',
                  105, 'MLSLABEL',
                  106, 'MLSLABEL',
                  112, decode(m.charsetform, 2, 'NCLOB', 'CLOB'),
                  113, 'BLOB', 114, 'BFILE', 115, 'CFILE',
                  178, 'TIME(' ||m.scale|| ')',
                  179, 'TIME(' ||m.scale|| ')' || ' WITH TIME ZONE',
                  180, 'TIMESTAMP(' ||m.scale|| ')',
                  181, 'TIMESTAMP(' ||m.scale|| ')' || ' WITH TIME ZONE',
                  231, 'TIMESTAMP(' ||m.scale|| ')' || ' WITH LOCAL TIME ZONE',
                  182, 'INTERVAL YEAR(' ||m.precision#||') TO MONTH',
                  183, 'INTERVAL DAY(' ||m.precision#||') TO SECOND(' ||
                        m.scale || ')',
                  208, 'UROWID',
                  'UNDEFINED') DATA_TYPE,
  m.length DATA_LENGTH,
  m.precision# DATA_PRECISION,
  m.scale DATA_SCALE
FROM
  olap_measures$ m,
  user$ u,
  obj$ o,
  olap_syntax$ ss,
  olap_syntax$ s,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
	n.parameter = 'NLS_LANGUAGE'
	and d.description_type = 'Description'
	and d.owning_object_type = 2 --MEASURE
	and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d,
 (SELECT
    obj#,
    MIN(have_dim_access) have_all_dim_access
  FROM
    (SELECT
      c.obj# obj#,
      (CASE
        WHEN
        (do.owner# in (userenv('SCHEMAID'), 1)   -- public objects
         or do.obj# in
              ( select obj#  -- directly granted privileges
                from sys.objauth$
                where grantee# in ( select kzsrorol from x$kzsro )
              )
         or   -- user has system privileges
                ( exists (select null from v$enabledprivs
                          where priv_number in (-302, -- ALTER ANY PRIMARY DIMENSION
                                                -304, -- DELETE ANY PRIMARY DIMENSION
                                                -305, -- DROP ANY PRIMARY DIMENSION
                                                -306, -- INSERT ANY PRIMARY DIMENSION
                                                -307) -- SELECT ANY PRIMARY DIMENSION
                          )
                )
        )
        THEN 1
        ELSE 0
       END) have_dim_access
    FROM
      olap_cubes$ c,
      olap_dimensionality$ diml,
      olap_cube_dimensions$ dim,
      obj$ do
    WHERE
      do.obj# = dim.obj#
      AND diml.dimensioned_object_type = 1 --CUBE
      AND diml.dimensioned_object_id = c.obj#
      AND diml.dimension_type = 11 --DIMENSION
      AND diml.dimension_id = do.obj#
    )
    GROUP BY obj# ) da
WHERE
  m.cube_obj#=o.obj#
  AND o.obj#=da.obj#(+)
  AND o.owner#=u.user#
  AND m.measure_id=s.owner_id(+)
  AND m.measure_id=ss.owner_id(+)
  AND m.is_hidden=0 --NOT HIDDEN
  AND s.owner_type(+)=2 --MEASURE
  AND s.ref_role(+)=14 --DERIVED_MEAS_EXPRESSION
  AND ss.owner_type(+)=2 --MEASURE
  AND ss.ref_role(+)=16 --CONSISTENT_SOLVE_SPEC
  AND m.measure_id=d.owning_object_id(+)
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ( exists (select null from v$enabledprivs
                        where priv_number in (-309, -- ALTER ANY CUBE
                                              -311, -- DROP ANY CUBE
                                              -312, -- SELECT ANY CUBE
                                              -313) -- UPDATE ANY CUBE
                        )
              )
            )
  AND ((have_all_dim_access = 1) OR (have_all_dim_access is NULL))
/

comment on table ALL_CUBE_MEASURES is 'OLAP Measures in the database accessible to the user'
/

comment on column ALL_CUBE_MEASURES.OWNER is 'Owner of the OLAP Measure'
/

comment on column ALL_CUBE_MEASURES.CUBE_NAME is 'Name of the OLAP Cube which owns the Measure'
/

comment on column ALL_CUBE_MEASURES.MEASURE_NAME is 'Name of Measure in the OLAP Cube'
/

comment on column ALL_CUBE_MEASURES.OVERRIDE_SOLVE_SPEC is 'Override solve specification of the OLAP Measure'
/

comment on column ALL_CUBE_MEASURES.MEASURE_TYPE is 'Type of Measure in the OLAP Cube'
/

comment on column ALL_CUBE_MEASURES.EXPRESSION is 'Expression of the OLAP Measure'
/

comment on column ALL_CUBE_MEASURES.DESCRIPTION is 'Description of the OLAP Measure'
/

comment on column ALL_CUBE_MEASURES.DATA_TYPE is 'Data Type of the OLAP Measure'
/

comment on column ALL_CUBE_MEASURES.DATA_LENGTH is 'Data Length of the OLAP Measure'
/

comment on column ALL_CUBE_MEASURES.DATA_PRECISION is 'Data Precision of the OLAP Measure'
/

comment on column ALL_CUBE_MEASURES.DATA_SCALE is 'Data Scale of the OLAP Measure'
/


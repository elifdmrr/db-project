create view ROLE_SYS_PRIVS (ROLE, PRIVILEGE, ADMIN_OPTION) as
select u.name,spm.name,decode(min(option$),1,'YES','NO')
from  sys.user$ u, sys.system_privilege_map spm, sys.sysauth$ sa
where grantee# in
   (select distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
  and u.user#=sa.grantee# and sa.privilege#=spm.privilege
group by u.name, spm.name
/

comment on table ROLE_SYS_PRIVS is 'System privileges granted to roles'
/

comment on column ROLE_SYS_PRIVS.ROLE is 'Role name'
/

comment on column ROLE_SYS_PRIVS.PRIVILEGE is 'System Privilege'
/

comment on column ROLE_SYS_PRIVS.ADMIN_OPTION is 'Grant was with the ADMIN option'
/


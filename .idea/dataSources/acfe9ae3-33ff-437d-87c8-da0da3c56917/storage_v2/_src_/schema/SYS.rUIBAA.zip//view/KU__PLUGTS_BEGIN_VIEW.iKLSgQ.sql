create view KU$_PLUGTS_BEGIN_VIEW
            (VERS_MAJOR, VERS_MINOR, USER_NAME, OBJ_NUM, BASE_OBJ, PACKAGE, PKG_SCHEMA, LEVEL_NUM, CLASS, PREPOST,
             TS_NAME, INCL_CONST, INCL_TRIG, INCL_GRANT, TTS_FULL_CHK, TTS_CLOSURE_CHK)
as
select '1','0',
  null, null, null,
  'DBMS_PLUGTS','SYS',
  0,
  100,
  0,
  null, null, null, null, null, null
  FROM dual
  where (SYS_CONTEXT('USERENV','CURRENT_USERID')=0
                 OR EXISTS ( SELECT * FROM sys.session_roles
                    WHERE role='SELECT_CATALOG_ROLE' ))
/


create view EXU9TGRI
            (OWNERID, OWNER, BASEOBJECT, DEFINITION, WHENCLAUSE, ACTION, ENABLED, TPROPERTY, NAME, BASENAME, BASETYPE,
             PROPERTY, BTOWNER, BTOWNERID, ACTIONSIZE)
as
SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE"
        FROM    sys.exu81tgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu9tabi)
      UNION ALL
        SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE"
        FROM    sys.exu81tgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu8vinfi)
/


create view DBA_CUBE_ATTR_VISIBILITY
            (OWNER, DIMENSION_NAME, ATTRIBUTE_NAME, HIERARCHY_NAME, LEVEL_NAME, FROM_TYPE, TO_TYPE) as
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  null HIERARCHY_NAME,
  null LEVEL_NAME,
  'DIMENSION' FROM_TYPE,
  'DIMENSION' TO_TYPE
FROM
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 11 -- DIMENSION
  AND av.owning_dim_id = o.obj#
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  null LEVEL_NAME,
  'DIMENSION' FROM_TYPE,
  'HIERARCHY' TO_TYPE
FROM
  olap_hierarchies$ h,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 11 -- DIMENSION
  AND av.owning_dim_id = o.obj#
  AND h.dim_obj# = o.obj#
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  null HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  'DIMENSION' FROM_TYPE,
  'DIM_LEVEL' TO_TYPE
FROM
  olap_dim_levels$ dl,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 11 -- DIMENSION
  AND av.owning_dim_id = o.obj#
  AND dl.dim_obj# = o.obj#
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  'DIMENSION' FROM_TYPE,
  'HIER_LEVEL' TO_TYPE
FROM
  olap_hierarchies$ h,
  olap_hier_levels$ hl,
  olap_dim_levels$ dl,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 11 -- DIMENSION
  AND av.owning_dim_id = o.obj#
  AND h.dim_obj# = o.obj#
  AND hl.hierarchy_id = h.hierarchy_id
  AND dl.level_id = hl.dim_level_id
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  null LEVEL_NAME,
  'HIERARCHY' FROM_TYPE,
  'HIERARCHY' TO_TYPE
FROM
  olap_hierarchies$ h,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 13 -- HIERARCHY
  AND av.owning_dim_id = h.hierarchy_id
  AND h.dim_obj# = o.obj#
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  'HIERARCHY' FROM_TYPE,
  'HIER_LEVEL' TO_TYPE
FROM
  olap_hierarchies$ h,
  olap_hier_levels$ hl,
  olap_dim_levels$ dl,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 13 -- HIERARCHY
  AND av.owning_dim_id = h.hierarchy_id
  AND h.dim_obj# = o.obj#
  AND hl.hierarchy_id = h.hierarchy_id
  AND dl.level_id = hl.dim_level_id
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  'HIER_LEVEL' FROM_TYPE,
  'HIER_LEVEL' TO_TYPE
FROM
  olap_hierarchies$ h,
  olap_hier_levels$ hl,
  olap_dim_levels$ dl,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 14 -- HIER_LEVEL
  AND av.owning_dim_id = hl.hierarchy_level_id
  AND hl.hierarchy_id = h.hierarchy_id
  AND dl.level_id = hl.dim_level_id
  AND h.dim_obj# = o.obj#
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  null HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  'DIM_LEVEL' FROM_TYPE,
  'DIM_LEVEL' TO_TYPE
FROM
  olap_dim_levels$ dl,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 12 -- DIM_LEVEL
  AND av.owning_dim_id = dl.level_id
  AND dl.dim_obj# = o.obj#
  AND o.owner# = u.user#
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  'DIM_LEVEL' FROM_TYPE,
  'HIER_LEVEL' TO_TYPE
FROM
  olap_hierarchies$ h,
  olap_hier_levels$ hl,
  olap_dim_levels$ dl,
  olap_attributes$ a,
  olap_attribute_visibility$ av,
  obj$ o,
  user$ u
WHERE
  av.is_unique_key = 0
  AND av.attribute_id = a.attribute_id
  AND av.owning_dim_type = 12 -- DIM_LEVEL
  AND av.owning_dim_id = dl.level_id
  AND dl.level_id = hl.dim_level_id
  AND hl.hierarchy_id = h.hierarchy_id
  AND h.dim_obj# = o.obj#
  AND o.owner# = u.user#
/

comment on table DBA_CUBE_ATTR_VISIBILITY is 'OLAP Attributes visible for Dimensions, Hierarchies, and Levels'
/

comment on column DBA_CUBE_ATTR_VISIBILITY.OWNER is 'Owner of OLAP Attribute'
/

comment on column DBA_CUBE_ATTR_VISIBILITY.DIMENSION_NAME is 'Name of the OLAP Cube Dimension that owns the OLAP Attribute'
/

comment on column DBA_CUBE_ATTR_VISIBILITY.ATTRIBUTE_NAME is 'Name of the OLAP Attribute'
/

comment on column DBA_CUBE_ATTR_VISIBILITY.HIERARCHY_NAME is 'Name of the OLAP Hierarchy for which the Attribute is visible'
/

comment on column DBA_CUBE_ATTR_VISIBILITY.LEVEL_NAME is 'Name of the OLAP Level for which the Attribute is visible'
/

comment on column DBA_CUBE_ATTR_VISIBILITY.FROM_TYPE is 'Object type on which the visibility has been explicitly set'
/

comment on column DBA_CUBE_ATTR_VISIBILITY.TO_TYPE is 'Object type on which the visibility has been implicitly derived'
/


create view USER_ADVISOR_LOG
            (TASK_ID, TASK_NAME, EXECUTION_START, EXECUTION_END, STATUS, STATUS_MESSAGE, PCT_COMPLETION_TIME,
             PROGRESS_METRIC, METRIC_UNITS, ACTIVITY_COUNTER, RECOMMENDATION_COUNT, ERROR_MESSAGE)
as
select a.id as task_id,
         a.name as task_name,
         nvl(e.exec_start, a.exec_start) as execution_start,
         nvl(e.exec_end, a.exec_end) as execution_end,
         decode(nvl(e.status, a.status),
                1, 'INITIAL',
                2, 'EXECUTING',
                3, 'COMPLETED',
                4, 'INTERRUPTED',
                5, 'CANCELLED',
                6, 'FATAL ERROR') as status,
         dbms_advisor.format_message_group(
           nvl(e.status_msg_id, a.status_msg_id)) as status_message,
         a.pct_completion_time as pct_completion_time,
         a.progress_metric as progress_metric,
         a.metric_units as metric_units,
         a.activity_counter as activity_counter,
         a.rec_count as recommendation_count,
         dbms_advisor.format_message_group(
           nvl(e.error_msg_id, a.error_msg#)) as error_message
  from wri$_adv_tasks a, wri$_adv_executions e
      where a.id = e.task_id(+)
        and a.last_exec_name = e.name(+)
        and a.advisor_id = e.advisor_id(+)
        and a.owner# = userenv('SCHEMAID')
        and bitand(a.property, 6) = 4
/


create view DBA_AUTOTASK_CLIENT_HISTORY
            (CLIENT_NAME, WINDOW_NAME, WINDOW_START_TIME, WINDOW_DURATION, JOBS_CREATED, JOBS_STARTED, JOBS_COMPLETED,
             WINDOW_END_TIME)
as
SELECT X.CNAME_KETCL,
            WLOG.WINDOW_NAME,
            WLOG.WINDOW_START_TIME,
            WLOG.WINDOW_END_TIME - WLOG.WINDOW_START_TIME
                AS WINDOW_DURATION,
            SUM(CASE WHEN OPERATION = 'ENABLE'
                THEN 1 ELSE 0 END) AS JOBS_CREATED,
            SUM(CASE WHEN OPERATION = 'RUN'
                THEN 1 ELSE 0 END) AS JOBS_STARTED,
            SUM(CASE WHEN OPERATION = 'RUN' AND STATUS = 'SUCCEEDED'
                THEN 1 ELSE 0 END) AS JOBS_COMPLETED,
            WLOG.WINDOW_END_TIME
       FROM X$KETCL X,
            DBA_SCHEDULER_JOB_LOG JL,
            DBA_AUTOTASK_WINDOW_HISTORY WLOG
      WHERE (BITAND(X.ATTR_KETCL,2048) = 0
          OR 999999 < (SELECT TO_NUMBER(VALUE)
                         FROM V$SYSTEM_PARAMETER
                        WHERE NAME = '_automatic_maintenance_test'))
        AND X.CID_KETCL > 0
        AND JL.JOB_CLASS IN (X.HJC_KETCL,X.UJC_KETCL,X.MJC_KETCL)
        AND JL.LOG_DATE BETWEEN WLOG.WINDOW_START_TIME
                            AND WLOG.WINDOW_END_TIME
      GROUP BY X.CNAME_KETCL, WLOG.WINDOW_NAME, WLOG.WINDOW_START_TIME,
               WLOG.WINDOW_END_TIME - WLOG.WINDOW_START_TIME,
                WLOG.WINDOW_END_TIME

/

comment on table DBA_AUTOTASK_CLIENT_HISTORY is 'Automated Maintenance Jobs history'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.CLIENT_NAME is 'Name of the Automated Maintenance Client'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.WINDOW_NAME is 'Name of the Maintenance Window'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.WINDOW_START_TIME is 'Start time of the Maintenance Window'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.WINDOW_DURATION is 'Duration of the Maintenance Window'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.JOBS_CREATED is 'Number of Maintenance Jobs created during the window'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.JOBS_STARTED is 'Number of Maintenance Jobs that were run during the window'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.JOBS_COMPLETED is 'Number of Maintenance Jobs that were completed during the window'
/

comment on column DBA_AUTOTASK_CLIENT_HISTORY.WINDOW_END_TIME is 'End time of the Maintenance Window'
/


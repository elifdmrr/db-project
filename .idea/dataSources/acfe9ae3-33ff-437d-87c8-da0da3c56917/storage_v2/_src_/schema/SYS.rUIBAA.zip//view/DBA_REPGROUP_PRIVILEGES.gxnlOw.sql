create view DBA_REPGROUP_PRIVILEGES (USERNAME, GNAME, CREATED, RECEIVER, PROXY_SNAPADMIN, OWNER) as
select u.username, rp.gname, rp.created,
       decode(bitand(rp.privilege, 1), 1, 'Y', 'N'),
       decode(bitand(rp.privilege, 2), 2, 'Y', 'N'),
       rp.gowner
from system.repcat$_repgroup_privs rp, dba_users u
where rp.username = u.username
/

comment on table DBA_REPGROUP_PRIVILEGES is 'Information about users who are registered for object group privileges'
/

comment on column DBA_REPGROUP_PRIVILEGES.USERNAME is 'Name of the user'
/

comment on column DBA_REPGROUP_PRIVILEGES.GNAME is 'Name of the replicated object group'
/

comment on column DBA_REPGROUP_PRIVILEGES.CREATED is 'Registration date'
/

comment on column DBA_REPGROUP_PRIVILEGES.RECEIVER is 'Receiver privileges'
/

comment on column DBA_REPGROUP_PRIVILEGES.PROXY_SNAPADMIN is 'Proxy snapadmin privileges'
/

comment on column DBA_REPGROUP_PRIVILEGES.OWNER is 'Owner of the replicated object group'
/


create view GV_$MYSTAT (INST_ID, SID, STATISTIC#, VALUE) as
select "INST_ID","SID","STATISTIC#","VALUE" from gv$mystat
/


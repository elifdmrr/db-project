create view "_DBA_STREAMS_COMPONENT_EVENT"
            (COMPONENT_NAME, COMPONENT_DB, COMPONENT_TYPE, SUB_COMPONENT_TYPE, STAT_TIME, SESSION_ID, SESSION_SERIAL#,
             EVENT, EVENT_COUNT, TOTAL_COUNT, MODULE_NAME, ACTION_NAME, SPARE1, SPARE2, SPARE3, SPARE4)
as
SELECT C.COMPONENT_NAME,
       global_name AS COMPONENT_DB,
       C.COMPONENT_TYPE,
       C.SUB_COMPONENT_TYPE,
       sysdate AS STAT_TIME,
       C.SESSION_ID,
       C.SESSION_SERIAL#,
       V.EVENT,
       0 AS EVENT_COUNT,
       0 AS TOTAL_COUNT,
       SUBSTRB(V.MODULE_NAME,1,
             (SELECT KSUMODLEN FROM X$MODACT_LENGTH)) MODULE_NAME,
       SUBSTRB(V.ACTION_NAME,1,
             (SELECT KSUACTLEN FROM X$MODACT_LENGTH)) ACTION_NAME,
       0, 0, STATE, to_date(NULL, '')
FROM global_name,
 ( -- CAPTURE
   SELECT capture_name AS COMPONENT_NAME,
          1            AS COMPONENT_TYPE,
          14           AS sub_component_type,
          sid          AS SESSION_ID,
          serial#      AS SESSION_SERIAL#,
          state        AS STATE
   FROM gv$streams_capture
   UNION
   SELECT capture_name AS COMPONENT_NAME,
          1            AS COMPONENT_TYPE,
          decode(l.role,
            'reader',  11,
            'preparer',12,
            'builder', 13,
            14)        AS sub_component_type,
          l.sid        AS SESSION_ID,
          l.serial#    AS SESSION_SERIAL#,
          NULL         AS STATE
   FROM gv$streams_capture c, gv$logmnr_process l
   WHERE c.logminer_id = l.session_id
     -- Don't want row for capture process since state is NULL
     AND l.role in ('reader', 'preparer', 'builder')
   UNION
   -- APPLY SERVER, non-XStreamOut case
   SELECT apply_name   AS COMPONENT_NAME,
          4            AS COMPONENT_TYPE,
          44           AS SUB_COMPONENT_TYPE,
          sid          AS SESSION_ID,
          serial#      AS SESSION_SERIAL#,
          state        AS STATE
   FROM gv$streams_apply_server
   WHERE apply_name NOT IN
         (SELECT apply_name FROM dba_apply WHERE UPPER(purpose)= 'XSTREAM OUT')
   UNION
   -- APPLY SERVER, XStreamOut case
   -- In case of XStreamOut, only includes the XStream Outbound Server
   SELECT sas.apply_name   AS COMPONENT_NAME,
          4                AS COMPONENT_TYPE,
          44               AS SUB_COMPONENT_TYPE,
          sas.sid          AS SESSION_ID,
          sas.serial#      AS SESSION_SERIAL#,
          sas.state        AS STATE
   FROM gv$streams_apply_server sas, dba_apply da
   WHERE sas.server_id = 2 AND
         sas.apply_name = da.apply_name AND
         UPPER(da.purpose) = 'XSTREAM OUT'
   UNION
   -- APPLY COORDINATOR
   SELECT apply_name   AS COMPONENT_NAME,
          4            AS COMPONENT_TYPE,
          43           AS SUB_COMPONENT_TYPE,
          sid          AS SESSION_ID,
          serial#      AS SESSION_SERIAL#,
          state        AS STATE
   FROM gv$streams_apply_coordinator
   UNION
   -- APPLY READER
   SELECT apply_name   AS COMPONENT_NAME,
          4            AS COMPONENT_TYPE,
          42           AS SUB_COMPONENT_TYPE,
          sid          AS SESSION_ID,
          serial#      AS SESSION_SERIAL#,
          state        AS STATE
   FROM gv$streams_apply_reader
   UNION
   -- PROPAGATION SENDER+RECEIVER
   -- In case of XStreamIn, we will populate the XStream inbound server as
   -- PROPAGATION RECEIVER, so do not show it as PROPAGATION SENDER+RECEIVER
   SELECT apply_name   AS COMPONENT_NAME,
          4            AS COMPONENT_TYPE,
          41           AS SUB_COMPONENT_TYPE,
          proxy_sid    AS SESSION_ID,
          proxy_serial AS SESSION_SERIAL#,
          state        AS STATE
   FROM gv$streams_apply_reader
   WHERE proxy_sid > 0 AND
         ((proxy_sid, proxy_serial) NOT IN
          (SELECT sid, serial# FROM gv$streams_capture)) AND
         (apply_name NOT IN
          (SELECT apply_name FROM dba_apply WHERE UPPER(purpose)='XSTREAM IN'))
   UNION
   -- PROPAGATION SENDER
   SELECT ('"'||queue_schema||'"."'||queue_name||'"=>'||
           CASE WHEN dblink IS NOT NULL AND
                     (dst_queue_schema IS NULL OR dst_queue_name IS NULL)
                THEN dblink
                ELSE ('"'||dst_queue_schema||'"."'||dst_queue_name||
                      '"@'||dst_database_name)
           END)        AS COMPONENT_NAME,
          2            AS COMPONENT_TYPE,
          NULL         AS SUB_COMPONENT_TYPE,
          session_id   AS SESSION_ID,
          serial#      AS SESSION_SERIAL#,
          state        AS STATE
   FROM gv$propagation_sender
   UNION
   -- PROPAGATION RECEIVER, exclude the case for XStreamIn where src_queue_schema
   -- and src_queue_name are NULL. Also exclude local anr for backward
   -- compatibility. A propagation receiver is considered local anr if source
   -- and destination queues are the same and the source db is the same as
   -- the local db.
   SELECT ('"'||src_queue_schema||'"."'||src_queue_name||
           '"@'||src_dbname||'=>"'||
           dst_queue_schema||'"."'||dst_queue_name||'"')
                       AS COMPONENT_NAME,
          3            AS COMPONENT_TYPE,
          NULL         AS SUB_COMPONENT_TYPE,
          session_id   AS SESSION_ID,
          serial#      AS SESSION_SERIAL#,
          state        AS STATE
   FROM gv$propagation_receiver P
   WHERE src_queue_schema IS NOT NULL AND
         src_queue_name IS NOT NULL AND
         NOT ((P.SRC_QUEUE_SCHEMA = P.DST_QUEUE_SCHEMA) and
              (P.SRC_QUEUE_NAME = P.DST_QUEUE_NAME) and
              (P.SRC_DBNAME = (SELECT GLOBAL_NAME FROM GLOBAL_NAME)))
   UNION
   -- PROPAGATION RECEIVER in case of XStreamIn, we will populate the
   -- XStream inbound server as PROPAGATION RECEIVER
   -- Note: in gv$propagation receiver, there is no source queue name and
   -- queue owner, the src_dbname is populated with the XStreamIn source
   -- name, thus the src_dbname in gv$propagation receiver should be the same
   -- as the cap_src_database in xstream$_server table.
   SELECT ('"'||pr.src_dbname||'"=>"'||
           pr.dst_queue_schema||'"."'||pr.dst_queue_name||'"')
                       AS COMPONENT_NAME,
          3            AS COMPONENT_TYPE,
          NULL         AS SUB_COMPONENT_TYPE,
          pr.session_id   AS SESSION_ID,
          pr.serial#      AS SESSION_SERIAL#,
          pr.state        AS STATE
   FROM gv$propagation_receiver pr, xstream$_server xs
   WHERE  pr.src_dbname = xs.cap_src_database AND
          NOT ((pr.SRC_QUEUE_SCHEMA = pr.DST_QUEUE_SCHEMA) and
               (pr.SRC_QUEUE_NAME = pr.DST_QUEUE_NAME) and
               (pr.SRC_DBNAME = (SELECT GLOBAL_NAME FROM GLOBAL_NAME)))
   ) C,
   -- Need to get proper size for EVENT, MODULE_NAME, ACTION_NAME
 ( SELECT NULL               AS COMPONENT_NAME,
          LPAD(' ', 64, ' ') AS EVENT,
          LPAD(' ', 64, ' ') AS MODULE_NAME,
          LPAD(' ', 64, ' ') AS ACTION_NAME
   FROM DUAL) V
WHERE C.SESSION_ID IS NOT NULL AND
      C.SESSION_SERIAL# IS NOT NULL AND
      C.COMPONENT_NAME = V.COMPONENT_NAME (+)
/

comment on table "_DBA_STREAMS_COMPONENT_EVENT" is 'DBA Streams Component Event'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".COMPONENT_NAME is 'Name of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".COMPONENT_DB is 'Database on which the streams component resides'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".COMPONENT_TYPE is 'Type of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".STAT_TIME is 'Time that statistics were taken'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".SESSION_ID is 'Session ID of the component'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".SESSION_SERIAL# is 'Session serial number of the component'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".EVENT is 'Description of the event of the component'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".EVENT_COUNT is 'The number of times that this event has appeared so far'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".TOTAL_COUNT is 'The total number of events'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".MODULE_NAME is 'Name of the module where the event occurs'
/

comment on column "_DBA_STREAMS_COMPONENT_EVENT".ACTION_NAME is 'Name of the action where the event occurs'
/


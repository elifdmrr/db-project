create view DBA_LOGSTDBY_SKIP_TRANSACTION (XIDUSN, XIDSLT, XIDSQN) as
select xidusn, xidslt, xidsqn
  from system.logstdby$skip_transaction
/

comment on table DBA_LOGSTDBY_SKIP_TRANSACTION is 'List the transactions to be skipped'
/

comment on column DBA_LOGSTDBY_SKIP_TRANSACTION.XIDUSN is 'Transaction id, component 1 of 3'
/

comment on column DBA_LOGSTDBY_SKIP_TRANSACTION.XIDSLT is 'Transaction id, component 2 of 3'
/

comment on column DBA_LOGSTDBY_SKIP_TRANSACTION.XIDSQN is 'Transaction id, component 3 of 3'
/


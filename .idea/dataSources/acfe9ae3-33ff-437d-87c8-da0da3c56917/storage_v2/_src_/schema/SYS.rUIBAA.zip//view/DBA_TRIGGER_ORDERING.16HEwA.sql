create view DBA_TRIGGER_ORDERING
            (TRIGGER_OWNER, TRIGGER_NAME, REFERENCED_TRIGGER_OWNER, REFERENCED_TRIGGER_NAME, ORDERING_TYPE) as
select trigger_owner, trigger_name, referenced_trigger_owner,
  referenced_trigger_name, ordering_type
from sys."_DBA_TRIGGER_ORDERING"
/

comment on table DBA_TRIGGER_ORDERING is 'All triggers having FOLLOWS or PRECEDES ordering in the database'
/

comment on column DBA_TRIGGER_ORDERING.TRIGGER_OWNER is 'Owner of the trigger'
/

comment on column DBA_TRIGGER_ORDERING.REFERENCED_TRIGGER_OWNER is 'Owner of the referenced trigger'
/

comment on column DBA_TRIGGER_ORDERING.REFERENCED_TRIGGER_NAME is 'Name of the referenced trigger'
/

comment on column DBA_TRIGGER_ORDERING.ORDERING_TYPE is 'Type of the ordering between the trigger and the reference trigger'
/


create view GV_$IO_CALIBRATION_STATUS (INST_ID, STATUS, CALIBRATION_TIME) as
select "INST_ID","STATUS","CALIBRATION_TIME" from gv$io_calibration_status
/


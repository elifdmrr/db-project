create view "_DBA_STREAMS_COMPONENT_LINK"
            (SOURCE_COMPONENT_NAME, SOURCE_COMPONENT_DB, SOURCE_COMPONENT_TYPE, DEST_COMPONENT_NAME, DEST_COMPONENT_DB,
             DEST_COMPONENT_TYPE, SPARE1, SPARE2, SPARE3, SPARE4)
as
SELECT v.SOURCE_COMPONENT_NAME,
       v.SOURCE_COMPONENT_DB,
       v.SOURCE_COMPONENT_TYPE,
       v.DEST_COMPONENT_NAME,
       v.DEST_COMPONENT_DB,
       v.DEST_COMPONENT_TYPE,
       0                        as SPARE1,
       0                        as SPARE2,
       NULL                     as SPARE3,
       to_date(NULL, '')        as SPARE4
FROM (
-- CAPTURE -> QUEUE
   SELECT
     c.capture_name             as SOURCE_COMPONENT_NAME,
     global_name                as SOURCE_COMPONENT_DB,
     1                          as SOURCE_COMPONENT_TYPE,
     ('"'||c.queue_owner||'"."'||c.queue_name||'"')
                                as DEST_COMPONENT_NAME,
     global_name                as DEST_COMPONENT_DB,
     5                          as DEST_COMPONENT_TYPE
   -- OPTIMIZE: Replace dba_capture with sys.streams$_capture_process
   FROM sys.streams$_capture_process c, global_name
   UNION
-- QUEUE -> PROPAGATION SENDER
   SELECT
     ('"'||source_queue_schema||'"."'||source_queue||'"')
                                as SOURCE_COMPONENT_NAME,
     global_name                as SOURCE_COMPONENT_DB,
     5                          as SOURCE_COMPONENT_TYPE,
     ('"'||source_queue_schema||'"."'||source_queue||
      '"=>"'||destination_queue_schema||'"."'||destination_queue||
      '"@'||destination_dblink) as DEST_COMPONENT_NAME,
     global_name                as DEST_COMPONENT_DB,
     2                          as DEST_COMPONENT_TYPE
   FROM sys.streams$_propagation_process, global_name
   UNION
-- PROPAGATION SENDER -> PROPAGATION RECEIVER
   SELECT
     ('"'||source_queue_schema||'"."'||source_queue||
      '"=>"'||destination_queue_schema||'"."'||destination_queue||
      '"@'||destination_dblink) as SOURCE_COMPONENT_NAME,
     global_name                as SOURCE_COMPONENT_DB,
     2                          as SOURCE_COMPONENT_TYPE,
     ('"'||source_queue_schema||'"."'||source_queue||
      '"@'||global_name||'=>"'||destination_queue_schema||'"."'||
      destination_queue||'"')   as DEST_COMPONENT_NAME,
     destination_dblink         as DEST_COMPONENT_DB,
     3                          as DEST_COMPONENT_TYPE
   -- OPTIMIZE: Replace dba_propagation with sys.streams$_propagation_process
   FROM sys.streams$_propagation_process, global_name
   UNION
-- PROPAGATION RECEIVER -> QUEUE
-- NOTE: This link is stored on the source database though it physically
-- resides on the destination database
   SELECT
     ('"'||source_queue_schema||'"."'||source_queue||
      '"@'||global_name||'=>"'||destination_queue_schema||'"."'||
      destination_queue||'"')   as SOURCE_COMPONENT_NAME,
     destination_dblink         as SOURCE_COMPONENT_DB,
     3                          as SOURCE_COMPONENT_TYPE,
     ('"'||destination_queue_schema||'"."'||destination_queue||'"')
                                as DEST_COMPONENT_NAME,
     destination_dblink         as DEST_COMPONENT_DB,
     5                          as DEST_COMPONENT_TYPE
   -- OPTIMIZE: Replace dba_propagation with sys.streams$_propagation_process
   FROM sys.streams$_propagation_process, global_name
   WHERE destination_dblink IS NOT NULL
   UNION
-- PROPAGATION RECEIVER -> QUEUE in case of XStreamIn
-- XStream inbound server is presented as PROPAGATION RECEIVER and we need
-- to add a link from propagation receiver to queue
   SELECT ('"'||xs.cap_src_database||'"=>"'||
            xs.queue_owner||'"."'||xs.queue_name||'"')
                                     as SOURCE_COMPONENT_NAME,
          global_name                as SOURCE_COMPONENT_DB,
          3                          as SOURCE_COMPONENT_TYPE,
          ('"'||xs.queue_owner||'"."'||xs.queue_name||'"')
                                     as DEST_COMPONENT_NAME,
          global_name                as DEST_COMPONENT_DB,
          5                          as DEST_COMPONENT_TYPE
   FROM xstream$_server xs, global_name
   WHERE xs.flags = 2
   UNION
-- QUEUE -> APPLY
   SELECT
     ('"'||a.queue_owner||'"."'||a.queue_name||'"')
                                as SOURCE_COMPONENT_NAME,
     global_name                as SOURCE_COMPONENT_DB,
     5                          as SOURCE_COMPONENT_TYPE,
     a.apply_name               as DEST_COMPONENT_NAME,
     global_name                as DEST_COMPONENT_DB,
     4                          as DEST_COMPONENT_TYPE
   -- OPTIMIZE: Replace dba_apply with sys.streams$_apply_process
   FROM sys.streams$_apply_process a, global_name ) v
/

comment on table "_DBA_STREAMS_COMPONENT_LINK" is 'DBA Streams Component Link'
/

comment on column "_DBA_STREAMS_COMPONENT_LINK".SOURCE_COMPONENT_NAME is 'Name of the source component'
/

comment on column "_DBA_STREAMS_COMPONENT_LINK".SOURCE_COMPONENT_DB is 'Database on which the source component resides'
/

comment on column "_DBA_STREAMS_COMPONENT_LINK".SOURCE_COMPONENT_TYPE is 'Type of the source component'
/

comment on column "_DBA_STREAMS_COMPONENT_LINK".DEST_COMPONENT_NAME is 'Name of the destination component'
/

comment on column "_DBA_STREAMS_COMPONENT_LINK".DEST_COMPONENT_DB is 'Database on which the destination component resides'
/

comment on column "_DBA_STREAMS_COMPONENT_LINK".DEST_COMPONENT_TYPE is 'Type of the destination component'
/


create view LOGSTDBY_UNSUPPORT_TAB_11_2B
            (OWNER, TABLE_NAME, COLUMN_NAME, SCALE, PRECISION#, CHARSETFORM, TYPE#, ATTRIBUTES, GENSBY) as
select u.name owner, o.name table_name, c.name column_name,
         c.scale, c.precision#, c.charsetform, c.type#,
   (case when bitand(t.flags, 536870912) = 536870912
         then 'Mapping table for physical rowid of IOT'
         when bitand(t.property, 131072) = 131072
         then 'AQ queue table'
         when c.type# = 58
         then 'Unsupported XML'
         when bitand(t.property, 1 ) = 1     /* 0x00000001      typed table */
         then 'Object Table'
         when bitand(c.property, 65544) != 0
         then  'Unsupported Virtual Column'
         else null end) attributes,
    (case
    /* The following are tables that are system maintained */
    when bitand(o.flags,
                2                                       /* temporary object */
              + 16                                      /* secondary object */
              + 32                                  /* in-memory temp table */
              + 128                           /* dropped table (RecycleBin) */
             ) != 0
    or bitand(t.flags,
                262144     /* 0x00040000        Summary Container Table, MV */
              + 134217728  /* 0x08000000          in-memory temporary table */
              + 536870912  /* 0x20000000  Mapping Tab for Phys rowid of IOT */
             ) != 0
    or bitand(t.property,
                512        /* 0x00000200               iot OVeRflow segment */
              + 8192       /* 0x00002000                       nested table */
              + 4194304    /* 0x00400000             global temporary table */
              + 8388608    /* 0x00800000   session-specific temporary table */
              + 33554432   /* 0x02000000        Read Only Materialized View */
              + 67108864   /* 0x04000000            Materialized View table */
              + 134217728  /* 0x08000000                    Is a Sub object */
              + 2147483648 /* 0x80000000                     eXternal TaBle */
              + 4294967296 /* 0x100000000                              Cube */
              + 8589934592 /* 0x200000000                      FBA Internal */
             ) != 0
    or bitand(t.trigflag,
                536870912  /* 0x20000000                  DDLs autofiltered */
               ) != 0
    or exists                                                /* MVLOG table */
       (select 1
        from sys.mlog$ ml where ml.mowner = u.name and ml.log = o.name)
    or exists (select 1 from sys.secobj$ so           /* ODCI storage table */
               where o.obj# = so.secobj#)
    or exists (select 1 from sys.opqtype$ opq       /* XML OR storage table */
               where o.obj# = opq.obj#
                 and bitand(opq.flags, 32) = 32)
  then -1
    /* The following tables are data tables in internal schemata *
     * that are not secondary objects                            */
  when (exists (select 1 from system.logstdby$skip_support s
                where s.name = u.name and action = 0))
  then -2
    /* The following tables are user visible tables that we choose to       *
     * skip because of some unsupported attribute of the table or column    */
  when (bitand(t.property, 1) = 1       /* 0x00000001            typed table */
        AND((bitand(t.property, 4096) = 4096) /* PK OID */
            or not exists            /* Only XML Typed Tables Are Supported */
            (select 1
             from  sys.col$ cc, sys.opqtype$ opq
             where cc.name = 'SYS_NC_ROWINFO$' and cc.type# = 58 and
                   opq.obj# = cc.obj# and opq.intcol# = cc.intcol# and
                   opq.type = 1 and cc.obj# = t.obj#
                   and (bitand(opq.flags,1) = 1 or      /* stored as object */
                        bitand(opq.flags,4) = 4)           /* stored as lob */
                   and bitand(opq.flags,64) = 0     /* not stored as binary */
                   and bitand(opq.flags,512) = 0 )))   /* not hierarch enab */
  or bitand(t.property,
                131072     /* 0x00020000 table is used as an AQ queue table */
             ) != 0
  or (bitand(t.property, 32) = 32)
    and exists (select 1 from partobj$ po
                where po.obj#=o.obj#
                and  (po.parttype in (3,             /* System partitioned */
                                      5)))        /* Reference partitioned */
  or (c.type# not in (
                  1,                             /* VARCHAR2 */
                  2,                               /* NUMBER */
                  8,                                 /* LONG */
                  12,                                /* DATE */
                  24,                            /* LONG RAW */
                  96,                                /* CHAR */
                  100,                       /* BINARY FLOAT */
                  101,                      /* BINARY DOUBLE */
                  112,                     /* CLOB and NCLOB */
                  113,                               /* BLOB */
                  180,                     /* TIMESTAMP (..) */
                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                  182,         /* INTERVAL YEAR(..) TO MONTH */
                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
  and (c.type# != 23                      /* RAW not RAW OID */
  or  (c.type# = 23 and bitand(c.property, 2) = 2))
  and (c.type# != 58                               /* OPAQUE */
  or  (c.type# = 58                       /* XMLTYPE as CLOB */
      and (not exists (select 1 from opqtype$ opq
                  where opq.type=1
                  and (bitand(opq.flags,1) = 1 or      /* stored as object */
                       bitand(opq.flags,4) = 4)           /* stored as lob */
                  and bitand(opq.flags,64) = 0      /* not stored as binary */
                  and bitand(opq.flags,512) = 0        /* not hierarch enab */
                  and opq.obj#=c.obj#
                  and opq.intcol#=c.intcol#)
           or exists (select 1  /* check unique indexes */
                     from ind$ ui, icol$ uic, col$ c
                    where uic.bo# = t.obj#
                      and uic.intcol# = c.intcol#
                      and ui.bo# = t.obj#
                      and ui.obj# = uic.obj#
                      and c.obj# = t.obj#
                      and bitand(c.property, 32) = 32  /* hidden */
                      and bitand(c.property, 2) = 0    /* not oid */
                      and bitand(c.property, 1024) = 0 /* not nested table */
                      and bitand(ui.property, 1) = 1)
           or exists (select 1 /* check unique constraints */
                    from cdef$ ucd, ccol$ ucc, col$ c
                    where ucd.obj# = t.obj#
                      and ucc.obj# = t.obj#
                      and ucd.con# = ucc.con#
                      and ucc.intcol# = c.intcol#
                      and c.obj# = t.obj#
                      and bitand(c.property, 32) = 32  /* hidden */
                      and bitand(c.property, 2) = 0    /* not oid */
                      and bitand(c.property, 1024) = 0   /* not nested table */
                      and ucd.type# in (2,3))))))
  ----------------------------------------------------------
  /* longs must have a scalar column to use as the id key */
  or (c.type# in (8,24,58,112,113)
      and bitand(t.property, 1) = 0       /* not a typed table or */
      and 0 = (select count(*) from sys.col$ c2
               where t.obj# = c2.obj#
               and bitand(c2.property, 32) != 32               /* Not hidden */
               and (c2.type# in ( 1,                             /* VARCHAR2 */
                                  2,                               /* NUMBER */
                                  12,                                /* DATE */
                                  23,                                 /* RAW */
                                  96,                                /* CHAR */
                                  100,                       /* BINARY FLOAT */
                                  101,                      /* BINARY DOUBLE */
                                  180,                     /* TIMESTAMP (..) */
                                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                                  182,         /* INTERVAL YEAR(..) TO MONTH */
                                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
      )))
  ----------------------------------------------------------
  /* we don't support dedup securefile */
  or  (c.type# in (112, 113)
      and exists (select 1 from logstdby_support_11lob lb
                  where lb.obj# = o.obj#
                  and lb.col# = c.col#
                  and dedupsecurefile = 1))
  ----------------------------------------------------------
  /* we don't support virtual column candidate key */
  or (bitand(c.property, 65544) != 0                      /* Virtual Column */
     and bitand(c.property, 32) != 32                         /* Not hidden */
     and exists (select 1 from icol$ ic, ind$ i
                 where ic.bo# = t.obj# and ic.intcol# = c.intcol#
                 and   i.bo# = t.obj# and i.obj# = ic.obj#
                 and   bitand(i.property, 1) = 1))           /* Unique Index */
  ----------------------------------------------------------
  then 0 else 1 end) gensby
  from sys.obj$ o, sys.user$ u, sys.tab$ t, sys.seg$ s, sys.col$ c
  where o.owner# = u.user#
  and o.obj# = t.obj#
  and o.obj# = c.obj#
  and t.file# = s.file# (+)
  and t.ts# = s.ts# (+)
  and t.block# = s.block# (+)
  and t.obj# = o.obj#
  and bitand(c.property, 32) != 32                         /* Not hidden */
/


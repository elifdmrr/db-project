create view DBA_CPU_USAGE_STATISTICS (DBID, VERSION, TIMESTAMP, CPU_COUNT, CPU_CORE_COUNT, CPU_SOCKET_COUNT) as
select cu.dbid, cu.version, timestamp,
        cpu_count, cpu_core_count, cpu_socket_count
 from wri$_dbu_cpu_usage cu, wri$_dbu_cpu_usage_sample cus
 where cu.dbid    = cus.dbid
   and cu.version = cus.version
/

comment on table DBA_CPU_USAGE_STATISTICS is 'Database CPU Usage Statistics'
/

comment on column DBA_CPU_USAGE_STATISTICS.DBID is 'database ID'
/

comment on column DBA_CPU_USAGE_STATISTICS.VERSION is 'the database version'
/

comment on column DBA_CPU_USAGE_STATISTICS.TIMESTAMP is 'time the CPU usage changed'
/

comment on column DBA_CPU_USAGE_STATISTICS.CPU_COUNT is 'CPU count of database'
/

comment on column DBA_CPU_USAGE_STATISTICS.CPU_CORE_COUNT is 'CPU Core count of database'
/

comment on column DBA_CPU_USAGE_STATISTICS.CPU_SOCKET_COUNT is 'CPU Socket count of database'
/


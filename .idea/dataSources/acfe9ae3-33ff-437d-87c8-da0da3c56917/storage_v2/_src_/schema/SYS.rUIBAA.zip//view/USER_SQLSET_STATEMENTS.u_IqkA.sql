create view USER_SQLSET_STATEMENTS
            (SQLSET_NAME, SQLSET_ID, SQL_ID, FORCE_MATCHING_SIGNATURE, SQL_TEXT, PARSING_SCHEMA_NAME, PARSING_SCHEMA_ID,
             PLAN_HASH_VALUE, BIND_DATA, BINDS_CAPTURED, MODULE, ACTION, ELAPSED_TIME, CPU_TIME, BUFFER_GETS,
             DISK_READS, DIRECT_WRITES, ROWS_PROCESSED, FETCHES, EXECUTIONS, END_OF_FETCH_COUNT, OPTIMIZER_COST,
             OPTIMIZER_ENV, PRIORITY, COMMAND_TYPE, FIRST_LOAD_TIME, STAT_PERIOD, ACTIVE_STAT_PERIOD, OTHER,
             PLAN_TIMESTAMP, SQL_SEQ)
as
select f.name as sqlset_name, sqlset_id, s.sql_id, s.force_matching_signature,
       t.sql_text, p.parsing_schema_name, user# as parsing_schema_id,
       p.plan_hash_value, p.bind_data, p.binds_captured,
       substrb(s.module, 1, (select ksumodlen from x$modact_length)) module,
       substrb(s.action, 1, (select ksuactlen from x$modact_length)) action,
       c.elapsed_time, c.cpu_time, c.buffer_gets,
       c.disk_reads, c.direct_writes, c.rows_processed, c.fetches, c.executions,
       c.end_of_fetch_count, c.optimizer_cost, p.optimizer_env, m.priority,
       s.command_type, c.first_load_time, c.stat_period, c.active_stat_period,
       m.other, p.plan_timestamp, s.id as sql_seq
from   WRI$_SQLSET_DEFINITIONS f, WRI$_SQLSET_STATEMENTS s,
       WRI$_SQLSET_MASK m, WRH$_SQLTEXT t,
       WRI$_SQLSET_PLANS p, WRI$_SQLSET_STATISTICS c,
       user$ u
where  s.id = p.stmt_id AND
       p.stmt_id = c.stmt_id AND p.plan_hash_value = c.plan_hash_value AND
       p.stmt_id = m.stmt_id AND p.plan_hash_value = m.plan_hash_value AND
       s.sql_id = t.sql_id AND
       t.dbid = (select max(d.dbid) from V$DATABASE d) AND
       f.id = s.sqlset_id AND owner = SYS_CONTEXT('USERENV', 'CURRENT_USER') AND
       p.parsing_schema_name = u.NAME(+)
/


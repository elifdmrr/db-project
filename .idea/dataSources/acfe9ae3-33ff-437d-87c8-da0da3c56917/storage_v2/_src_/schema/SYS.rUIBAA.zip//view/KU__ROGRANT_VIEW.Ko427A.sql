create view KU$_ROGRANT_VIEW (VERS_MAJOR, VERS_MINOR, GRANTEE_ID, GRANTEE, ROLE, ROLE_ID, ADMIN, SEQUENCE) as
select '1','0',
          u1.user#, u1.name, u2.name, u2.user#, NVL(g.option$, 0), g.sequence#
  from    sys.user$ u1, sys.user$ u2, sys.sysauth$ g
  where   u1.user# = g.grantee# AND
          u2.user# = g.privilege# AND
          g.privilege# > 0
          AND (SYS_CONTEXT('USERENV','CURRENT_USERID') =0
                OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/


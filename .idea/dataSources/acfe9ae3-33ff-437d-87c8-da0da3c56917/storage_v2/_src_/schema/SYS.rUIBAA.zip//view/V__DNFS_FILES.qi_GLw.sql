create view V_$DNFS_FILES (FILENAME, FILESIZE, PNUM, SVR_ID) as
select "FILENAME","FILESIZE","PNUM","SVR_ID" from v$dnfs_files
/


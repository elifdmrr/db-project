create view "_DBA_XSTREAM_CONNECTION"
            (OUTBOUND_SERVER, OUTBOUND_SOURCE_DB, INBOUND_SERVER, INBOUND_SERVER_DBLINK, OUTBOUND_QUEUE_OWNER,
             OUTBOUND_QUEUE_NAME, INBOUND_QUEUE_OWNER, INBOUND_QUEUE_NAME, RULE_SET_OWNER, RULE_SET_NAME,
             NEGATIVE_RULE_SET_OWNER, NEGATIVE_RULE_SET_NAME, FLAGS, STATUS, CREATE_DATE, ERROR_MESSAGE, ERROR_DATE,
             ACKED_SCN)
as
select
  xs.server_name outbound_server, xs.cap_src_database outbound_source_db,
  c.inbound_server, c.inbound_server_dblink,
  c.outbound_queue_owner, c.outbound_queue_name, c.inbound_queue_owner,
  c.inbound_queue_name, c.rule_set_owner, c.rule_set_name,
  c.negative_rule_set_owner, c.negative_rule_set_name, c.flags, c.status,
  c.create_date, c.error_message, c.error_date, c.acked_scn
from sys.xstream$_server_connection c, sys.xstream$_server xs where
  c.outbound_server = xs.server_name
/


create view ALL_XSC_AGGREGATE_PRIVILEGE
            (AGGREGATE_PRIVILEGE_NAME, AGGREGATE_PRIVILEGE_TARGET_NS, TITLE, DESCRIPTION, PRIVILEGE_NAME,
             PRIVILEGE_TARGET_NAMESPACE)
as
select
   substr(extractValue(value(aggregates),
    '/aggregatePrivilege/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 1024),
   substr(extractValue(OBJECT_VALUE,
    '/securityClass/@targetNamespace'),
    1, 4000),
   extractValue(value(titles),
    '/title', 'xmlns="http://xmlns.oracle.com/xs"'),
   extractValue(value(descriptions),
    '/description', 'xmlns="http://xmlns.oracle.com/xs"'),
   REGEXP_REPLACE(substr(extractValue(value(privrefs),
                                      '/privilegeRef/@name',
                                      'xmlns="http://xmlns.oracle.com/xs"'),
                         1, 1024),
                  '(.+):(.+)', '\2'),
   substr(
     SYS_XMLEXNSURI(value(privrefs),
       '/privilegeRef/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 4000)
from XDB.XS$SECURITYCLASS p,
     table(XMLSequence(
       extract(p.OBJECT_VALUE, '/securityClass/aggregatePrivilege'))
     ) aggregates,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/privilegeRef',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) privrefs,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/title',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) titles,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/description',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) descriptions
union all
select
   substr(extractValue(value(aggregates),
    '/aggregatePrivilege/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 1024),
   substr(extractValue(OBJECT_VALUE,
    '/securityClass/@targetNamespace'),
    1, 4000),
   NULL,
   NULL,
   REGEXP_REPLACE(substr(extractValue(value(privrefs),
                                      '/privilegeRef/@name',
                                      'xmlns="http://xmlns.oracle.com/xs"'),
                         1, 1024),
                  '(.+):(.+)', '\2'),
   substr(
     SYS_XMLEXNSURI(value(privrefs),
       '/privilegeRef/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 4000)
from XDB.XS$SECURITYCLASS p,
     table(XMLSequence(
       extract(p.OBJECT_VALUE, '/securityClass/aggregatePrivilege'))
     ) aggregates,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/privilegeRef',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) privrefs
union all
select
   substr(extractValue(value(aggregates),
    '/aggregatePrivilege/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 1024),
   substr(extractValue(OBJECT_VALUE,
    '/securityClass/@targetNamespace'),
    1, 4000),
   NULL,
   extractValue(value(descriptions),
    '/description', 'xmlns="http://xmlns.oracle.com/xs"'),
   REGEXP_REPLACE(substr(extractValue(value(privrefs),
                                      '/privilegeRef/@name',
                                      'xmlns="http://xmlns.oracle.com/xs"'),
                         1, 1024),
                  '(.+):(.+)', '\2'),
   substr(
     SYS_XMLEXNSURI(value(privrefs),
       '/privilegeRef/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 4000)
from XDB.XS$SECURITYCLASS p,
     table(XMLSequence(
       extract(p.OBJECT_VALUE, '/securityClass/aggregatePrivilege'))
     ) aggregates,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/privilegeRef',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) privrefs,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/description',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) descriptions
union all
select
   substr(extractValue(value(aggregates),
    '/aggregatePrivilege/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 1024),
   substr(extractValue(OBJECT_VALUE,
    '/securityClass/@targetNamespace'),
    1, 4000),
   extractValue(value(titles),
    '/title', 'xmlns="http://xmlns.oracle.com/xs"'),
   NULL,
   REGEXP_REPLACE(substr(extractValue(value(privrefs),
                                      '/privilegeRef/@name',
                                      'xmlns="http://xmlns.oracle.com/xs"'),
                         1, 1024),
                  '(.+):(.+)', '\2'),
   substr(
     SYS_XMLEXNSURI(value(privrefs),
       '/privilegeRef/@name', 'xmlns="http://xmlns.oracle.com/xs"'),
    1, 4000)
from XDB.XS$SECURITYCLASS p,
     table(XMLSequence(
       extract(p.OBJECT_VALUE, '/securityClass/aggregatePrivilege'))
     ) aggregates,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/privilegeRef',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) privrefs,
     table(XMLSequence(
       extract(value(aggregates), '/aggregatePrivilege/title',
               'xmlns="http://xmlns.oracle.com/xs"'))
     ) titles
/

comment on table ALL_XSC_AGGREGATE_PRIVILEGE is 'All privileges that make up an aggregate privilege in the database'
/

comment on column ALL_XSC_AGGREGATE_PRIVILEGE.AGGREGATE_PRIVILEGE_NAME is 'The name of the aggregate privilege'
/

comment on column ALL_XSC_AGGREGATE_PRIVILEGE.AGGREGATE_PRIVILEGE_TARGET_NS is 'The target namespace for the aggregate privilege'
/

comment on column ALL_XSC_AGGREGATE_PRIVILEGE.TITLE is 'Title of the aggregate privilege'
/

comment on column ALL_XSC_AGGREGATE_PRIVILEGE.DESCRIPTION is 'Description of the aggregate privilege'
/

comment on column ALL_XSC_AGGREGATE_PRIVILEGE.PRIVILEGE_NAME is 'Name of a privilege defined in the specified aggregate privilege'
/

comment on column ALL_XSC_AGGREGATE_PRIVILEGE.PRIVILEGE_TARGET_NAMESPACE is 'The target namespace for this privilege'
/


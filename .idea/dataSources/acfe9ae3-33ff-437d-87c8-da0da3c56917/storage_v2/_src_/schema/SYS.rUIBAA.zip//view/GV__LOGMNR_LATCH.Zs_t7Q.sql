create view GV_$LOGMNR_LATCH (INST_ID, SESSION_ID, NAME, CHILD_ADDR, STATE) as
select "INST_ID","SESSION_ID","NAME","CHILD_ADDR","STATE" from gv$logmnr_latch
/


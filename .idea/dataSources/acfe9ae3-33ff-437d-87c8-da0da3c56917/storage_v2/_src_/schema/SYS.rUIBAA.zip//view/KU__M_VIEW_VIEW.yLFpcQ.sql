create view KU$_M_VIEW_VIEW
            (VERS_MAJOR, VERS_MINOR, SOWNER, VNAME, TNAME, MOWNER, MASTER, MLINK, SNAPSHOT, SNAPID, AUTO_FAST, AUTO_FUN,
             AUTO_DATE, USLOG, STATUS, MASTER_VERSION, TABLES, FLAG, FLAG2, FLAG3, LOBMASKVEC, MAS_ROLL_SEG, RSCN,
             INSTSITE, FLAVOR_ID, OBJFLAG, SNA_TYPE_OWNER, SNA_TYPE_NAME, MAS_TYPE_OWNER, MAS_TYPE_NAME, PARENT_SOWNER,
             PARENT_VNAME, QUERY_LEN, QUERY_TXT, PARSED_QUERY_TXT, QUERY_VCNT, REL_QUERY, LOC_ROLL_SEG, GLOBAL_DB_NAME,
             SYN_COUNT, SRT_LIST)
as
select '2',
         case when dbms_metadata.get_version >= '11.02.00.00.00' then '3'
              when dbms_metadata.get_version >= '11.00.00.00.00' then '2'
              when dbms_metadata.get_version >= '10.00.00.00.00' then '1'
              else '0'
         end,
         s.sowner,
         s.vname,
         s.tname,
         s.mowner,
         s.master,
         s.mlink,
         TO_CHAR(s.snapshot,'YYYY-MM-DD HH24:MI:SS'),
         s.snapid,
         DECODE(s.auto_fast, 'C', 'COMPLETE', 'F', 'FAST', '?', 'FORCE',
                NULL, 'FORCE', 'N', 'NEVER', 'ERROR'),
         s.auto_fun,
         to_char(s.auto_date,'YYYY/MM/DD HH24:MI:SS'),
         s.uslog,
         s.status,
         s.master_version,
         s.tables,
         s.flag,
         s.flag2,
         case when dbms_metadata.get_version >= '11.02.00.00.00'
           then NVL(s.flag3, 0)
           else 0
         end,
         s.lobmaskvec,
         s.mas_roll_seg,
         s.rscn,
         s.instsite,
         NVL(s.flavor_id, 0),
         s.objflag,
         s.sna_type_owner,
         s.sna_type_name,
         s.mas_type_owner,
         s.mas_type_name,
         s.parent_sowner,
         s.parent_vname,
         s.query_len,
         sys.dbms_metadata_util.long2clob(s.query_len, 'sys.snap$',
                                            'query_txt', s.rowid),
         sys.dbms_metadata.parse_query(s.sowner, s.query_len, 'sys.snap$',
                                       'query_txt', s.rowid),
--         sys.dbms_metadata_util.long2vcnt(s.query_len, 'sys.snap$',
--                                            'query_txt', s.rowid),
         NULL,
         s.rel_query,
         (select rg.rollback_seg
          from   sys.rgroup$ rg
          where  rg.owner = s.sowner
             and rg.name = s.vname),
         p.value$,
         s.syn_count,
         cast(multiset(select srt.tablenum,
                              TO_CHAR(srt.snaptime,'YYYY-MM-DD HH24:MI:SS'),
                              srt.mowner,
                              srt.master,
                              srt.masflag,
                              srt.masobj#,
                              TO_CHAR(srt.loadertime,'YYYY-MM-DD HH24:MI:SS'),
                              srt.refscn,
                              TO_CHAR(srt.lastsuccess,'YYYY-MM-DD HH24:MI:SS'),
                              srt.fcmaskvec,
                              srt.ejmaskvec,
                              srt.sub_handle,
                              srt.change_view,
                              (select count(*)
                               from   sys.snap_colmap$ scm
                               where  srt.vname = scm.vname
                               and    srt.sowner = scm.sowner
                               and    srt.instsite = scm.instsite
                               and    srt.tablenum = scm.tabnum),
                              cast(multiset(select scm.snacol,
                                                   scm.mascol,
                                                   scm.maspos,
                                                   scm.colrole,
                                                   scm.snapos
                                            from   sys.snap_colmap$ scm
                                            where  srt.vname = scm.vname
                                            and    srt.sowner = scm.sowner
                                            and    srt.instsite = scm.instsite
                                            and    srt.tablenum = scm.tabnum
                                            order by scm.maspos)
                                            as ku$_m_view_scm_list_t)
                       from   sys.snap_reftime$ srt
                       where  s.vname    = srt.vname
                          and s.sowner   = srt.sowner
                          and s.instsite = srt.instsite
                       order by srt.tablenum, srt.mowner, srt.master)
                       as ku$_m_view_srt_list_t)
  from   snap$ s, sys.props$ p
  where  p.name  = 'GLOBAL_DB_NAME'
  /* for < 11.2, exclude MVs using scn-based refresh */
  and (dbms_metadata.get_version >= '11.02.00.00.00'
       or
       (dbms_metadata.get_version < '11.02.00.00.00' and bitand(s.flag3, 1)=0))
  order by parent_vname nulls last
-- bug 6750821: list secondary MVs first, so that when ALTER MV COMPILE is done
-- on primary MVs during import, their secondary MVs are already present
/


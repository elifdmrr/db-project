create view "_DBA_STREAMS_COMPONENT"
            (COMPONENT_NAME, COMPONENT_DB, COMPONENT_TYPE, COMPONENT_PROPERTY, COMPONENT_CHANGED_TIME, SPARE1, SPARE2,
             SPARE3, SPARE4)
as
SELECT v.COMPONENT_NAME,
       v.COMPONENT_DB,
       v.COMPONENT_TYPE,
       v.COMPONENT_PROPERTY,
       v.COMPONENT_CHANGED_TIME,
       0, 0, NULL, to_date(NULL, '')
FROM (
   SELECT caq.COMPONENT_NAME,
          global_name                       as COMPONENT_DB,
          caq.COMPONENT_TYPE,
          caq.COMPONENT_PROPERTY,
          o.mtime                           as COMPONENT_CHANGED_TIME
   FROM (
-- Capture
      SELECT c.capture_name                 as COMPONENT_NAME,
             1                              as COMPONENT_TYPE,
             decode(bitand(c.flags, 64), 64,
-- Downstream 0001; Downstream Hotmining 0101; Downstream Coldmining 1001
                    decode(p.value, 'Y', 5, 'N', 9, null, 0, 1),
-- Local 0010; Local Hotmining 0110; Local Coldmining 1010; Unknown 0000
                    decode(p.value, 'Y', 6, 'N',10, null, 0, 2))
                                            as COMPONENT_PROPERTY,
             'SYS'                          as OBJECT_OWNER,
             c.capture_name                 as OBJECT_NAME
      -- OPTIMIZE: Replace dba_capture with sys.streams$_capture_process
      -- and dba_capture_parameters with sys.streams$_process_params to
      -- optimize query performance.
      FROM sys.streams$_capture_process c, sys.streams$_process_params p
      WHERE p.process_type = 2 AND   -- type 2 indicates capture process
            p.process# = c.capture# AND
      -- For local and downstream capture, 'DOWNSTREAM_REAL_TIME_MINE'
      -- is always populated.
            p.name = 'DOWNSTREAM_REAL_TIME_MINE'
      UNION
-- Apply
      SELECT apply_name                     as COMPONENT_NAME,
             4                              as COMPONENT_TYPE,
             0                              as COMPONENT_PROPERTY,
             'SYS'                          as OBJECT_OWNER,
             apply_name                     as OBJECT_NAME
      -- OPTIMIZE: Replace dba_apply with sys.streams$_apply_process
      FROM sys.streams$_apply_process
      UNION
-- Queue
-- Every queue in 'gv$buffered_queues' is buffered. Otherwise, persistent.
      SELECT ('"'||q.queue_schema||'"."'||q.queue_name||'"')
                                            as COMPONENT_NAME,
             5                              as COMPONENT_TYPE,
             16                             as COMPONENT_PROPERTY,
             q.queue_schema                 as OBJECT_OWNER,
             q.queue_name                   as OBJECT_NAME
      FROM   gv$buffered_queues q
      UNION
      SELECT ('"'||t.schema||'"."'||q.name||'"')
                                            as COMPONENT_NAME,
             5                              as COMPONENT_TYPE,
             32                             as COMPONENT_PROPERTY,
             t.schema                       as OBJECT_OWNER,
             q.name                         as OBJECT_NAME
      FROM   system.aq$_queues q,
             system.aq$_queue_tables t
      WHERE  q.table_objno = t.objno AND
-- Use system.aq$_queues.usage to find 'NORMAL_QUEUE' in dba_queues
             q.usage NOT IN (1, 2) AND
             q.eventid NOT IN (SELECT queue_id FROM gv$buffered_queues)
         ) caq, sys.obj$ o, sys.user$ u, global_name
   -- OPTIMIZE: Replace dba_objects with sys.obj$ and sys.user$
   --           and extract global_name
   WHERE caq.object_owner = u.name AND
         caq.object_name = o.name AND
         o.owner# = u.user# AND
-- namespace values for queue, capture and apply are 10, 37 and 39 respectively
         o.namespace in (10, 37, 39)
   UNION
-- Propagation Sender
-- Using sys.streams$_propagation_process instead of gv$propagation_sender,
-- we can have propagation sender even when dst_database_name is missing in
-- gv$propagation_sender. We can have creation_time as component_changed_time.
   SELECT ('"'||source_queue_schema||'"."'||source_queue||
           '"=>"'||destination_queue_schema||'"."'||destination_queue||
           '"@'||destination_dblink)     as COMPONENT_NAME,
          global_name                    as COMPONENT_DB,
          2                              as COMPONENT_TYPE,
          0                              as COMPONENT_PROPERTY,
-- The creation time of propagation is the last ddl time.
          creation_time                  as COMPONENT_CHANGED_TIME
   FROM sys.streams$_propagation_process, global_name
   UNION
-- Propagation Receiver
-- Using sys.streams$_propagation_process, we can always produce
-- propagation receiver, even when gv$propagation_receiver is missing.
-- NOTE: This streams component is stored on the source database though
-- it physically resides on the destination database.
   SELECT ('"'||source_queue_schema||'"."'||source_queue||
           '"@'||global_name||'=>"'||destination_queue_schema||'"."'||
           destination_queue||'"')       as COMPONENT_NAME,
          destination_dblink             as COMPONENT_DB,
          3                              as COMPONENT_TYPE,
          0                              as COMPONENT_PROPERTY,
          to_date(null, '')              as COMPONENT_CHANGED_TIME
   -- OPTIMIZE: Replace dba_propagation with sys.streams$_propagation_process
   FROM sys.streams$_propagation_process, global_name
   WHERE destination_dblink IS NOT NULL
   UNION
-- Propagation Receiver in case of XStreamIn, using xstream$_server.
-- The component name is formatted as:
--     "SOURCE_NAME"=>"QUEUE_SCHEMA"."QUEUE_NAME"
   SELECT ('"'||xs.cap_src_database||'"=>"'||
           xs.queue_owner||'"."'||xs.queue_name||'"')
                                        as COMPONENT_NAME,
          global_name                   as COMPONENT_DB,
          3                             as COMPONENT_TYPE,
          0                             as COMPONENT_PROPERTY,
          xs.create_date                as COMPONENT_CHANGED_TIME
   FROM xstream$_server xs, global_name
   WHERE xs.flags = 2
   ) v
/

comment on table "_DBA_STREAMS_COMPONENT" is 'DBA Streams Component'
/

comment on column "_DBA_STREAMS_COMPONENT".COMPONENT_NAME is 'Name of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT".COMPONENT_DB is 'Database on which the streams component resides'
/

comment on column "_DBA_STREAMS_COMPONENT".COMPONENT_TYPE is 'Type of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT".COMPONENT_PROPERTY is 'Properties of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT".COMPONENT_CHANGED_TIME is 'Time that the streams component was last changed by a DDL'
/


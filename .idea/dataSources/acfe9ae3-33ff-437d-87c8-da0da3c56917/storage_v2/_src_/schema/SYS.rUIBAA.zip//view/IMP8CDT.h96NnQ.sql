create view IMP8CDT (OWNERID, BAD) as
SELECT  co$.owner#, DECODE(BITAND(c$.defer, 16), 16, 1, 0)
        FROM    sys.cdef$ c$, sys.con$ co$
        WHERE   c$.defer IS NOT NULL AND
                BITAND(c$.defer, 16) = 16 AND
                c$.con# = co$.con#
/


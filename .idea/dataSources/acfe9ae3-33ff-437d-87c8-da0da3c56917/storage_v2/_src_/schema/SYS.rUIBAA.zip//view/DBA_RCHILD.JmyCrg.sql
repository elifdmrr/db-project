create view DBA_RCHILD (REFGROUP, OWNER, NAME, TYPE#) as
select REFGROUP, OWNER, NAME, TYPE# from rgchild$ r
   where r.instsite = 0
/

comment on table DBA_RCHILD is 'All the children in any refresh group.  This view is not a join.'
/


create view REPCAT_REPCOLUMN_BASE
            (SNAME, ONAME, TYPE, CNAME, ID, POS, COMPARE_OLD_ON_DELETE, COMPARE_OLD_ON_UPDATE, SEND_OLD_ON_DELETE,
             SEND_OLD_ON_UPDATE, CTYPE, CTYPE_TOID, CTYPE_OWNER, CTYPE_HASHCODE, CTYPE_VERSION#, CTYPE_NUM, CTYPE_MOD,
             DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE, CHARACTER_SET_NAME, TOP, CHAR_LENGTH, CHAR_USED,
             PROPERTY, LPOS)
as
select r.sname,
       r.oname,
       decode(r.type,
         -1, 'SNAPSHOT',
          1, 'INDEX',
          2, 'TABLE',
          4, 'VIEW',
          5, 'SYNONYM'),
       r.lcname, -- cname, long column name
       r.id,
       -- we want to leave the pos as NULL for virtual columns
       r.pos,
       -- we want the send and compare bits from the 'real' column
       decode(nvl(r.pos,r2.pos), NULL, NULL,
         decode(utl_raw.bit_and(utl_raw.substr(nvl(r2.flag,
                r.flag), 1, 1), '04'), '00', 'Y','N')),
       decode(nvl(r.pos,r2.pos), NULL, NULL,
         decode(utl_raw.bit_and(utl_raw.substr(nvl(r2.flag,
                r.flag), 1, 1), '08'), '00', 'Y','N')),
       decode(nvl(r.pos,r2.pos), NULL, NULL,
         decode(utl_raw.bit_and(utl_raw.substr(nvl(r2.flag,
                r.flag), 1, 1), '01'), '00', 'Y','N')),
       decode(nvl(r.pos,r2.pos), NULL, NULL,
         decode(utl_raw.bit_and(utl_raw.substr(nvl(r2.flag,
                r.flag), 1, 1), '02'), '00', 'Y','N')),
       decode(r.ctype,
         1, decode(r.charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
         2, 'NUMBER',
         12, 'DATE',
         23, decode(utl_raw.bit_and(utl_raw.substr(r.property, 1, 1), '08'),
                    '08', r.ctype_name, 'RAW'),
         58, r.ctype_name,
         69, 'ROWID',
         96, decode(r.charsetform, 2, 'NCHAR', 'CHAR'),
         -- system provided type may be stored as clob, e.g., XMLType
         112, NVL(r.ctype_name, decode(r.charsetform, 2, 'NCLOB', 'CLOB')),
         113, 'BLOB',
         178, 'TIME(' ||r.scale|| ')',
         179, 'TIME(' ||r.scale|| ')' || ' WITH TIME ZONE',
         180, 'TIMESTAMP(' ||r.scale|| ')',
         181, 'TIMESTAMP(' ||r.scale|| ')' || ' WITH TIME ZONE',
         182, 'INTERVAL YEAR(' ||r.precision#||') TO MONTH',
         183, 'INTERVAL DAY(' ||r.precision#||') TO SECOND(' ||r.scale|| ')',
         111, r.ctype_name,
         121, r.ctype_name,
         122, r.ctype_name,
         123, r.ctype_name,
         231, 'TIMESTAMP(' ||r.scale|| ')' || ' WITH LOCAL TIME ZONE',
         'UNDEFINED'),
       r.toid,
       r.ctype_owner,
       RAWTOHEX(r.hashcode),
       r.version#,
       r.ctype,
       decode(r.ctype, 111, 'REF'),                       -- CTYPE_MOD
       decode(nvl(r.pos, r2.pos), NULL, NULL, r.length),
       decode(nvl(r.pos, r2.pos), NULL, NULL, r.precision#),
       decode(nvl(r.pos, r2.pos), NULL, NULL, r.scale),
       decode(nvl(r.pos, r2.pos), NULL, NULL, decode(sign(r.null$),-1,'D',
                                                     0, 'Y', 'N')),
       decode(r.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(r.charsetid),
                             4, 'ARG:'||r.charsetid),
       decode(r.ctype, 23,
               -- nested table column SETID (in the parent table)
               decode(utl_raw.bit_and(utl_raw.substr(r.property, 1, 1), '08'),
                      '08',decode(r.top, r.lcname, NULL, r.top), r.top),
               -- for XMLType storage column
               112, decode(r.top, r.lcname, NULL, r.top),
              r.top),
       r.clength,
       decode(r.ctype,
        1,
        decode(utl_raw.bit_and(utl_raw.substr(r.flag,1,1),'10'),'00','B','C'),
        96,
        decode(utl_raw.bit_and(utl_raw.substr(r.flag,1,1),'10'),'00','B','C'),
        ''),
        r.property,
        -- for soidref_fk we need to select the pos of the real column
        -- in the lpos field so that in the definition of dba_repcolumn we
        -- can say nvl(pos, lpos) showing the pos of the real column rather
        -- than null.
        decode(utl_raw.bit_and(utl_raw.substr(r.property,2,1),'01'),'01',
               r2.pos, null)
from system.repcat$_repcolumn r, system.repcat$_repcolumn r2
where r2.sname (+) = r.sname
and   r2.oname (+) = r.oname
and   r2.lcname (+) = r.lcname
and   r2.id (+) <> r.id
-- we select r2 only for soidref_fk_attr
and utl_raw.bit_and(utl_raw.substr(nvl(r2.property (+),'0000'),2,1),'02')='02'
-- filter out nested table column
and utl_raw.bit_and(utl_raw.substr(r.property, 1, 1), '01') != '01'
-- filter out special opaque type referenced in table opqtype$
and utl_raw.bit_and(utl_raw.substr(r.property, 2, 1), '08') != '08'
-- filter out soidref_fk_attr column
and utl_raw.bit_and(utl_raw.substr(r.property, 2, 1), '02') != '02'
/

comment on table REPCAT_REPCOLUMN_BASE is 'Replicated top-level columns (table) sorted alphabetically in ascending order'
/

comment on column REPCAT_REPCOLUMN_BASE.SNAME is 'Name of the object owner'
/

comment on column REPCAT_REPCOLUMN_BASE.ONAME is 'Name of the object'
/

comment on column REPCAT_REPCOLUMN_BASE.TYPE is 'Type of the object'
/

comment on column REPCAT_REPCOLUMN_BASE.CNAME is 'Name of the replicated column'
/

comment on column REPCAT_REPCOLUMN_BASE.ID is 'ID of the replicated column'
/

comment on column REPCAT_REPCOLUMN_BASE.POS is 'Ordering of the replicated column'
/

comment on column REPCAT_REPCOLUMN_BASE.COMPARE_OLD_ON_DELETE is 'Compare the old value of the column in replicated deletes'
/

comment on column REPCAT_REPCOLUMN_BASE.COMPARE_OLD_ON_UPDATE is 'Compare the old value of the column in replicated updates'
/

comment on column REPCAT_REPCOLUMN_BASE.SEND_OLD_ON_DELETE is 'Send the old value of the column in replicated deletes'
/

comment on column REPCAT_REPCOLUMN_BASE.SEND_OLD_ON_UPDATE is 'Send the old value of the column in replicated updates'
/

comment on column REPCAT_REPCOLUMN_BASE.CTYPE is 'Type of the column'
/

comment on column REPCAT_REPCOLUMN_BASE.CTYPE_TOID is 'Type OID of a column of TYPE'
/

comment on column REPCAT_REPCOLUMN_BASE.CTYPE_OWNER is 'Type owner of a column of TYPE'
/

comment on column REPCAT_REPCOLUMN_BASE.CTYPE_HASHCODE is 'Type hashcode of a column of TYPE'
/

comment on column REPCAT_REPCOLUMN_BASE.CTYPE_VERSION# is 'Type version# of a column of TYPE'
/

comment on column REPCAT_REPCOLUMN_BASE.CTYPE_NUM is 'Type of a column'
/

comment on column REPCAT_REPCOLUMN_BASE.CTYPE_MOD is 'Datatype modifier of a column'
/

comment on column REPCAT_REPCOLUMN_BASE.DATA_LENGTH is 'Length of the column in bytes'
/

comment on column REPCAT_REPCOLUMN_BASE.DATA_PRECISION is 'Length: decimal digits (NUMBER) or binary digits (FLOAT)'
/

comment on column REPCAT_REPCOLUMN_BASE.DATA_SCALE is 'Digits to right of decimal point in a number'
/

comment on column REPCAT_REPCOLUMN_BASE.NULLABLE is 'Does column allow NULL values?'
/

comment on column REPCAT_REPCOLUMN_BASE.CHARACTER_SET_NAME is 'Name of character set for column, if applicable'
/

comment on column REPCAT_REPCOLUMN_BASE.TOP is 'Top column name for an attribute'
/

comment on column REPCAT_REPCOLUMN_BASE.LPOS is 'Ordering of the real replicated column'
/


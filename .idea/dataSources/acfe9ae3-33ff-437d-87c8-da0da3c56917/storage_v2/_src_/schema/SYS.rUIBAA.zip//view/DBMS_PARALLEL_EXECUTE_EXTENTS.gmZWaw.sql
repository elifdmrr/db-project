create view DBMS_PARALLEL_EXECUTE_EXTENTS
            (OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, DATA_OBJECT_ID, RELATIVE_FNO, BLOCK_ID, BLOCKS) as
SELECT owner,
       segment_name,
       partition_name,
       segment_type,
       data_object_id,
       relative_fno,
       block_id,
       blocks
from (select ds.owner,
             ds.segment_name,
             ds.partition_name,
             ds.segment_type,
             e.block#           BLOCK_ID,
             e.length           BLOCKS,
             e.file#            RELATIVE_FNO,
             ds.data_object_id
      from sys.uet$ e,
           (select u.name           OWNER,
                   o.name           SEGMENT_NAME,
                   o.subname        PARTITION_NAME,
                   so.object_type   SEGMENT_TYPE,
                   ts.ts#           TABLESPACE_ID,
                   s.block#         HEADER_BLOCK,
                   s.file#          RELATIVE_FNO,
                   NVL(s.spare1,0)  SEGMENT_FLAGS,
                   o.dataobj#       DATA_OBJECT_ID
            from sys.user$ u,
                 sys.obj$  o,
                 sys.ts$   ts,
                 sys.seg$  s,
                 sys.file$ f,
                 (select 'TABLE'  OBJECT_TYPE,
                         2        OBJECT_TYPE_ID,
                         5        SEGMENT_TYPE_ID,
                         t.obj#   OBJECT_ID,
                         t.file#  HEADER_FILE,
                         t.block# HEADER_BLOCK,
                         t.ts#    TS_NUMBER
                  from sys.tab$ t
                  where bitand(t.property, 1024) = 0
                    and bitand(t.property, 8192) != 8192
                 ) so
            where s.file#  = so.header_file
              and s.block# = so.header_block
              and s.ts#    = so.ts_number
              and s.ts#    = ts.ts#
              and o.obj#   = so.object_id
              and o.owner# = u.user#
              and s.type#  = so.segment_type_id
              and o.type#  = so.object_type_id
              and s.ts#    = f.ts#
              and s.file#  = f.relfile#
            UNION ALL
            select /*+ USE_NL(U O SO) */
                   u.name           OWNER,
                   o.name           SEGMENT_NAME,
                   o.subname        PARTITION_NAME,
                   so.object_type   SEGMENT_TYPE,
                   ts.ts#           TABLESPACE_ID,
                   s.block#         HEADER_BLOCK,
                   s.file#          RELATIVE_FNO,
                   NVL(s.spare1,0)  SEGMENT_FLAGS,
                   o.dataobj#       DATA_OBJECT_ID
            from sys.user$ u,
                 sys.obj$  o,
                 sys.ts$   ts,
                 sys.seg$  s,
                 sys.file$ f,
                 (select /*+ INDEX(TP) */
                         'TABLE PARTITION' OBJECT_TYPE,
                         19                OBJECT_TYPE_ID,
                         5                 SEGMENT_TYPE_ID,
                         tp.obj#           OBJECT_ID,
                         tp.file#          HEADER_FILE,
                         tp.block#         HEADER_BLOCK,
                         tp.ts#            TS_NUMBER
                  from sys.tabpart$ tp
                 ) so
            where s.file#  = so.header_file
              and s.block# = so.header_block
              and s.ts#    = so.ts_number
              and s.ts#    = ts.ts#
              and o.obj#   = so.object_id
              and o.owner# = u.user#
              and s.type#  = so.segment_type_id
              and o.type#  = so.object_type_id
              and s.ts#    = f.ts#
              and s.file#  = f.relfile#
            UNION ALL
            select u.name           OWNER,
                   o.name           SEGMENT_NAME,
                   o.subname        PARTITION_NAME,
                   so.object_type   SEGMENT_TYPE,
                   ts.ts#           TABLESPACE_ID,
                   s.block#         HEADER_BLOCK,
                   s.file#          RELATIVE_FNO,
                   NVL(s.spare1,0)  SEGMENT_FLAGS,
                   o.dataobj#       DATA_OBJECT_ID
            from sys.user$ u,
                 sys.obj$  o,
                 sys.ts$   ts,
                 sys.seg$  s,
                 sys.file$ f,
                 (select /*+ INDEX(TSP) */
                         'TABLE SUBPARTITION' OBJECT_TYPE,
                         34                   OBJECT_TYPE_ID,
                         5                    SEGMENT_TYPE_ID,
                         tsp.obj#             OBJECT_ID,
                         tsp.file#            HEADER_FILE,
                         tsp.block#           HEADER_BLOCK,
                         tsp.ts#              TS_NUMBER
                  from sys.tabsubpart$ tsp
                 ) so
            where s.file#  = so.header_file
              and s.block# = so.header_block
              and s.ts#    = so.ts_number
              and s.ts#    = ts.ts#
              and o.obj#   = so.object_id
              and o.owner# = u.user#
              and s.type#  = so.segment_type_id
              and o.type#  = so.object_type_id
              and s.ts#    = f.ts#
              and s.file#  = f.relfile#
           ) ds,
           sys.file$ f
      where e.segfile#  = ds.relative_fno
        and e.segblock# = ds.header_block
        and e.ts#       = ds.tablespace_id
        and e.ts#       = f.ts#
        and e.file#     = f.relfile#
        and bitand(NVL(ds.segment_flags,0), 1) = 0
      union all
      select /*+ ordered use_nl(e) use_nl(f) */
             ds.owner,
             ds.segment_name,
             ds.partition_name,
             ds.segment_type,
             e.ktfbuebno       BLOCK_ID,
             e.ktfbueblks      BLOCKS,
             e.ktfbuefno       RELATIVE_FNO,
             ds.data_object_id
      from (select u.name           OWNER,
                   o.name           SEGMENT_NAME,
                   o.subname        PARTITION_NAME,
                   so.object_type   SEGMENT_TYPE,
                   ts.ts#           TABLESPACE_ID,
                   s.block#         HEADER_BLOCK,
                   s.file#          RELATIVE_FNO,
                   NVL(s.spare1,0)  SEGMENT_FLAGS,
                   o.dataobj#       DATA_OBJECT_ID
            from sys.user$ u,
                 sys.obj$  o,
                 sys.ts$   ts,
                 sys.seg$  s,
                 sys.file$ f,
                 (select 'TABLE'  OBJECT_TYPE,
                         2        OBJECT_TYPE_ID,
                         5        SEGMENT_TYPE_ID,
                         t.obj#   OBJECT_ID,
                         t.file#  HEADER_FILE,
                         t.block# HEADER_BLOCK,
                         t.ts#    TS_NUMBER
                  from sys.tab$ t
                  where bitand(t.property, 1024) = 0
                    and bitand(t.property, 8192) != 8192
                 ) so
            where s.file#  = so.header_file
              and s.block# = so.header_block
              and s.ts#    = so.ts_number
              and s.ts#    = ts.ts#
              and o.obj#   = so.object_id
              and o.owner# = u.user#
              and s.type#  = so.segment_type_id
              and o.type#  = so.object_type_id
              and s.ts#    = f.ts#
              and s.file#  = f.relfile#
            UNION ALL
            select /*+ USE_NL(U O SO) */
                   u.name           OWNER,
                   o.name           SEGMENT_NAME,
                   o.subname        PARTITION_NAME,
                   so.object_type   SEGMENT_TYPE,
                   ts.ts#           TABLESPACE_ID,
                   s.block#         HEADER_BLOCK,
                   s.file#          RELATIVE_FNO,
                   NVL(s.spare1,0)  SEGMENT_FLAGS,
                   o.dataobj#       DATA_OBJECT_ID
            from sys.user$ u,
                 sys.obj$  o,
                 sys.ts$   ts,
                 sys.seg$  s,
                 sys.file$ f,
                 (select /*+ INDEX(TP) */
                         'TABLE PARTITION' OBJECT_TYPE,
                         19                OBJECT_TYPE_ID,
                         5                 SEGMENT_TYPE_ID,
                         tp.obj#           OBJECT_ID,
                         tp.file#          HEADER_FILE,
                         tp.block#         HEADER_BLOCK,
                         tp.ts#            TS_NUMBER
                  from sys.tabpart$ tp
                 ) so
            where s.file#  = so.header_file
              and s.block# = so.header_block
              and s.ts#    = so.ts_number
              and s.ts#    = ts.ts#
              and o.obj#   = so.object_id
              and o.owner# = u.user#
              and s.type#  = so.segment_type_id
              and o.type#  = so.object_type_id
              and s.ts#    = f.ts#
              and s.file#  = f.relfile#
            UNION ALL
            select u.name           OWNER,
                   o.name           SEGMENT_NAME,
                   o.subname        PARTITION_NAME,
                   so.object_type   SEGMENT_TYPE,
                   ts.ts#           TABLESPACE_ID,
                   s.block#         HEADER_BLOCK,
                   s.file#          RELATIVE_FNO,
                   NVL(s.spare1,0)  SEGMENT_FLAGS,
                   o.dataobj#       DATA_OBJECT_ID
            from sys.user$ u,
                 sys.obj$  o,
                 sys.ts$   ts,
                 sys.seg$  s,
                 sys.file$ f,
                 (select /*+ INDEX(TSP) */
                         'TABLE SUBPARTITION' OBJECT_TYPE,
                         34                   OBJECT_TYPE_ID,
                         5                    SEGMENT_TYPE_ID,
                         tsp.obj#             OBJECT_ID,
                         tsp.file#            HEADER_FILE,
                         tsp.block#           HEADER_BLOCK,
                         tsp.ts#              TS_NUMBER
                  from sys.tabsubpart$ tsp
                 ) so
            where s.file#  = so.header_file
              and s.block# = so.header_block
              and s.ts#    = so.ts_number
              and s.ts#    = ts.ts#
              and o.obj#   = so.object_id
              and o.owner# = u.user#
              and s.type#  = so.segment_type_id
              and o.type#  = so.object_type_id
              and s.ts#    = f.ts#
              and s.file#  = f.relfile#
           ) ds,
           sys.x$ktfbue e,
           sys.file$ f
      where e.ktfbuesegfno = ds.relative_fno
        and e.ktfbuesegbno = ds.header_block
        and e.ktfbuesegtsn = ds.tablespace_id
        and e.ktfbuesegtsn = f.ts#
        and e.ktfbuefno    = f.relfile#
        and bitand(NVL(ds.segment_flags, 0), 1) = 1
     )
/


create view ALL_SCHEDULER_GLOBAL_ATTRIBUTE (ATTRIBUTE_NAME, VALUE) as
SELECT o.name, a.value
 FROM sys.obj$ o, sys.scheduler$_global_attribute a
 WHERE o.obj# = a.obj# AND BITAND(a.flags,1) != 1
/

comment on table ALL_SCHEDULER_GLOBAL_ATTRIBUTE is 'All scheduler global attributes'
/

comment on column ALL_SCHEDULER_GLOBAL_ATTRIBUTE.ATTRIBUTE_NAME is 'Name of the scheduler global attribute'
/

comment on column ALL_SCHEDULER_GLOBAL_ATTRIBUTE.VALUE is 'Value of the scheduler global attribute'
/


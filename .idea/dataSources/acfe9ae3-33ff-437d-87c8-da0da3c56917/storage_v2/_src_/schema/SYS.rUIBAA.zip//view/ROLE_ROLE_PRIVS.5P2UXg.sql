create view ROLE_ROLE_PRIVS (ROLE, GRANTED_ROLE, ADMIN_OPTION) as
select u1.name,u2.name,decode(min(option$),1,'YES','NO')
from  sys.user$ u1, sys.user$ u2, sys.sysauth$ sa
where grantee# in
   (select distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
   and u1.user#=sa.grantee# and u2.user#=sa.privilege#
group by u1.name,u2.name
/

comment on table ROLE_ROLE_PRIVS is 'Roles which are granted to roles'
/

comment on column ROLE_ROLE_PRIVS.ROLE is 'Role Name'
/

comment on column ROLE_ROLE_PRIVS.GRANTED_ROLE is 'Role which was granted'
/

comment on column ROLE_ROLE_PRIVS.ADMIN_OPTION is 'Grant was with the ADMIN option'
/


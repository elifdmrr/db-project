create view DBA_REPOBJECT
            (SNAME, ONAME, TYPE, STATUS, GENERATION_STATUS, ID, OBJECT_COMMENT, GNAME, MIN_COMMUNICATION,
             REPLICATION_TRIGGER_EXISTS, INTERNAL_PACKAGE_EXISTS, GROUP_OWNER, NESTED_TABLE)
as
select r.sname, r.oname, r.type, r.status, r.generation_status, r.id,
       r.object_comment, r.gname, r.min_communication,
       r.trigflag replication_trigger_exists, r.internal_package_exists,
       r.gowner, r.nested_table
from repcat_repobject r
where r.type != 'INTERNAL PACKAGE'
/

comment on table DBA_REPOBJECT is 'Information about replicated objects'
/

comment on column DBA_REPOBJECT.SNAME is 'Name of the object owner'
/

comment on column DBA_REPOBJECT.ONAME is 'Name of the object'
/

comment on column DBA_REPOBJECT.TYPE is 'Type of the object'
/

comment on column DBA_REPOBJECT.STATUS is 'Status of the last create or alter request on the local object'
/

comment on column DBA_REPOBJECT.GENERATION_STATUS is 'Status of whether the object needs to generate replication packages'
/

comment on column DBA_REPOBJECT.ID is 'Identifier of the local object'
/

comment on column DBA_REPOBJECT.OBJECT_COMMENT is 'Description of the replicated object'
/

comment on column DBA_REPOBJECT.GNAME is 'Name of the replicated object group'
/

comment on column DBA_REPOBJECT.MIN_COMMUNICATION is 'Send only necessary OLD and NEW values for an updated row?'
/

comment on column DBA_REPOBJECT.REPLICATION_TRIGGER_EXISTS is 'Internal replication trigger exists?'
/

comment on column DBA_REPOBJECT.INTERNAL_PACKAGE_EXISTS is 'Internal package exists?'
/

comment on column DBA_REPOBJECT.GROUP_OWNER is 'Owner of the replicated object group'
/

comment on column DBA_REPOBJECT.NESTED_TABLE is 'Storage table for a nested table column?'
/


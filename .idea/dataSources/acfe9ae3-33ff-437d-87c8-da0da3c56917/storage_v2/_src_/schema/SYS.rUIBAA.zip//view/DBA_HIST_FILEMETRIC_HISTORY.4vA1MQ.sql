create view DBA_HIST_FILEMETRIC_HISTORY
            (SNAP_ID, DBID, INSTANCE_NUMBER, FILEID, CREATIONTIME, BEGIN_TIME, END_TIME, INTSIZE, GROUP_ID, AVGREADTIME,
             AVGWRITETIME, PHYSICALREAD, PHYSICALWRITE, PHYBLKREAD, PHYBLKWRITE)
as
select fm.snap_id, fm.dbid, fm.instance_number,
       fileid, creationtime, begin_time,
       end_time, intsize, group_id, avgreadtime, avgwritetime,
       physicalread, physicalwrite, phyblkread, phyblkwrite
  from wrm$_snapshot sn, WRH$_FILEMETRIC_HISTORY fm
  where     sn.snap_id         = fm.snap_id
        and sn.dbid            = fm.dbid
        and sn.instance_number = fm.instance_number
        and sn.status          = 0
/

comment on table DBA_HIST_FILEMETRIC_HISTORY is 'File Metrics History'
/


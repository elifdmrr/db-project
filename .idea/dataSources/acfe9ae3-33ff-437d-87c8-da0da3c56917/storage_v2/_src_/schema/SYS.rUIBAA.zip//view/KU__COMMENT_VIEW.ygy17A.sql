create view KU$_COMMENT_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, BASE_OBJ, PROPERTY, COLNO, COLNAME, CMNT) as
select '1','0',
         cm.obj#, value(o),
         (select t.property from sys.tab$ t where t.obj#=cm.obj#),
         cm.col#,
         (select c.name
                 from  sys.col$ c
                 where  c.obj#=cm.obj# and c.intcol# = cm.col# ),
         TO_CLOB(replace(cm.comment$,'''',''''''))
  from   sys.ku$_schemaobj_view o,
                sys.com$ cm
  where  o.obj_num = cm.obj# AND
         (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
             EXISTS ( SELECT * FROM sys.session_roles
                WHERE role='SELECT_CATALOG_ROLE' ))
/


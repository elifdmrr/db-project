create view GV_$PARALLEL_DEGREE_LIMIT_MTH (INST_ID, NAME) as
select "INST_ID","NAME" from gv$parallel_degree_limit_mth
/


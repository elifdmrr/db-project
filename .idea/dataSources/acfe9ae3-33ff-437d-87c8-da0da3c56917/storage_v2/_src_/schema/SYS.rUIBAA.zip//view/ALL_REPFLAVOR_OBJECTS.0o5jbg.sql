create view ALL_REPFLAVOR_OBJECTS (FNAME, GNAME, SNAME, ONAME, TYPE, GROUP_OWNER) as
SELECT UNIQUE fo.fname, fo.gname, fo.sname, fo.oname,
       fo.type, fo.group_owner
from dba_repflavor_objects fo, all_objects o
where fo.sname = o.owner
  and fo.oname = o.object_name
  and (fo.type = o.object_type OR
       fo.type = 'SNAPSHOT' and o.object_type IN ('VIEW', 'TABLE'))
/

comment on table ALL_REPFLAVOR_OBJECTS is 'Replicated objects in flavors'
/

comment on column ALL_REPFLAVOR_OBJECTS.FNAME is 'Flavor name'
/

comment on column ALL_REPFLAVOR_OBJECTS.GNAME is 'Object group name'
/

comment on column ALL_REPFLAVOR_OBJECTS.SNAME is 'Schema containing object'
/

comment on column ALL_REPFLAVOR_OBJECTS.ONAME is 'Name of object'
/

comment on column ALL_REPFLAVOR_OBJECTS.TYPE is 'Object type'
/

comment on column ALL_REPFLAVOR_OBJECTS.GROUP_OWNER is 'Object group owner'
/


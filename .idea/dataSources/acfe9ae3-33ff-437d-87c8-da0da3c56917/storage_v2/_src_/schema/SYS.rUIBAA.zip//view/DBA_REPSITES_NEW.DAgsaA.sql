create view DBA_REPSITES_NEW (EXTENSION_ID, GOWNER, GNAME, DBLINK, FULL_INSTANTIATION, MASTER_STATUS) as
select
  r.extension_id,
  r.gowner,
  r.gname,
  r.dblink,
  r.full_instantiation,
  DECODE(r.master_status,
         0, 'READY',
         1, 'INSTANTIATING',
         2, 'INSTANTIATED',
         3, 'PREPARED') master_status
from system.repcat$_sites_new r
/

comment on table DBA_REPSITES_NEW is 'Information about new masters for replication extension'
/

comment on column DBA_REPSITES_NEW.EXTENSION_ID is 'Globally unique identifier for replication extension'
/

comment on column DBA_REPSITES_NEW.GOWNER is 'Owner of the object group'
/

comment on column DBA_REPSITES_NEW.GNAME is 'Name of the replicated object group'
/

comment on column DBA_REPSITES_NEW.DBLINK is 'A database site that will replicate the object group'
/

comment on column DBA_REPSITES_NEW.FULL_INSTANTIATION is 'Y if the database uses full-database export or change-based recovery'
/

comment on column DBA_REPSITES_NEW.MASTER_STATUS is 'Instantiation status of the new master'
/


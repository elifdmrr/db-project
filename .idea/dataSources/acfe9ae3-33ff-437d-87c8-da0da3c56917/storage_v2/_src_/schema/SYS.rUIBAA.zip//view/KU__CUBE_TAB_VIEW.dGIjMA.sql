create view KU$_CUBE_TAB_VIEW (OBJ_NUM, AWNAME, FLAGS, DIMS, FACTS, CGID) as
select ot.obj#, aw.awname, ot.flags,
    cast( multiset(select ofv.obj#, ofv.colname, ofv.objname,
                    (select ol.objname                     /*dimusing*/
                     from ku$_cube_fact_view ol
                     where ol.obj#=ot.obj#
                     and ol.coltype=10
                     and ol.pcol#=ofv.col#),
                    cast( multiset(select ol.obj#,              /*gid*/
                                          ol.colname, ol.pcolname, null,
                                          ol.objname, ol.qdr,
                                          ol.qdrval, ol.flags
                                     from ku$_cube_fact_view ol
                                     where ol.obj#=ot.obj#
                                     and ol.coltype=5
                                     and ol.pcol#=ofv.col#
                                   ) as ku$_cube_fact_list_t
                        ),
                    cast( multiset(select ol.obj#,              /*pgid*/
                                          ol.colname, ol.pcolname, null,
                                          ol.objname, ol.qdr,
                                          ol.qdrval, ol.flags
                                     from ku$_cube_fact_view ol
                                     where ol.obj#=ot.obj#
                                     and ol.coltype=6
                                     and ol.pcol#=ofv.col#
                                  ) as ku$_cube_fact_list_t
                        ),
                    cast( multiset(select ol.obj#,              /*attr*/
                                          ol.colname, ol.pcolname, null,
                                          ol.objname, ol.qdr,
                                          ol.qdrval, ol.flags
                                     from ku$_cube_fact_view ol
                                     where ol.obj#=ot.obj#
                                     and ol.coltype=4
                                     and ol.pcol#=ofv.col#
                                   ) as ku$_cube_fact_list_t
                        ),
                    cast( multiset(select ol.obj#,              /*lvls*/
                                          ol.colname, ol.pcolname, null,
                                          ol.objname, ol.qdr,
                                          ol.qdrval, ol.flags
                                     from ku$_cube_fact_view ol
                                     where ol.obj#=ot.obj#
                                     and ol.coltype=3
                                     and ol.pcol#=ofv.col#
                                  ) as ku$_cube_fact_list_t
                        ),
                    cast( multiset(select ol.obj#, ol.objname, ol.qdr,
                                          ol.qdrval,
                                          cast( multiset(select
                                                           lvl.obj#,
                                                           lvl.colname,
                                                           lvl.pcolname,
                                                           null,
                                                           lvl.objname,
                                                           lvl.qdr,
                                                           lvl.qdrval,
                                                           oh.flags
                                            from ku$_cube_fact_view lvl,
                                                 sys.olap_tab_hier$ oh
                                            where oh.hier#=ol.hier#
                                              and oh.obj#=ol.obj#
                                              and lvl.obj#=oh.obj#
                                              and (lvl.pcol#=ofv.col#
                                               or (lvl.col#=ofv.col#
                                               and (oh.flags=1)))
                                              and lvl.colname=
                           (select col.name from sys.col$ col
                              where col.obj#=oh.obj# and col.col#=oh.col#)
                                            order by oh.ord
                                                ) as ku$_cube_fact_list_t
                                              ),
                                          ol.flags
                                     from ku$_cube_fact_view ol
                                     where ol.obj#=ot.obj#
                                     and ol.coltype=7
                                     and ol.pcol#=ofv.col#
                                   ) as ku$_cube_hier_list_t
                        ),
                    ofv.flags /* flags */
                    from ku$_cube_fact_view ofv
                    where ofv.coltype=2 and ofv.obj#=ot.obj#
                  ) as ku$_cube_dim_list_t
        ),
    /* FACTs */
    cast( multiset(select ofv.obj#, ofv.colname, ofv.pcolname,
                          (select col.name from sys.col$ col        /* COUNT */
                             where col.obj#=ofv.obj# and col.col#=
                               (select otc.col# from olap_tab_col$ otc
                                  where otc.obj#=ofv.obj# and
                                        otc.pcol#=ofv.col# and
                                        otc.coltype=9)),
                          ofv.objname, ofv.qdr, ofv.qdrval, ofv.flags
                     from ku$_cube_fact_view ofv
                     where ofv.coltype=1 and ofv.obj#=ot.obj#
                  ) as ku$_cube_fact_list_t
        ),
    /* CGID */
    cast( multiset(select ofv.obj#, ofv.colname, ofv.pcolname, null,
                          ofv.objname, ofv.qdr, ofv.qdrval, ofv.flags
                     from ku$_cube_fact_view ofv
                     where ofv.coltype=8 and ofv.obj#=ot.obj#
                     order by ofv.col#
                  ) as ku$_cube_fact_list_t
        )
  from sys.olap_tab$ ot, sys.aw$ aw
    where aw.awseq#=ot.awseq#
/


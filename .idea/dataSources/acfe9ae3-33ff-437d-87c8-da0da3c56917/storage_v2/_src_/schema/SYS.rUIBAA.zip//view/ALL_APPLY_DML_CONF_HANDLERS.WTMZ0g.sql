create view ALL_APPLY_DML_CONF_HANDLERS
            (APPLY_NAME, SCHEMA_NAME, OBJECT_NAME, OPERATION_NAME, CONFLICT_TYPE, METHOD_NAME, OLD_SCHEMA,
             OLD_OBJECT) as
select h."APPLY_NAME",h."SCHEMA_NAME",h."OBJECT_NAME",h."OPERATION_NAME",h."CONFLICT_TYPE",h."METHOD_NAME",h."OLD_SCHEMA",h."OLD_OBJECT"
from all_tables o, all_apply a, DBA_APPLY_DML_CONF_HANDLERS h
where h.schema_name = o.owner and h.object_name = o.table_name and
      a.apply_name = h.apply_name
/

comment on table ALL_APPLY_DML_CONF_HANDLERS is 'Details about dml conflict handlers on tables visible to the current user'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.APPLY_NAME is 'Name of the apply process'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.SCHEMA_NAME is 'Owner of the target object'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.OBJECT_NAME is 'Name of the target object'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.OPERATION_NAME is 'Type of DML operation'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.CONFLICT_TYPE is 'Description of the conflict'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.METHOD_NAME is 'Description of the conflict handling method'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.OLD_SCHEMA is 'Owner of the source object'
/

comment on column ALL_APPLY_DML_CONF_HANDLERS.OLD_OBJECT is 'Name of the source object'
/


create view KU$_HDEPTABLE_OBJNUM_VIEW (OBJ_NUM, SCHEMA_OBJ, BASE_OBJ) as
select exdo.d_obj#, value(po), value(do)
  from expdepobj$ exdo, ku$_schemaobj_view po, ku$_schemaobj_view do
  where exdo.p_obj# = po.obj_num
  AND exdo.d_obj# = do.obj_num
  AND do.TYPE_name='TABLE'
  AND (bitand(do.flags,16)!=16)
  AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (po.owner_num, 0)
        OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/


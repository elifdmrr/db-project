create view DBA_MVIEWS
            (OWNER, MVIEW_NAME, CONTAINER_NAME, QUERY, QUERY_LEN, UPDATABLE, UPDATE_LOG, MASTER_ROLLBACK_SEG,
             MASTER_LINK, REWRITE_ENABLED, REWRITE_CAPABILITY, REFRESH_MODE, REFRESH_METHOD, BUILD_MODE,
             FAST_REFRESHABLE, LAST_REFRESH_TYPE, LAST_REFRESH_DATE, STALENESS, AFTER_FAST_REFRESH, UNKNOWN_PREBUILT,
             UNKNOWN_PLSQL_FUNC, UNKNOWN_EXTERNAL_TABLE, UNKNOWN_CONSIDER_FRESH, UNKNOWN_IMPORT, UNKNOWN_TRUSTED_FD,
             COMPILE_STATE, USE_NO_INDEX, STALE_SINCE, NUM_PCT_TABLES, NUM_FRESH_PCT_REGIONS, NUM_STALE_PCT_REGIONS)
as
select s.sowner as OWNER, s.vname as MVIEW_NAME, s.tname as CONTAINER_NAME,
  s.query_txt as QUERY, s.query_len as QUERY_LEN,
       decode(bitand(s.flag,2), 0, 'N', 'Y') as UPDATABLE,  /* updatable */
       s.uslog as UPDATE_LOG, s.mas_roll_seg as MASTER_ROLLBACK_SEG, s.mlink as MASTER_LINK,
       decode(w.mflags,
              '', '',  /* missing summary */
              decode(bitand(w.mflags, 4), 4, 'N', 'Y')) as REWRITE_ENABLED,
       /* rewrite capability
        *   KKQS_NOGR_PFLAGS:
        *     QSMG_SUM_PART_EXT_NAME + QSMG_SUM_CONNECT_BY +
        *     QSMG_SUM_RAW_OUTPUT + QSMG_SUM_SUBQUERY_HAVING +
        *     QSMG_SUM_SUBQUERY_WHERE + QSMG_SUM_SET_OPERATOR +
        *     QSMG_SUM_NESTED_CURSOR + QSMG_SUM_OUT_MISSING_GRPCOL +
        *     QSMG_SUM_AGGREGATE_NOT_TOP
        *
        *   KKQS_NOGR_XPFLAGS:
        *     QSMG_SUM_WCLS
        *
        *   QSMG_SUM_DATA_IGNORE - 2nd-class summary
        */
       decode(w.pflags,
              '', '',  /* missing summary */
              decode(bitand(w.pflags, 1073741824), /* 2nd-class summary */
                     1073741824, 'NONE',
                     /* 2152929292 = 2147483648 + 2048 + 4096 + 65536 + 131072 +
                      *              1048576 + 4194304 + 8 + 4
                      */
                     decode(bitand(w.pflags, 2152929292),
                            0, decode(bitand(w.xpflags, 8192),
                                      8192, 'TEXTMATCH',
                                      'GENERAL'),
                            'TEXTMATCH'))) as REWRITE_CAPABILITY,
       decode(s.auto_fast,
              'N', 'NEVER',
              decode(bitand(s.flag, 32768), 0, 'DEMAND', 'COMMIT')) as REFRESH_MODE,
       decode(s.auto_fast,   /* refresh method */
              'C',  'COMPLETE',
              'F',  'FAST',
              '?',  'FORCE',
              'N',  'NEVER',
              NULL, 'FORCE', 'ERROR') as REFRESH_METHOD,
       decode(bitand(s.flag, 131072),  /* build mode */
              131072, 'PREBUILT',
              decode(bitand(s.flag, 524288), 0, 'IMMEDIATE', 'DEFERRED')) as BUILD_MODE,
       /* fast refreshable
        *     rowid+primary key+object id+subquery+complex+MAV+MJV+MAV1
        *     536900016 = 16+32+536870912+128+256+4096+8192+16384
        */
     decode(bitand(s.flag2, 67108864),
            67108864,
            /* if primary CUBE MV, use its secondary MV's flag value to
             * determine its FAST REFRESHABILITY. */
              (decode(bitand((select s2.flag from sys.snap$ s2
                              where s2.parent_sowner=s.sowner and s2.parent_vname=s.vname), 536900016),
              16,        'DIRLOAD_DML',  /* rowid */
              32,        'DIRLOAD_DML',  /* primary key */
              536870912, 'DIRLOAD_DML',  /* object id */
              160,       'DIRLOAD_DML',  /* subquery - has both the primary key     */
                                 /* bit and the subquery bit  (32+128)      */
              536871040, 'DIRLOAD_DML',  /* subquery - has both the object id bit   */
                                 /* and the subquery bit (536870912+128)    */
              256,       'NO',   /* complex */
              4096,   decode(bitand(s.flag2,23),            /* KKZFAGG_INSO */
                             0,
                             'DIRLOAD_DML',                  /* regular MAV */
                             'DIRLOAD_LIMITEDDML'),      /* insert only MAV */
              8192,      'DIRLOAD_DML', /* MJV */
              16384,     'DIRLOAD_DML', /* MAV1 */
              decode(bitand(s.flag2, 16384),
                     16384,   'DIRLOAD_DML', /* UNION_ALL MV */
                     'ERROR'))),
            decode(
              bitand(s.flag, 536900016),
              16,        'DIRLOAD_DML',  /* rowid */
              32,        'DIRLOAD_DML',  /* primary key */
              536870912, 'DIRLOAD_DML',  /* object id */
              160,       'DIRLOAD_DML',  /* subquery - has both the primary key     */
                                 /* bit and the subquery bit  (32+128)      */
              536871040, 'DIRLOAD_DML',  /* subquery - has both the object id bit   */
                                 /* and the subquery bit (536870912+128)    */
              256,       'NO',   /* complex */
              4096,   decode(bitand(s.flag2,23),            /* KKZFAGG_INSO */
                             0,
                             'DIRLOAD_DML',                  /* regular MAV */
                             'DIRLOAD_LIMITEDDML'),      /* insert only MAV */
              8192,      'DIRLOAD_DML', /* MJV */
              16384,     'DIRLOAD_DML', /* MAV1 */
              decode(bitand(s.flag2, 16384),
                     16384,   'DIRLOAD_DML', /* UNION_ALL MV */
                     'ERROR'))) as FAST_REFRESHABLE,
       /* fixing bug 923186 */
       decode(w.mflags,                    /*last refresh type */
              '','',                       /*missing summary */
              decode(bitand(w.mflags,16384+32768+4194304+1073741824),
                     0, 'NA',
                     16384, 'COMPLETE',
                     32768, 'FAST',
                     4194304, 'FAST_PCT',
                     1073741824, 'FAST_CS',
                     'ERROR')) as LAST_REFRESH_TYPE,
       /* end fixing bug 923186 */
       /* the last refresh date should be of date type and not varchar,
       ** SO BE CAREFUL WITH CHANGES IN THE FOLLOWING DECODE
       */
       decode(w.lastrefreshdate,  /* last refresh date */
              NULL, to_date(NULL, 'DD-MON-YYYY'),  /* missing summary */
              decode(to_char(w.lastrefreshdate,'DD-MM-YYYY'),'01-01-1950',
              to_date(NULL, 'DD-MON-YYYY'), w.lastrefreshdate)) as LAST_REFRESH_DATE,
       /* staleness */
        decode(NVL(s.mlink,'null'),  /* not null implies remote */
              'null', decode(bitand(s.status, 4),  /* snapshot-invalid */
                             4, 'UNUSABLE',
                             decode(o.status,
                                    1, decode(w.mflags,
                                         '', '',  /* missing summary */
                                         decode(bitand(w.mflags, 8388608),
                                                8388608, 'IMPORT',            /* mv imported */
                                                decode(bitand(w.mflags, 64),  /* wh-unusable */
                                                       64, 'UNUSABLE',        /* unusable */
                                                       decode(bitand(w.mflags, 32),
                                                              0,    /* unknown */
                                            /* known stale */  decode(bitand(w.mflags, 1),
                                                              0, 'FRESH',
                                                              'STALE'), 'UNKNOWN')))),
                                    2, 'AUTHORIZATION_ERROR',
                                    3, 'COMPILATION_ERROR',
                                    5, 'NEEDS_COMPILE',
                                    'ERROR')),
              'UNDEFINED') as STALENESS,  /* remote MV */
       /* after fast refresh */
       /* in the decode for after fast refresh, we only have to check
        * whether w.mflags is null once.  all of the other occurences
        * fall under the first check.  if the summary information is not
        * null, we need to check for the warehouse unusable condition
        * before we check to see if the MV is complex.  if the summary
        * information is null, we still need to check whether the MV
        * is complex.
        */
       decode(NVL(s.mlink,'null'),  /* remote */
              'null', decode(s.auto_fast,  /* never refresh */
                         'N', 'NA',
                         decode(bitand(s.flag, 32768),  /* on commit */
                             32768, 'NA',
                             decode(bitand(s.status, 4),  /* snap-invalid */
                                4, 'NA',
                                decode(w.mflags,  /* missing summary */
                                   '', decode(bitand(s.flag, 256), /* complex */
                                              256, 'NA',
                                              ''),
                                   decode(o.status,
                                      1, decode(bitand(w.mflags, 8388608),
                                            8388608, 'UNKNOWN',        /* imported */
                  /* warehouse unusable */  decode(bitand(w.mflags, 64),
                                               64, 'NA',
                                               decode(bitand(s.flag, 256), /*complex*/
                                                  256, 'NA',
                                 /* unknown */    decode(bitand(w.mflags,32),
                                                     32, 'UNKNOWN',
                                 /* known stale */   decode(bitand(w.mflags, 1),
                                                        0, 'FRESH',
                  /* stale states (on-demand only)
                   * (This decode is the default clause for the known-stale
                   * decode statement.  It should be indented there, but there
                   * isn't enough room.)
                   */
                   decode(bitand(s.flag, 176), /* ri+pk+sq  */
                                               /* 16+32+128 */
                          0, decode(bitand(s.flag, 28672), /* mjv+mav1+mav  */
                                                         /* 8192+16384+4096 */
                                      0, 'ERROR', /* no mv type */
                /* mjv/mav/mav1 MV */ decode(bitand(w.mflags, 1576832),
                           /* 1576832 = 128+256+512+1024+2048+524288+1048576*/
                                      /*si + su + lsi + lsu + sf + sp + spu */
                                             128, 'FRESH',     /* si */
                                             256, 'UNKNOWN',   /* su */
                                             512, 'STALE',     /* sf */
                                             1024, 'FRESH',    /* lsi */
                                             2048, 'UNKNOWN',  /* lsu */
                                             524288, 'FRESH',  /* sp */
                                             1048576, 'UNKNOWN', /* spu */
                            /* 128+1024 */   1152, 'FRESH',    /* si+lsi*/
                            /* 256+2048 */   2304, 'UNKNOWN',  /* su+lsu*/
                                             'ERROR')),
   /* ri or pk or sq MV */  decode(bitand(w.mflags, 1576832),
                             /* 1576832 = 128+256+512+1024+2048+524288+1048576 */
                                   128, 'STALE',     /* si */
                                   256, 'STALE',     /* su */
                                   512, 'STALE',     /* sf */
                                   1024, 'FRESH',    /* lsi */
                                   2048, 'UNKNOWN',  /* lsu */
                                   524288, 'FRESH',  /* sp */
                                   1048576, 'UNKNOWN', /* spu */
                  /* 128+1024 */   1152, 'STALE',    /* si+lsi*/
                  /* 256+2048 */   2304, 'STALE',    /* su+lsu*/
                                   'ERROR'))))))),
                      2, 'AUTHORIZATION_ERROR',
                      3, 'COMPILATION_ERROR',
                      5, 'NEEDS_COMPILE',
                      'ERROR'))))),
              'UNDEFINED') as AFTER_FAST_REFRESH, /* remote mv */
       /* UNKNOWN_PREBUILT */
       decode(w.pflags,
              '','', /* missing summary */
              decode(bitand(s.flag, 131072),
                    131072, 'Y', 'N')) as UNKNOWN_PREBUILT,
       /* UNKNOWN_PLSQL_FUNC */
       decode(w.pflags,
              '','', /* missing summary */
              decode(bitand(w.pflags, 268435456),
                     268435456, 'Y', 'N')) as UNKNOWN_PLSQL_FUNC,
       /* UNKNOWN_EXTERNAL_TABLE */
       decode(w.xpflags,
              '','', /* missing summary */
              decode(bitand(w.xpflags, 32768),
                     32768, 'Y', 'N')) as UNKNOWN_EXTERNAL_TABLE,
       /* UNKNOWN_CONSIDER_FRESH */
       decode(w.mflags,
              '','', /* missing summary */
              decode(bitand(w.mflags, 8192),
                     8192, 'Y', 'N')) as UNKNOWN_CONSIDER_FRESH,
       /* UNKNOWN_IMPORT */
       decode(w.mflags,
              '','', /* missing summary */
              decode(bitand(w.mflags, 8388608),
                     8388608, 'Y', 'N')) as UNKNOWN_IMPORT,
       /* UNKNOWN_TRUSTED_FD */
       decode(w.mflags,
              '','', /* missing summary */
              decode(bitand(w.mflags, 33554432),
                     33554432, 'Y', 'N')) as UNKNOWN_TRUSTED_FD,
       decode(o.status,
              1, 'VALID',
              2, 'AUTHORIZATION_ERROR',
              3, 'COMPILATION_ERROR',
              5, 'NEEDS_COMPILE', 'ERROR') as COMPILE_STATE, /* compile st*/
       decode(bitand(s.flag2,1024), 0, 'N', 'Y') as USE_NO_INDEX, /* USE NO INDEX ? */
       (select min(TIME_DP) from sys.SMON_SCN_TIME
        where (SCN_WRP*4294967295+ SCN_BAS) >
              (select min(t.spare3)
               from tab$ t, dependency$ d
               where t.obj#= d.p_obj# and w.obj#=d.d_obj# and
                     t.spare3 > w.lastrefreshscn)) as STALE_SINCE,
           /* whether this is a PCT refresh enabled primary CUBE MV */
       (decode(bitand(w.xpflags, 8589934592), 0,
        (select count(*) as num_pct_tables from
          (select wd.sumobj#, wd.detailobj# from sys.sumdetail$ wd
           where wd.detaileut > 0) wdd where wdd.sumobj# = w.obj#),
        (select count(*) as num_pct_tables from
          (select wd.sumobj#, wd.detailobj# from sys.sumdetail$ wd
           where wd.detaileut > 2147483648 ) /* special secondary cube row */
                wdd where wdd.sumobj# = w.obj#)  )) as NUM_PCT_TABLES,
        (select num_fresh_partns from
             (select sumobj#, sum(num_fresh_partitions) as num_fresh_partns,
                            sum(num_stale_partitions) as num_stale_partns
              from
              (select sumobj#,
               decode(partn_state, 'FRESH', partn_count, 0)
               as num_fresh_partitions,
               decode(partn_state, 'STALE', partn_count, 0)
               as num_stale_partitions
               from
               (select sumobj#, partn_state, count(*) as partn_count from
                (select sumobj#,
                        (case when partn_scn is NULL then 'FRESH'
                         when partn_scn < mv_scn
                         then 'FRESH' else 'STALE' end) partn_state
                 from
                 (select s.obj# as sumobj#, s.lastrefreshscn as mv_scn,
                         t.obj# pobj#, t.obj# as sub_pobj#, t.spare1 as partn_scn
                  from sys.sum$ s, sys.sumdetail$ sd, sys.tabpart$ t
                  where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#
                        and bitand(sd.detaileut, 2147483648) = 0
                                      /* NO secondary CUBE MV rows */
                  union
                  select s.sumobj#, s.mv_scn,
                       s.pobj# pobj#, t.obj# as sub_pobj#,t.spare1 as partn_scn
                  from  tabsubpart$ t,
                   (select s.obj# as sumobj#, s.lastrefreshscn as mv_scn,
                           t.obj# pobj#, t.spare1 as partn_scn
                    from sys.sum$ s, sys.sumdetail$ sd, sys.tabcompart$ t,
                         sys.obj$ o
                    where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#
                        and bitand(sd.detaileut, 2147483648) = 0
                                      /* NO secondary CUBE MV rows */) s
                  where t.pobj# = s.pobj#))
                group by sumobj#, partn_state)) group by sumobj#) nfsp
         where nfsp.sumobj# = w.obj#) as NUM_FRESH_PCT_REGIONS,
        (select num_stale_partns from
             (select sumobj#, sum(num_fresh_partitions) as num_fresh_partns,
                            sum(num_stale_partitions) as num_stale_partns
              from
              (select sumobj#,
               decode(partn_state, 'FRESH', partn_count, 0)
               as num_fresh_partitions,
               decode(partn_state, 'STALE', partn_count, 0)
               as num_stale_partitions
               from
               (select sumobj#, partn_state, count(*) as partn_count from
                (select sumobj#,
                        (case when partn_scn is NULL then 'FRESH'
                         when partn_scn < mv_scn
                         then 'FRESH' else 'STALE' end) partn_state
                 from
                 (select s.obj# as sumobj#, s.lastrefreshscn as mv_scn,
                         t.obj# pobj#, t.obj# as sub_pobj#, t.spare1 as partn_scn
                  from sys.sum$ s, sys.sumdetail$ sd, sys.tabpart$ t
                  where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#
                        and bitand(sd.detaileut, 2147483648) = 0
                                      /* NO secondary CUBE MV rows */
                  union
                  select s.sumobj#, s.mv_scn,
                       s.pobj# pobj#, t.obj# as sub_pobj#,t.spare1 as partn_scn
                  from  tabsubpart$ t,
                   (select s.obj# as sumobj#, s.lastrefreshscn as mv_scn,
                           t.obj# pobj#, t.spare1 as partn_scn
                    from sys.sum$ s, sys.sumdetail$ sd, sys.tabcompart$ t,
                         sys.obj$ o
                    where s.obj# = sd.sumobj# and sd.detailobj# = t.bo#
                          and bitand(sd.detaileut, 2147483648) = 0
                                      /* NO secondary CUBE MV rows */) s
                  where t.pobj# = s.pobj#))
                group by sumobj#, partn_state)) group by sumobj#) nfsp
         where nfsp.sumobj# = w.obj#) as NUM_STALE_PCT_REGIONS
from sys.user$ u, sys.sum$ w, sys.obj$ o, sys.snap$ s
where w.containernam(+) = s.vname
  and o.obj#(+) = w.obj#
  and o.owner# = u.user#(+)
  and ((u.name = s.sowner) or (u.name IS NULL))
  and s.instsite = 0
  and not (bitand(s.flag, 268435456) > 0       /* MV with user-defined types */
           and bitand(s.objflag, 32) > 0)                    /* secondary MV */
  and not (bitand(s.flag2, 33554432) > 0)               /* secondary CUBE MV */
/

comment on table DBA_MVIEWS is 'All materialized views in the database'
/

comment on column DBA_MVIEWS.OWNER is 'Owner of the materialized view'
/

comment on column DBA_MVIEWS.MVIEW_NAME is 'Name of the materialized view'
/

comment on column DBA_MVIEWS.CONTAINER_NAME is 'Name of the materialized view container table'
/

comment on column DBA_MVIEWS.QUERY is 'The defining query that the materialized view instantiates'
/

comment on column DBA_MVIEWS.QUERY_LEN is 'The number of bytes in the defining query (based on the server character set'
/

comment on column DBA_MVIEWS.UPDATABLE is 'Indicates whether the materialized view can be updated'
/

comment on column DBA_MVIEWS.UPDATE_LOG is 'Name of the table that logs changes to an updatable materialized view'
/

comment on column DBA_MVIEWS.MASTER_ROLLBACK_SEG is 'Name of the rollback segment to use at the master site'
/

comment on column DBA_MVIEWS.MASTER_LINK is 'Name of the database link to the master site'
/

comment on column DBA_MVIEWS.REWRITE_ENABLED is 'Indicates whether rewrite is enabled for the materialized view'
/

comment on column DBA_MVIEWS.REWRITE_CAPABILITY is 'Indicates the kind of rewrite that is enabled'
/

comment on column DBA_MVIEWS.REFRESH_MODE is 'Indicates how and when the materialized view will be refreshed'
/

comment on column DBA_MVIEWS.REFRESH_METHOD is 'The default refresh method for the materialized view (complete, fast, ...)'
/

comment on column DBA_MVIEWS.BUILD_MODE is 'How and when to initially build (load) the materialized view container'
/

comment on column DBA_MVIEWS.FAST_REFRESHABLE is 'Indicates the kinds of operations that can be fast refreshed for the MV'
/

comment on column DBA_MVIEWS.LAST_REFRESH_TYPE is 'Indicates the kind of refresh that was last performed on the MV'
/

comment on column DBA_MVIEWS.LAST_REFRESH_DATE is 'The date that the materialized view was last refreshed'
/

comment on column DBA_MVIEWS.STALENESS is 'Indicates the staleness state of the materialized view (fresh, stale, ...)'
/

comment on column DBA_MVIEWS.AFTER_FAST_REFRESH is 'Indicates the staleness state the MV will have after a fast refresh is done'
/

comment on column DBA_MVIEWS.UNKNOWN_PREBUILT is 'Indicates if the materialized view is prebuilt'
/

comment on column DBA_MVIEWS.UNKNOWN_PLSQL_FUNC is 'Indicates if the materialized view contains PL/SQL function'
/

comment on column DBA_MVIEWS.UNKNOWN_EXTERNAL_TABLE is 'Indicates if the materialized view contains external tables'
/

comment on column DBA_MVIEWS.UNKNOWN_CONSIDER_FRESH is 'Indicates if the materialized view is considered fresh'
/

comment on column DBA_MVIEWS.UNKNOWN_IMPORT is 'Indicates if the materialized view is imported'
/

comment on column DBA_MVIEWS.UNKNOWN_TRUSTED_FD is 'Indicates if the materialized view used trusted constraints for refresh'
/

comment on column DBA_MVIEWS.COMPILE_STATE is 'Indicates the validity of the MV meta-data'
/

comment on column DBA_MVIEWS.USE_NO_INDEX is 'Indicates whether the MV uses no index'
/

comment on column DBA_MVIEWS.STALE_SINCE is 'Time from when the materialized view became stale'
/

comment on column DBA_MVIEWS.NUM_PCT_TABLES is 'Number of PCT detail tables'
/

comment on column DBA_MVIEWS.NUM_FRESH_PCT_REGIONS is 'Number of fresh PCT partition regions'
/

comment on column DBA_MVIEWS.NUM_STALE_PCT_REGIONS is 'Number of stale PCT partition regions'
/


create view DBA_OPERATORS (OWNER, OPERATOR_NAME, NUMBER_OF_BINDS) as
select c.name, b.name, a.numbind from
  sys.operator$ a, sys.obj$ b, sys.user$ c where
  a.obj# = b.obj# and b.owner# = c.user#
/

comment on table DBA_OPERATORS is 'All operators'
/

comment on column DBA_OPERATORS.OWNER is 'Owner of the operator'
/

comment on column DBA_OPERATORS.OPERATOR_NAME is 'Name of the operator'
/

comment on column DBA_OPERATORS.NUMBER_OF_BINDS is 'Number of bindings associated with the operator'
/


create view "_DBA_STREAMS_UNSUPPORTED_10_1"
            (OWNER, TABLE_NAME, TPROPERTY, TTRIGFLAG, OFLAGS, TFLAGS, REASON, COMPATIBLE, AUTO_FILTERED) as
select
    distinct u.name, o.name,
             t.property, t.trigflag, o.flags, t.flags,
    (case
      when bitand(t.property, 128 + 512 ) != 0             /* 0x080 + 0x200 */
        then 'IOT with row overflow'
      when bitand(t.property, 256 ) != 0                   /* 0x080 + 0x200 */
        then 'IOT with row clustering'
      when bitand(t.property, 262208) = 262208                   /* 0x40040 */
        then 'IOT with LOB'                                     /* user lob */
      when bitand(t.flags, 268435456) = 268435456             /* 0x10000000 */
        then 'IOT with physical Rowid mapping'
      when bitand(t.flags, 536870912) = 536870912             /* 0x20000000 */
        then 'mapping table for physical rowid of IOT'
      when bitand(t.property, 2112) = 2112 /* 0x40+0x800 IOT + internal LOB */
        then 'IOT with LOB'                                 /* internal lob */
      when (bitand(t.property, 64) = 64 and
            bitand(t.flags, 131072) = 131072)
        then 'IOT with row movement'                             /* 0x20000 */
      when exists (select 1 from sys.partobj$ p
                   where p.obj# = o.obj# and
                         p.parttype = 3)                 /* system partition */
        then 'table with system partition'
      when bitand(t.property,
                  1                                           /* typed table */
                + 2                                           /* ADT columns */
                + 4                                  /* nested table columns */
                + 8                                           /* REF columns */
                + 16                                        /* array columns */
                + 4096                                             /* pk OID */
                + 8192       /* 0x2000 storage table for nested table column */
                + 65536                                      /* 0x10000 sOID */
               ) != 0
        then 'column with user-defined type'
      when ( bitand(nvl(s.spare1, 0), 2048) = 2048  or  /* table compression */
             bitand(nvl(ds.flags_stg, 0), 4) = 4   /* DSC: table compression */
           )
        then 'table compression'
      when bitand(t.trigflag, 65536 + 131072) != 0                /* 0x10000 */
        then 'Table with encrypted column'
      when (exists                                                    /* TDE */
            (select 1 from sys.col$ c
             where t.obj# = c.obj# and
                   bitand(c.property, 67108864 + 536870912) != 0))
        then 'table with encrypted column'
      when (exists                                                    /* oid */
            (select 1 from sys.col$ c
             where t.obj# = c.obj# and bitand(c.property, 2) = 2))
        then 'table with OID column'
      when (exists
            (select 1 from sys.col$ c
             where t.obj# = c.obj#
               and
               ((c.segcol# = 0 and bitand(c.property, 65536+32+8) != 65576 and
                              bitand(c.property, 131072) != 131072 ) or
                                                     /* not functional index */
                (c.segcol# != 0 and
                 bitand(c.property, 32) = 32 and                   /* hidden */
                 bitand(c.property, 32768) != 32768) or        /* not unused */
                 (c.type# not in (
                     1,                                          /* varchar2 */
                     2,                                            /* number */
                     8,                                              /* long */
                     12,                                             /* date */
                     24,                                         /* long raw */
                     96,                                             /* char */
                     100,                                    /* binary float */
                     101,                                   /* binary double */
                     112,                                  /* clob and nclob */
                     113,                                            /* blob */
                     180,                                  /* timestamp (..) */
                     181,                    /* timestamp(..) with time zone */
                     182,                      /* interval year(..) to month */
                     183,                  /* interval day(..) to second(..) */
                     208,                                          /* urowid */
                     231)              /* timestamp(..) with local time zone */
                   and (c.type# != 23                     /* raw not raw oid */
                     or (c.type# = 23 and bitand(c.property, 2) = 2))
                 )
               )
             )
          )
        then 'unsupported column exists'
      when bitand(t.property, 1) = 1
        then 'object table'
      when bitand(t.property, 131072) = 131072
        then 'AQ queue table'
      /* x00400000 + 0x00800000 */
      when bitand(t.property, 4194304 + 8388608) != 0
        then 'temporary table'
      when bitand(t.property, 134217728) = 134217728          /* 0x08000000 */
        then 'sub object'
      when bitand(t.property, 2147483648) = 2147483648        /* 0x80000000 */
        then 'external table'
      when bitand(t.property, 32768) = 32768     /* 0x8000 has FILE columns */
        then 'FILE column exists'
      when
        (exists  /* TO DO: add some bit to tab$.property */
          (select 1
           from   sys.mlog$ ml
           where  ml.mowner = u.name and ml.log = o.name)
        )
        then 'materialized view log'
      when bitand(t.trigflag, 268435456) = 268435456
        then 'streams unsupported object'
      when bitand(o.flags, 16) = 16
        then 'domain index'
      else NULL end) reason,
      100,                                                     /* compatible */
    (case
      when bitand(t.trigflag, 268435456) = 268435456  /* streams unsupported */
        then 'YES'
      /* x00400000 + 0x00800000  : Temp table */
      when bitand(t.property, 4194304 + 8388608) != 0
        then 'YES'
      when bitand(o.flags, 16) = 16                          /* domain index */
        then 'YES'
      else 'NO' end) auto_filtered
  from sys.obj$ o, sys.user$ u, sys.tab$ t, sys.seg$ s, sys.deferred_stg$ ds
    where t.obj# = o.obj#
      and o.owner# = u.user#
      and t.file# = s.file# (+)
      and t.block# = s.block# (+)
      and t.ts# = s.ts# (+)
      and t.obj# = ds.obj# (+)
                   /* should be consistent with knlcfIsFilteredSpecialSchema */
      and u.name not in ('SYS', 'SYSTEM', 'CTXSYS', 'DBSNMP', 'LBACSYS',
                         'MDDATA', 'MDSYS', 'DMSYS', 'OLAPSYS', 'ORDPLUGINS',
                         'ORDSYS', 'SI_INFORMTN_SCHEMA', 'SYSMAN', 'OUTLN',
                         'EXFSYS', 'WMSYS', 'XDB', 'DVSYS', 'ORDDATA')
      and bitand(o.flags,
                  2                                      /* temporary object */
                + 4                               /* system generated object */
                + 32                                 /* in-memory temp table */
                + 128                          /* dropped table (RecycleBin) */
                  ) = 0
      and
      (  (bitand(t.property,
                128         /* 0x00000080              IOT with row overflow */
              + 256         /* 0x00000100            IOT with row clustering */
              + 512         /* 0x00000200               IOT overflow segment */
             ) != 0
          ) or
          (bitand(t.flags,
                268435456    /* 0x10000000   IOT with Phys Rowid/mapping tab */
              + 536870912    /* 0x20000000 Mapping Tab for Phys rowid of IOT */
             ) != 0
          ) or
          (bitand(t.property, 262208) = 262208  /* 0x40+0x40000 IOT+user LOB */
          ) or
          (bitand(t.property, 2112) = 2112  /* 0x40+0x800 IOT + internal LOB */
          ) or
          (bitand(t.property, 64) != 0 and
             bitand(t.flags, 131072) != 0
          ) or                                    /* IOT with "Row Movement" */
          (bitand(t.property,
                  1                                           /* typed table */
                + 2                                           /* ADT columns */
                + 4                                  /* nested table columns */
                + 8                                           /* REF columns */
                + 16                                        /* array columns */
                + 4096                                             /* pk OID */
                + 8192       /* 0x2000 storage table for nested table column */
                + 65536                                      /* 0x10000 sOID */
               ) != 0
          ) or
          (exists                                      /* unsupported column */
            (select 1 from sys.col$ c
             where t.obj# = c.obj#
               and
               ((c.segcol# = 0 and bitand(c.property, 65536+32+8) != 65576 and
                              bitand(c.property, 131072) != 131072 ) or
                                                     /* not functional index */
                (c.segcol# != 0 and
                 bitand(c.property, 32) = 32 and            /* hidden column */
                 bitand(c.property, 32768) != 32768) or /* not unused column */
                 (bitand(c.property,          /* check for encrypted columns */
                         67108864           /* column encrypted without salt */
                       + 536870912             /* column encrypted with salt */
                       ) != 0
                 ) or
                 (c.type# not in (
                     1,                                          /* varchar2 */
                     2,                                            /* number */
                     8,                                              /* long */
                     12,                                             /* date */
                     24,                                         /* long raw */
                     96,                                             /* char */
                     100,                                    /* binary float */
                     101,                                   /* binary double */
                     112,                                  /* clob and nclob */
                     113,                                            /* blob */
                     180,                                  /* timestamp (..) */
                     181,                    /* timestamp(..) with time zone */
                     182,                      /* interval year(..) to month */
                     183,                  /* interval day(..) to second(..) */
                     208,                                          /* urowid */
                     231)              /* timestamp(..) with local time zone */
                   and (c.type# != 23                     /* raw not raw oid */
                     or (c.type# = 23 and bitand(c.property, 2) = 2))
                 ) or
                 (bitand(c.property, 2) = 2                    /* OID column */
                 )
               )
             )
          ) or
          (bitand(nvl(s.spare1, 0), 2048) = 2048) or    /* table compression */
          (bitand(nvl(ds.flags_stg, 0), 4) = 4) or /* DSC: table compression */
          (bitand(t.property, 1) = 1                         /* object table */
          ) or
          (bitand(t.property,
                131072      /* 0x00020000 table is used as an AQ queue table */
              + 4194304     /* 0x00400000             global temporary table */
              + 8388608     /* 0x00800000   session-specific temporary table */
              + 134217728   /* 0x08000000                    Is a Sub object */
              + 2147483648  /* 0x80000000                     eXternal TaBle */
             ) != 0
          ) or
          (bitand(t.property, 32768) = 32768      /* 0x8000 has FILE columns */
          ) or
          (bitand(t.trigflag,
                  65536     /* 0x00010000   server held key encrypted column */
                + 131072    /* 0x00020000     user held key encrypted column */
                + 268435456 /* 0x10000000                         strm unsup */
             ) != 0
          ) or
          (exists /* TO DO: add some bit to tab$.property */
            (select 1
             from sys.mlog$ ml where ml.mowner = u.name and ml.log = o.name
            )                                       /* materialized view log */
          ) or
          bitand(o.flags, 16) = 16  or                       /* domain index */
          (exists
            (select 1 from sys.partobj$ p
             where p.obj# = o.obj# and
                   p.parttype = 3))                      /* system partition */
        )
/


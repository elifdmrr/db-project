create view DBA_SCHEDULER_PROGRAMS
            (OWNER, PROGRAM_NAME, PROGRAM_TYPE, PROGRAM_ACTION, NUMBER_OF_ARGUMENTS, ENABLED, DETACHED, SCHEDULE_LIMIT,
             PRIORITY, WEIGHT, MAX_RUNS, MAX_FAILURES, MAX_RUN_DURATION, NLS_ENV, COMMENTS)
as
SELECT u.name, o.name,
  DECODE(bitand(p.flags,2+4+8+16+32), 2,'PLSQL_BLOCK',
         4,'STORED_PROCEDURE', 32, 'EXECUTABLE', ''),
  p.action, p.number_of_args, DECODE(BITAND(p.flags,1),0,'FALSE',1,'TRUE'),
  DECODE(BITAND(p.flags,256),0,'FALSE','TRUE'),
  p.schedule_limit, p.priority, p.job_weight, p.max_runs,
  p.max_failures, p.max_run_duration, p.nls_env, p.comments
  FROM obj$ o, user$ u, sys.scheduler$_program p
  WHERE p.obj# = o.obj# AND u.user# = o.owner#
/

comment on table DBA_SCHEDULER_PROGRAMS is 'All scheduler programs in the database'
/

comment on column DBA_SCHEDULER_PROGRAMS.OWNER is 'Owner of the scheduler program'
/

comment on column DBA_SCHEDULER_PROGRAMS.PROGRAM_NAME is 'Name of the scheduler program'
/

comment on column DBA_SCHEDULER_PROGRAMS.PROGRAM_TYPE is 'Type of program action'
/

comment on column DBA_SCHEDULER_PROGRAMS.PROGRAM_ACTION is 'String specifying the program action'
/

comment on column DBA_SCHEDULER_PROGRAMS.NUMBER_OF_ARGUMENTS is 'Number of arguments accepted by the program'
/

comment on column DBA_SCHEDULER_PROGRAMS.ENABLED is 'Whether the program is enabled'
/

comment on column DBA_SCHEDULER_PROGRAMS.DETACHED is 'This column is for internal use'
/

comment on column DBA_SCHEDULER_PROGRAMS.SCHEDULE_LIMIT is 'Maximum delay in running program after scheduled start'
/

comment on column DBA_SCHEDULER_PROGRAMS.PRIORITY is 'Priority of program'
/

comment on column DBA_SCHEDULER_PROGRAMS.WEIGHT is 'Weight of program'
/

comment on column DBA_SCHEDULER_PROGRAMS.MAX_RUNS is 'Maximum number of runs of program'
/

comment on column DBA_SCHEDULER_PROGRAMS.MAX_FAILURES is 'Maximum number of failures of program'
/

comment on column DBA_SCHEDULER_PROGRAMS.MAX_RUN_DURATION is 'Maximum run duration of program'
/

comment on column DBA_SCHEDULER_PROGRAMS.NLS_ENV is 'NLS Environment in which program was created'
/

comment on column DBA_SCHEDULER_PROGRAMS.COMMENTS is 'Comments on the program'
/


create view KU$_END_PLUGTS_BLK_VIEW (VERS_MAJOR, VERS_MINOR, PREPOST, PLSQL) as
select '1','0',
  1,
  (select sys.dbms_metadata.get_plugts_blk(1) from dual)
  from sys.dual
  where (SYS_CONTEXT('USERENV','CURRENT_USERID')=0
                 OR EXISTS ( SELECT * FROM sys.session_roles
                    WHERE role='SELECT_CATALOG_ROLE' ))
/


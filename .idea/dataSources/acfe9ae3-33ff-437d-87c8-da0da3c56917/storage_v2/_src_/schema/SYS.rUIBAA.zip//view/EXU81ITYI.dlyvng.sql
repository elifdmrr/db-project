create view EXU81ITYI (NAME, OBJID, OWNER, OWNERID) as
SELECT  it."NAME",it."OBJID",it."OWNER",it."OWNERID"
        FROM    sys.exu81ity it, sys.incexp i, sys.incvid v
        WHERE   it.name = i.name(+) AND
                it.ownerid = i.owner#(+) AND
                NVL(i.type#, 32) = 32 AND
                v.expid < NVL(i.expid, 9999)
/


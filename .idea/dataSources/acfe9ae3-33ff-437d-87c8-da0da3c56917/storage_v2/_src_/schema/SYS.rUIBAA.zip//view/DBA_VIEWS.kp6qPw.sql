create view DBA_VIEWS
            (OWNER, VIEW_NAME, TEXT_LENGTH, TEXT, TYPE_TEXT_LENGTH, TYPE_TEXT, OID_TEXT_LENGTH, OID_TEXT,
             VIEW_TYPE_OWNER, VIEW_TYPE, SUPERVIEW_NAME, EDITIONING_VIEW, READ_ONLY)
as
select u.name, o.name, v.textlength, v.text, t.typetextlength, t.typetext,
       t.oidtextlength, t.oidtext, t.typeowner, t.typename,
       decode(bitand(v.property, 134217728), 134217728,
              (select sv.name from superobj$ h, "_CURRENT_EDITION_OBJ" sv
              where h.subobj# = o.obj# and h.superobj# = sv.obj#), null),
       decode(bitand(v.property, 32), 32, 'Y', 'N'),
       decode(bitand(v.property, 16384), 16384, 'Y', 'N')
from sys."_CURRENT_EDITION_OBJ" o, sys.view$ v, sys.user$ u, sys.typed_view$ t
where o.obj# = v.obj#
  and o.obj# = t.obj#(+)
  and o.owner# = u.user#
/

comment on table DBA_VIEWS is 'Description of all views in the database'
/

comment on column DBA_VIEWS.OWNER is 'Owner of the view'
/

comment on column DBA_VIEWS.VIEW_NAME is 'Name of the view'
/

comment on column DBA_VIEWS.TEXT_LENGTH is 'Length of the view text'
/

comment on column DBA_VIEWS.TEXT is 'View text'
/

comment on column DBA_VIEWS.TYPE_TEXT_LENGTH is 'Length of the type clause of the object view'
/

comment on column DBA_VIEWS.TYPE_TEXT is 'Type clause of the object view'
/

comment on column DBA_VIEWS.OID_TEXT_LENGTH is 'Length of the WITH OBJECT OID clause of the object view'
/

comment on column DBA_VIEWS.OID_TEXT is 'WITH OBJECT OID clause of the object view'
/

comment on column DBA_VIEWS.VIEW_TYPE_OWNER is 'Owner of the type of the view if the view is an object view'
/

comment on column DBA_VIEWS.VIEW_TYPE is 'Type of the view if the view is an object view'
/

comment on column DBA_VIEWS.SUPERVIEW_NAME is 'Name of the superview, if view is a subview'
/

comment on column DBA_VIEWS.EDITIONING_VIEW is 'An indicator of whether the view is an Editioning View'
/

comment on column DBA_VIEWS.READ_ONLY is 'An indicator of whether the view is a Read Only View'
/


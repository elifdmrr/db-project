create view DBA_XML_VIEW_COLS (OWNER, VIEW_NAME, COLUMN_NAME, XMLSCHEMA, SCHEMA_OWNER, ELEMENT_NAME) as
select u.name, o.name,
   decode(bitand(tc.property, 1), 1, attr.name, tc.name),
   null, null, null
from  sys.opqtype$ opq,
      sys.view$ v, sys.user$ u, sys.obj$ o, sys.coltype$ ac, sys.col$ tc,
      sys.attrcol$ attr
where o.owner# = u.user#
  and o.obj# = v.obj#
  and bitand(v.property, 1) = 1
  and v.obj# = tc.obj#
  and tc.obj# = ac.obj#
  and tc.intcol# = ac.intcol#
  and tc.obj#    = attr.obj#(+)
  and tc.intcol# = attr.intcol#(+)
  and ac.toid = '00000000000000000000000000020100'
  and tc.intcol# =  opq.intcol#
  and tc.obj# =  opq.obj#
  and bitand(opq.flags,2) = 0
union all
select u.name, o.name,
   decode(bitand(tc.property, 1), 1, attr.name, tc.name),
   schm.xmldata.schema_url, schm.xmldata.schema_owner,
decode(xel.xmldata.property.name, null,
        xel.xmldata.property.propref_name.name, xel.xmldata.property.name)
from xdb.xdb$element xel, xdb.xdb$schema schm, sys.opqtype$ opq,
      sys.view$ v, sys.user$ u, sys.obj$ o, sys.coltype$ ac, sys.col$ tc,
      sys.attrcol$ attr
where o.owner# = u.user#
  and o.obj# = v.obj#
  and bitand(v.property, 1) = 1
  and v.obj# = tc.obj#
  and tc.obj# = ac.obj#
  and tc.intcol# = ac.intcol#
  and tc.obj#    = attr.obj#(+)
  and tc.intcol# = attr.intcol#(+)
  and ac.toid = '00000000000000000000000000020100'
  and tc.intcol# =  opq.intcol#
  and tc.obj# =  opq.obj#
  and opq.schemaoid =  schm.sys_nc_oid$
  and ref(schm) =  xel.xmldata.property.parent_schema
  and opq.elemnum =  xel.xmldata.property.prop_number
/

comment on table DBA_XML_VIEW_COLS is 'Description of all XML views in the database'
/

comment on column DBA_XML_VIEW_COLS.OWNER is 'Name of the owner of the XML view'
/

comment on column DBA_XML_VIEW_COLS.VIEW_NAME is 'Name of the XML view'
/

comment on column DBA_XML_VIEW_COLS.COLUMN_NAME is 'Name of the XML view column'
/

comment on column DBA_XML_VIEW_COLS.XMLSCHEMA is 'Name of the XMLSchema that is used for the view definition'
/

comment on column DBA_XML_VIEW_COLS.SCHEMA_OWNER is 'Name of the owner of the XMLSchema used for table definition'
/

comment on column DBA_XML_VIEW_COLS.ELEMENT_NAME is 'Name XMLSChema element that is used for the view'
/


create view DBA_TABLESPACE_THRESHOLDS
            (TABLESPACE_NAME, CONTENTS, EXTENT_MANAGEMENT, THRESHOLD_TYPE, METRICS_NAME, WARNING_OPERATOR,
             WARNING_VALUE, CRITICAL_OPERATOR, CRITICAL_VALUE)
as
SELECT tablespace_name,
         contents,
         extent_management,
         decode(threshold_type, 1, 'EXPLICIT',
                                2, 'DEFAULT',
                                'NONE') as threshold_type,
         metrics_name,
         decode(warning_operator, 0, 'GT',
                                  1, 'EQ',
                                  2, 'LT',
                                  3, 'LE',
                                  4, 'GE',
                                  5, 'CONTAINS',
                                  6, 'NE',
                                  7, 'DO NOT CHECK',
                                  'NONE') AS warning_operator,
         warning_value,
         decode(critical_operator, 0, 'GT',
                                   1, 'EQ',
                                   2, 'LT',
                                   3, 'LE',
                                   4, 'GE',
                                   5, 'CONTAINS',
                                   6, 'NE',
                                   7, 'DO NOT CHECK',
                                   'NONE') AS critical_operator,
         critical_value
    FROM
    (SELECT tbs.tablespace_name,
            tbs.contents,
            tbs.extent_management,
            decode(m.metrics_name, NULL, 0, 1) as threshold_type,
            m.metrics_name,
            m.warning_operator,
            m.warning_value,
            m.critical_operator,
            m.critical_value
      FROM
         ((SELECT tablespace_name,
                 contents,
                 extent_management
             FROM DBA_TABLESPACES
            WHERE tablespace_name IN
                  (SELECT object_name
                     FROM table(dbms_server_alert.view_thresholds)
                    WHERE object_type = 5
                      AND object_name IS NOT NULL
                      AND metrics_id IN (9000, 9001))
          ) tbs
       LEFT OUTER JOIN
         (SELECT a.object_name,
                m.name AS metrics_name,
                a.warning_operator AS warning_operator,
                a.warning_value AS warning_value,
                a.critical_operator AS critical_operator,
                a.critical_value AS critical_value,
                c.contents
            FROM table(dbms_server_alert.view_thresholds) a,
                 X$KEWMDSM m,
                 (SELECT 'PERMANENT' AS contents FROM DUAL
                   WHERE EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_tablespace_alerts'
                                    AND display_value='TRUE')
                  UNION ALL
                  SELECT 'TEMPORARY' FROM DUAL
                   WHERE EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_tablespace_alerts'
                                    AND display_value = 'TRUE')
                     AND EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                 WHERE name = '_disable_temp_tablespace_alerts'
                                    AND display_value = 'FALSE')
                  UNION ALL
                  SELECT 'UNDO' FROM DUAL
                   WHERE EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_tablespace_alerts'
                                          AND display_value='TRUE')
                     AND EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                 WHERE name = '_disable_undo_tablespace_alerts'
                                    AND display_value = 'FALSE')) c
           WHERE a.object_type = 5
             AND a.flags = 1
             AND a.object_name IS NOT NULL
             AND a.metrics_id IN (9000, 9001)
             AND m.metricid = a.metrics_id) m
        ON (tbs.tablespace_name = m.object_name
            and tbs.contents = m.contents))
   UNION ALL
    SELECT tbs.tablespace_name,
            tbs.contents,
            tbs.extent_management,
            decode(m.metrics_name, NULL, 0, 2) as threshold_type,
            m.metrics_name,
            m.warning_operator,
            m.warning_value,
            m.critical_operator,
            m.critical_value
      FROM
        ((SELECT tablespace_name,
                 contents,
                 extent_management
            FROM DBA_TABLESPACES
           WHERE tablespace_name NOT IN
                  (SELECT object_name
                     FROM table(dbms_server_alert.view_thresholds)
                    WHERE object_type = 5
                      AND object_name IS NOT NULL
                      AND metrics_id IN (9000, 9001))
         ) tbs
         LEFT OUTER JOIN
         (SELECT 'LOCAL' as extent_management,
                  m.name AS metrics_name,
                  a.warning_operator AS warning_operator,
                  a.warning_value AS warning_value,
                  a.critical_operator AS critical_operator,
                  a.critical_value AS critical_value,
                  c.contents
            FROM table(dbms_server_alert.view_thresholds) a,
                 X$KEWMDSM m,
                 (SELECT 'PERMANENT' AS contents FROM DUAL
                   WHERE EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_tablespace_alerts'
                                    AND display_value='TRUE')
                  UNION ALL
                  SELECT 'TEMPORARY' FROM DUAL
                   WHERE EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_tablespace_alerts'
                                    AND display_value = 'TRUE')
                     AND EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                 WHERE name = '_disable_temp_tablespace_alerts'
                                   AND display_value = 'FALSE')
                     AND EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_default_temp_threshold'
                                    AND display_value = 'TRUE')
                  UNION ALL
                  SELECT 'UNDO' FROM DUAL
                   WHERE EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_tablespace_alerts'
                                          AND display_value='TRUE')
                     AND EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                 WHERE name = '_disable_undo_tablespace_alerts'
                                   AND display_value = 'FALSE')
                     AND EXISTS (SELECT * FROM GV$SYSTEM_PARAMETER3
                                  WHERE name = '_enable_default_undo_threshold'
                                    AND display_value = 'TRUE')) c
           WHERE a.object_type = 5
             AND a.object_name IS NULL
             AND a.metrics_id IN (9000, 9001)
             AND m.metricid = a.metrics_id) m
        ON (tbs.extent_management =  m.extent_management
            and tbs.contents = m.contents)))
/

comment on table DBA_TABLESPACE_THRESHOLDS is 'Space Utilization Threshold settings for all tablespaces'
/

comment on column DBA_TABLESPACE_THRESHOLDS.TABLESPACE_NAME is 'Tablespace name'
/

comment on column DBA_TABLESPACE_THRESHOLDS.CONTENTS is 'Tablespace contents: "PERMANENT", "TEMPORARY", or "UNDO"'
/

comment on column DBA_TABLESPACE_THRESHOLDS.EXTENT_MANAGEMENT is 'Extent management tracking: "DICTIONARY" or "LOCAL"'
/

comment on column DBA_TABLESPACE_THRESHOLDS.THRESHOLD_TYPE is 'Source of threshold: "EXPLICIT", "DEFAULT", or "NONE"'
/

comment on column DBA_TABLESPACE_THRESHOLDS.METRICS_NAME is 'Name of the metric being monitored'
/

comment on column DBA_TABLESPACE_THRESHOLDS.WARNING_OPERATOR is 'Relational operator for warning thresholds'
/

comment on column DBA_TABLESPACE_THRESHOLDS.WARNING_VALUE is 'Warning threshold value'
/

comment on column DBA_TABLESPACE_THRESHOLDS.CRITICAL_OPERATOR is 'Relational operator for critical thresholds'
/

comment on column DBA_TABLESPACE_THRESHOLDS.CRITICAL_VALUE is 'Critical threshold value'
/


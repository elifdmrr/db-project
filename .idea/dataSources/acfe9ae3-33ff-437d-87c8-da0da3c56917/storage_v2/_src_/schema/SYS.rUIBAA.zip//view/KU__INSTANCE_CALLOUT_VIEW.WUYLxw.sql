create view KU$_INSTANCE_CALLOUT_VIEW
            (VERS_MAJOR, VERS_MINOR, USER_NAME, OBJ_NUM, BASE_OBJ, PACKAGE, PKG_SCHEMA, LEVEL_NUM, CLASS, PREPOST,
             TS_NAME, INCL_CONST, INCL_TRIG, INCL_GRANT, TTS_FULL_CHK, TTS_CLOSURE_CHK)
as
select '1','0',
     null, d.obj#,
     value(o),
     p.package, p.schema, p.level#, p.class, pr.prepost,
     null, null, null, null, null, null
   FROM  sys.ku$_schemaobj_view o,
         sys.exppkgact$ p,
         sys.expdepact$ d,
         ku$_prepost_view pr
   WHERE d.obj# = o.obj_num AND d.package = p.package
         and d.schema = p.schema and p.class = 7
         and (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0)
                 OR EXISTS ( SELECT * FROM sys.session_roles
                    WHERE role='SELECT_CATALOG_ROLE' ))
   ORDER   by p.level#
/


create view GV_$SQLCOMMAND (INST_ID, COMMAND_TYPE, COMMAND_NAME) as
select "INST_ID","COMMAND_TYPE","COMMAND_NAME" from gv$sqlcommand
/


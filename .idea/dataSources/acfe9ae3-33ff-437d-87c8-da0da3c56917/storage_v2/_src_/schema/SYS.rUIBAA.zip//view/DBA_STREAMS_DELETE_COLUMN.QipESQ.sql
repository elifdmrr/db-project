create view DBA_STREAMS_DELETE_COLUMN
            (RULE_OWNER, RULE_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME, VALUE_TYPE, PRECEDENCE, STEP_NUMBER) as
select rule_owner, rule_name, schema_name, table_name, column_name,
       value_type, precedence, step_number
  from DBA_STREAMS_TRANSFORMATIONS
  where declarative_type = 'DELETE COLUMN'
/

comment on table DBA_STREAMS_DELETE_COLUMN is 'Delete column transformations'
/

comment on column DBA_STREAMS_DELETE_COLUMN.RULE_OWNER is 'Owner of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_DELETE_COLUMN.RULE_NAME is 'Name of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_DELETE_COLUMN.SCHEMA_NAME is 'The schema of the column to be modified'
/

comment on column DBA_STREAMS_DELETE_COLUMN.TABLE_NAME is 'The table of the column to be modified'
/

comment on column DBA_STREAMS_DELETE_COLUMN.COLUMN_NAME is 'The column to delete'
/

comment on column DBA_STREAMS_DELETE_COLUMN.VALUE_TYPE is 'Whether to delete the old column value of the lcr, the new value, or both'
/

comment on column DBA_STREAMS_DELETE_COLUMN.PRECEDENCE is 'Execution order relative to other declarative transformations on the same step_number'
/

comment on column DBA_STREAMS_DELETE_COLUMN.STEP_NUMBER is 'The order that this transformation should be executed'
/


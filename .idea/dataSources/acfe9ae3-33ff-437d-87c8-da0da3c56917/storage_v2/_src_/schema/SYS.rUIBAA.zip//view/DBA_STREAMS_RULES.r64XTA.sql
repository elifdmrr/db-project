create view DBA_STREAMS_RULES
            (STREAMS_TYPE, STREAMS_NAME, RULE_SET_OWNER, RULE_SET_NAME, RULE_OWNER, RULE_NAME, RULE_CONDITION,
             RULE_SET_TYPE, STREAMS_RULE_TYPE, SCHEMA_NAME, OBJECT_NAME, SUBSETTING_OPERATION, DML_CONDITION,
             INCLUDE_TAGGED_LCR, SOURCE_DATABASE, RULE_TYPE, MESSAGE_TYPE_OWNER, MESSAGE_TYPE_NAME,
             MESSAGE_RULE_VARIABLE, ORIGINAL_RULE_CONDITION, SAME_RULE_CONDITION)
as
select decode(r.streams_type, 1, 'CAPTURE',
                              2, 'PROPAGATION',
                              3, 'APPLY',
                              4, 'DEQUEUE',
                              5, 'SYNC_CAPTURE') streams_type,
       r.streams_name, r.rule_set_owner, r.rule_set_name,
       r.rule_owner, r.rule_name, r.rule_condition, r.rule_set_type,
       decode(sr.object_type, 1, 'TABLE',
                              2, 'SCHEMA',
                              3, 'GLOBAL') streams_rule_type,
       sr.schema_name, sr.object_name,
       decode(sr.subsetting_operation, 1, 'INSERT',
                                       2, 'UPDATE',
                                       3, 'DELETE') subsetting_operation,
       sr.dml_condition,
       decode(sr.include_tagged_lcr, 0, 'NO',
                                     1, 'YES') include_tagged_lcr,
       sr.source_database,
       decode(sr.rule_type, 1, 'DML',
                            2, 'DDL') rule_type,
       smr.msg_type_owner message_type_owner,
       smr.msg_type_name message_type_name,
       smr.msg_rule_var message_rule_variable,
       NVL(sr.rule_condition, smr.rule_condition) original_rule_condition,
       decode(NVL(sr.rule_condition, smr.rule_condition),
              NULL, NULL,
              dbms_lob.substr(r.rule_condition), 'YES',
              decode(least(4001,dbms_lob.getlength(r.rule_condition)),
                     4001, NULL, 'NO')) same_rule_condition
  from "_DBA_STREAMS_RULES_H" r, streams$_rules sr, streams$_message_rules smr
  where r.rule_name = sr.rule_name(+)
    and r.rule_owner = sr.rule_owner(+)
    and r.rule_name = smr.rule_name(+)
    and r.rule_owner = smr.rule_owner(+)
/

comment on table DBA_STREAMS_RULES is 'Rules used by Streams processes'
/

comment on column DBA_STREAMS_RULES.STREAMS_TYPE is 'Type of the Streams process: CAPTURE, PROPAGATION, APPLY or DEQUEUE'
/

comment on column DBA_STREAMS_RULES.STREAMS_NAME is 'Name of the Streams process'
/

comment on column DBA_STREAMS_RULES.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column DBA_STREAMS_RULES.RULE_SET_NAME is 'Name of the rule set'
/

comment on column DBA_STREAMS_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column DBA_STREAMS_RULES.RULE_NAME is 'Name of the rule'
/

comment on column DBA_STREAMS_RULES.RULE_CONDITION is 'Current rule condition'
/

comment on column DBA_STREAMS_RULES.RULE_SET_TYPE is 'Type of the rule set: POSITIVE or NEGATIVE'
/

comment on column DBA_STREAMS_RULES.STREAMS_RULE_TYPE is 'For global, schema or table rules, type of rule: TABLE, SCHEMA or GLOBAL'
/

comment on column DBA_STREAMS_RULES.SCHEMA_NAME is 'For table and schema rules, the schema name'
/

comment on column DBA_STREAMS_RULES.OBJECT_NAME is 'For table rules, the table name'
/

comment on column DBA_STREAMS_RULES.SUBSETTING_OPERATION is 'For subset rules, the type of operation: INSERT, UPDATE, or DELETE'
/

comment on column DBA_STREAMS_RULES.DML_CONDITION is 'For subset rules, the row subsetting condition'
/

comment on column DBA_STREAMS_RULES.INCLUDE_TAGGED_LCR is 'For global, schema or table rules, whether or not to include tagged LCRs'
/

comment on column DBA_STREAMS_RULES.SOURCE_DATABASE is 'For global, schema or table rules, the name of the database where the LCRs originated'
/

comment on column DBA_STREAMS_RULES.RULE_TYPE is 'For global, schema or table rules, type of rule: DML or DDL'
/

comment on column DBA_STREAMS_RULES.MESSAGE_TYPE_OWNER is 'For message rules, the owner of the message type'
/

comment on column DBA_STREAMS_RULES.MESSAGE_TYPE_NAME is 'For message rules, the name of the message type'
/

comment on column DBA_STREAMS_RULES.MESSAGE_RULE_VARIABLE is 'For message rules, the name of the variable in the message rule'
/

comment on column DBA_STREAMS_RULES.ORIGINAL_RULE_CONDITION is 'For rules created by Streams administrative APIs, the original rule condition when the rule was created'
/

comment on column DBA_STREAMS_RULES.SAME_RULE_CONDITION is 'For rules created by Streams administrative APIs, whether or not the current rule condition is the same as the original rule condition'
/


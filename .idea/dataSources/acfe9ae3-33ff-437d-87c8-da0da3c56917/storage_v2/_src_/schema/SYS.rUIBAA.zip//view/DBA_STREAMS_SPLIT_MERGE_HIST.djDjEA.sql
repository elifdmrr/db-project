create view DBA_STREAMS_SPLIT_MERGE_HIST
            (ORIGINAL_CAPTURE_NAME, CLONED_CAPTURE_NAME, ORIGINAL_QUEUE_OWNER, ORIGINAL_QUEUE_NAME, CLONED_QUEUE_OWNER,
             CLONED_QUEUE_NAME, ORIGINAL_CAPTURE_STATUS, CLONED_CAPTURE_STATUS, ORIGINAL_STREAMS_NAME,
             CLONED_STREAMS_NAME, STREAMS_TYPE, RECOVERABLE_SCRIPT_ID, SCRIPT_STATUS, ACTION_TYPE, ACTION_THRESHOLD,
             STATUS, STATUS_UPDATE_TIME, CREATION_TIME, LAG, JOB_OWNER, JOB_NAME, ERROR_NUMBER, ERROR_MESSAGE)
as
select s.original_capture_name,   s.cloned_capture_name,
       s.original_queue_owner,    s.original_queue_name,
       s.cloned_queue_owner,      s.cloned_queue_name,
       decode(s.original_capture_name, NULL, NULL,
                                       NVL(c1.status, 'DROPPED')),
       decode(s.cloned_capture_name, NULL, NULL,
                                       NVL(c2.status, 'DROPPED')),
       s.original_streams_name,   s.cloned_streams_name,
       decode(s.streams_type, 2, 'PROPAGATION',
                              3, 'APPLY'),
       s.recoverable_script_id,   NVL(decode(r.status, 1, 'GENERATING',
                                                       2, 'NOT EXECUTED',
                                                       3, 'EXECUTING',
                                                       4, 'EXECUTED',
                                                       5, 'ERROR'),
                                      decode(s.recoverable_script_id,
                                                       NULL, NULL,
                                                       'DROPPED')),
       decode(s.action_type, 1, 'SPLIT',
                             2, 'MERGE',
                             3, 'MONITOR'),
       decode(s.action_threshold, 2147483647, 'INFINITE',
                                  s.action_threshold),
       decode(s.status, 1, 'NOTHING TO SPLIT',
                        2, 'ABOUT TO SPLIT',
                        3, 'SPLITTING',
                        4, 'SPLIT DONE',
                        5, 'NOTHING TO MERGE',
                        6, 'ABOUT TO MERGE',
                        7, 'MERGING',
                        8, 'MERGE DONE',
                        9, 'ERROR',
                       10, 'NONSPLITTABLE'),
       s.status_update_time,
       s.creation_time,
       s.lag,
       s.job_owner,               s.job_name,
       s.error_number,            s.error_message
  from sys.streams$_split_merge s, dba_capture c1, dba_capture c2,
       sys.reco_script$ r
 where s.original_capture_name = c1.capture_name (+)
   and s.cloned_capture_name   = c2.capture_name (+)
   and s.recoverable_script_id =  r.oid          (+)
   and s.active               != 2
/

comment on table DBA_STREAMS_SPLIT_MERGE_HIST is 'history view of details of split/merge jobs/status about streams'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ORIGINAL_CAPTURE_NAME is 'name of the original capture'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.CLONED_CAPTURE_NAME is 'name of the cloned capture'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ORIGINAL_QUEUE_OWNER is 'name of original queue owner'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ORIGINAL_QUEUE_NAME is 'name of original queue'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.CLONED_QUEUE_OWNER is 'name of cloned queue owner'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.CLONED_QUEUE_NAME is 'name of cloned queue'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ORIGINAL_CAPTURE_STATUS is 'status of the original capture'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.CLONED_CAPTURE_STATUS is 'status of the cloned capture'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ORIGINAL_STREAMS_NAME is 'name of original streams (propagation or local apply)'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.CLONED_STREAMS_NAME is 'name of cloned streams (propagation or local apply)'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.STREAMS_TYPE is 'type of streams (propagation or local apply)'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.RECOVERABLE_SCRIPT_ID is 'unique oid of the script to split or merge streams'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.SCRIPT_STATUS is 'status of the script to split or merge streams'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ACTION_TYPE is 'type of action performed on this streams (either split or merge)'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ACTION_THRESHOLD is 'value of split_threshold or merge_threshold'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.STATUS is 'status of streams'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.STATUS_UPDATE_TIME is 'time when status was last updated'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.CREATION_TIME is 'time when this row was created'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.LAG is 'the time in seconds that the cloned capture lags behind the original capture'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.JOB_OWNER is 'name of the owner of the job'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.JOB_NAME is 'name of the job to split or merge streams'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ERROR_NUMBER is 'Error number if the capture process was aborted'
/

comment on column DBA_STREAMS_SPLIT_MERGE_HIST.ERROR_MESSAGE is 'Error message if the capture process was aborted'
/


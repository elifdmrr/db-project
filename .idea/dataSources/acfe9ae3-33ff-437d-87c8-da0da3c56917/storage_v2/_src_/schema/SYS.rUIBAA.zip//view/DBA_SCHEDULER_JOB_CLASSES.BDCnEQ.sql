create view DBA_SCHEDULER_JOB_CLASSES
            (JOB_CLASS_NAME, RESOURCE_CONSUMER_GROUP, SERVICE, LOGGING_LEVEL, LOG_HISTORY, COMMENTS) as
SELECT co.name, c.res_grp_name,
    c.affinity ,
    DECODE(BITAND(c.flags,32+64+128+256),32,'OFF',64,'RUNS',128,'FAILED RUNS',
      256,'FULL',NULL),
    c.log_history, c.comments
  FROM obj$ co, sys.scheduler$_class c
  WHERE c.obj# = co.obj#
/

comment on table DBA_SCHEDULER_JOB_CLASSES is 'All scheduler classes in the database'
/

comment on column DBA_SCHEDULER_JOB_CLASSES.JOB_CLASS_NAME is 'Name of the scheduler class'
/

comment on column DBA_SCHEDULER_JOB_CLASSES.RESOURCE_CONSUMER_GROUP is 'Resource consumer group associated with the class'
/

comment on column DBA_SCHEDULER_JOB_CLASSES.SERVICE is 'Name of the service this class is affined with'
/

comment on column DBA_SCHEDULER_JOB_CLASSES.LOGGING_LEVEL is 'Amount of logging that will be done pertaining to this class'
/

comment on column DBA_SCHEDULER_JOB_CLASSES.LOG_HISTORY is 'The history to maintain in the job log (in days) for this class'
/

comment on column DBA_SCHEDULER_JOB_CLASSES.COMMENTS is 'Comments on this class'
/


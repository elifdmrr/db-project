create view MGMT_BSLN_THRESHOLD_PARMS
            (BSLN_GUID, DATASOURCE_GUID, THRESHOLD_METHOD, NUM_OCCURRENCES, WARNING_PARAM, CRITICAL_PARAM,
             FAIL_ACTION) as
select btp.bsln_guid
      ,bsln.datasource_guid(bsln.target_uid(bb.dbid, i.instance_number),
                            bsln.metric_uid(btp.metric_id))
      ,btp.threshold_method
      ,btp.num_occurrences
      ,btp.warning_param
      ,btp.critical_param
      ,btp.fail_action
  from bsln_threshold_params btp, bsln_baselines bb, gv$instance i
 where btp.bsln_guid = bb.bsln_guid
   and bb.instance_name = i.instance_name
/

comment on table MGMT_BSLN_THRESHOLD_PARMS is 'Database Metric Baseline Thresholds (10.2)'
/


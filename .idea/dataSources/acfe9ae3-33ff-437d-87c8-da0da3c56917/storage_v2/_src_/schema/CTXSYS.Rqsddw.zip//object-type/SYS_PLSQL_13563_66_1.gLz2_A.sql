create type          SYS_PLSQL_13563_66_1 as table of "CTXSYS"."SYS_PLSQL_13563_38_1";
/


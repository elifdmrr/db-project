create type          SYS_PLSQL_13563_92_1 as table of "CTXSYS"."SYS_PLSQL_13563_74_1";
/


create type          SYS_PLSQL_13580_DUMMY_1 as table of number;
/


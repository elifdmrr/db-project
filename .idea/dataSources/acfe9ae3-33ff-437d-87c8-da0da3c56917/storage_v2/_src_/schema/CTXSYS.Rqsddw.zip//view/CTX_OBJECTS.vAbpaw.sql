create view CTX_OBJECTS as
select cla_name  obj_class,
       obj_name  obj_name,
       obj_desc  obj_description
  from dr$class,
       dr$object
 where cla_id     = obj_cla_id
   and obj_system = 'N'
   and cla_system = 'N'
/


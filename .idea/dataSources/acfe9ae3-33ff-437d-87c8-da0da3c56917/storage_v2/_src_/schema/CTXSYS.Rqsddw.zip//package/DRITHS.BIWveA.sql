create PACKAGE driths AS

   type phrtab is table of dr$ths_phrase%rowtype index by binary_integer;

/*--------------------------------- get_ths -------------------------------*/
/*
  NAME
    get_ths -- lookup thesaurus id and case-sensitivity

  ARGUMENTS
    tname  - thesaurus name
    tid    - thesaurus id (OUT)
    tcs    - thesaurus case sensitivity (OUT)
    modify - set to TRUE if you want to do ownership checking

  NOTES
    error if thesaurus does not exist
*/
PROCEDURE get_ths(
  tname  in  varchar2,
  tid    out number,
  tcs    out boolean,
  modify in  boolean  default FALSE
);

/*--------------------------------- parse_phrase ---------------------------*/
/*
  NAME
    parse_phrase

  DESCRIPTION
    This procedure parses a phrase into phrase and qualifier parts

  RETURN
*/

PROCEDURE parse_phrase (
  phrase in     varchar2,
  ppart  out    varchar2,
  qpart  out    varchar2
);

/*--------------------------------- lookup -------------------------------*/
/*
  NAME
    lookup -- lookup phrase in a thesaurus

  DESCRIPTION
    This procedure looks up a phrase in the given thesaurus

  RETURN
    TRUE if phrase is found, FALSE otherwise
*/

FUNCTION lookup (
  tname  in     varchar2,
  phrase in     varchar2,
  resarr in out phrtab
) return boolean;


/*----------------------------- lookup_single-----------------------------*/
/*
  NAME
    lookup_single -- lookup a single phrase in a thesaurus

  DESCRIPTION
    This procedure looks up a phrase in the given thesaurus

  RETURN
    phrase id

  NOTES
    phrase must exist in thesaurus
    if hits multiple phrases, only the first is returned
*/
FUNCTION lookup_single (
  tid    in     number,
  phrase in     varchar2,
  qual   in     varchar2
) return number;


end driths;
/


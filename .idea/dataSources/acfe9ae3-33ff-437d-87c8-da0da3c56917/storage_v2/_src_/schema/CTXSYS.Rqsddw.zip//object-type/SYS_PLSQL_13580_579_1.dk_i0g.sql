create type          SYS_PLSQL_13580_579_1 as table of "CTXSYS"."SYS_PLSQL_13580_559_1";
/


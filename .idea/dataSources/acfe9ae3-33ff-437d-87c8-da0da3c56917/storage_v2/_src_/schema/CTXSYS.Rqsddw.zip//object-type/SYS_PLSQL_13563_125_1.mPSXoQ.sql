create type          SYS_PLSQL_13563_125_1 as table of "CTXSYS"."SYS_PLSQL_13563_100_1";
/


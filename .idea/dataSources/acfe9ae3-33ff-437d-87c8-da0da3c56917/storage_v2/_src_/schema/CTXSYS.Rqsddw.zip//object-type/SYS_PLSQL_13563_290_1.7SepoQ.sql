create type          SYS_PLSQL_13563_290_1 as object (ID NUMBER,
VALUE VARCHAR2(128));
/


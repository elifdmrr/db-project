create type          SYS_PLSQL_13563_305_1 as table of "CTXSYS"."SYS_PLSQL_13563_290_1";
/


create package drvddlx authid current_user as

/*----------------------- IndexCreate  -----------------------*/
/*
  NAME
    IndexCreate

  DESCRIPTION
    create an index
*/
PROCEDURE IndexCreate(
  ia          in  sys.odciindexinfo,
  owner       in  varchar2,
  index_name  in  varchar2,
  table_owner in  varchar2,
  table_name  in  varchar2,
  column_name in  varchar2,
  idxmem      in  number,
  storage     in  varchar2
);

/*----------------------- IndexTransport  -----------------------*/
/*
  NAME
    IndexTransport

  DESCRIPTION
    meta-data cleanup after transportable tablespace
*/
PROCEDURE IndexTransport(
    owner           in  varchar2,
    index_name      in  varchar2,
    table_owner     in  varchar2,
    table_name      in  varchar2,
    IndexInfoFlags  in  number
);

/*----------------------- IndexDrop  -------------------------*/
/*
  NAME
    IndexDrop

  DESCRIPTION
    drop an index

  ARGUMENTS
    ia           index info
*/
PROCEDURE IndexDrop(
  ia          in  sys.ODCIIndexInfo,
  owner       in  varchar2,
  index_name  in  varchar2
);

/*----------------------- IndexRename  ---------------------*/
/*
  NAME
    IndexRename

  DESCRIPTION
    rename an index

  ARGUMENTS
    ia           index info
    owner        index owner
    index_name   index name
    new_name     new name
*/
PROCEDURE IndexRename(
  ia           in sys.odciindexinfo,
  owner        in varchar2,
  index_name   in varchar2,
  new_name     in varchar2
);

/*----------------------- IndexColRename  ---------------------*/
/*
  NAME
    IndexColRename

  DESCRIPTION
    rename an index column

  ARGUMENTS
    ia           index info
    owner        index owner
    index_name   index name
    new_name     new name
*/
PROCEDURE IndexColRename(
  ia           in sys.odciindexinfo,
  owner        in varchar2,
  index_name   in varchar2,
  new_name     in varchar2
);

/*----------------------- IndexTruncate  ---------------------*/
/*
  NAME
    IndexTruncate

  DESCRIPTION
    truncate an index

  ARGUMENTS
    owner        index owner
    index_name   index name
*/
PROCEDURE IndexTruncate(
  ia           in sys.odciindexinfo,
  owner        in varchar2,
  index_name   in varchar2
);

/*----------------------- IndexReplace  -------------------------*/
/*
  NAME
    IndexReplace

  DESCRIPTION
    rebuild an index, replacing preferences as needed

  ARGUMENTS
    ia           index info
    idx          index record
    idxmem       index memory
    storage      storage pref name
*/
PROCEDURE IndexReplace(
  ia          in  sys.ODCIIndexInfo,
  idx         in  dr_def.idx_rec,
  idxmem      in  number,
  storage     in  varchar2
);

/*----------------------- IndexResume  -------------------------*/
/*
  NAME
    IndexResume

  DESCRIPTION
    resume index creation

  ARGUMENTS
    ia           index info
    idx          index record
    para         parallel degree
    idxmem       index memory
*/
PROCEDURE IndexResume(
  ia          in  sys.ODCIIndexInfo,
  idx         in  dr_def.idx_rec,
  idxmem      in  number
);

/*----------------------- IsBinaryXMLColumn -------------------*/
/*
 NAME
   IsBinaryXMLColumn

 DESCRIPTION
   Is this XMLType column stored as binary?

 ARGUMENTS
   tableSchema   schema owning the table
   tableName     table name
   colName       column name
*/
FUNCTION isBinaryXMLColumn(
  tableSchema IN VARCHAR2,
  tableName   IN VARCHAR2,
  colName     IN VARCHAR2,
  indexName   IN VARCHAR2
) return boolean;

end drvddlx;
/


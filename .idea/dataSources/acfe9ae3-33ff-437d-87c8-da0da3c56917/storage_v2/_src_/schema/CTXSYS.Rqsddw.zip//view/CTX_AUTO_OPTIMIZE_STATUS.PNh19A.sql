create view CTX_AUTO_OPTIMIZE_STATUS as
select l.log_date aos_timestamp,
       l.status   aos_status,
       d.additional_info aos_error
  from user_scheduler_job_log l, user_scheduler_job_run_details d
  where l.log_id = d.log_id and
        l.owner = d.owner and
        l.owner = 'CTXSYS'
/


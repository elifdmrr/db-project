create type dr$substring as object
(
  part_1 varchar2(61),
  part_2 varchar2(64)
);
/

